import { useAccount, AccountTag } from '../ui/accounts.js';
import { TrophyBadge } from '../ui/trophies.js';
import { isOwnerName, decorateOwnerName } from '../ui/ownerName.js';
import { enabled as federationEnabled, currentNode } from '../federation.js';
// Room screen (同盟等待室). 2026-10-13 (the owner's request: the event's room, video 5:22–6:29): tall seat cards side by
// side — a portrait per doctor (名片干员: the player's own pick — room.card, room.state seats[].card; one's own screen shows
// it at once, the others once the server takes room.card — else an operator chosen from the player id), 创建者, 已就绪 / 准备中
// / 失去信号, the name plate with the account avatar and #tag, the host's 移出; an empty seat is 邀请 (copies the
// alliance key) or, while searching, a waiting glyph. Top: leave, the time waited, latency, 统计 / 设置 / 玩法说明, the
// alliance key with 复制 / 链接. Bottom: 干员调配, the status line, the 精确搜寻 | difficulty | ⚙ pill (the host picks the
// difficulty in 选择模拟协议 over the room and keeps 私密房间 / 人数上限 / AI 队友最后选择 / 无限火力 branch under ⚙),
// 开始搜寻 and 开始模拟 (host) or 准备就绪. 开始搜寻 runs the server's room queue (match.queue: same mode and
// difficulty) and keeps it running until stopped or full (the server ends a room's turn after 10 s without bots: the
// host's client queues again); everybody sees 搜寻中 (ui/matchFlow.js), then 搜寻成功 when the seats fill or a player
// arrives through match.found. 人数上限 only shows when shared/constants.js allows more than DEFAULT_SEATS.
// 对局选项 (this fork): the 座位区下方的三页签面板 —— 敌方强化 / 我方增益 / 全局设置（难度滑条、干员增益滑条、
// 海克斯开关与等级设定、海克斯图鉴入口），host-only before the match。
// Motion (the event's, css tr-*): the room comes up from black card by card and fades out when left; a doctor turning
// 已就绪 flashes green; 选择模拟协议, ⚙, 搜寻中 and 搜寻成功 stay mounted while they fade out (ui/transitions.js).
//
// Start rule (server/lobby.js): room.start needs every *other* human connected and ready; the
// host's start counts as the host's ready. So 开始模拟 is enabled exactly then and sends room.start
// alone (no separate room.ready round trip that could leave the host "ready" after a failed start).
// Solo rooms show a single seat.
// Spectator seats (community report #26, a remake feature): a co-op room with spectators shows the 观战席 strip under
// the seats — names, offline marks, the host's ✕ (room.removeSpectator) — and a spectator's own view swaps the ready
// button for 观战中 and offers 入座 (room.join of the room) while a player seat is free.
// Texts go through t() (docs/I18N.md).

import { useEffect, useMemo, useRef, useState } from '../../vendor/hooks.module.js';
import {
  DIFFICULTIES, DIFFICULTY_NAMES, DIFFICULTY_COLORS, MAX_SPECTATORS,
  TUNING_STATS, TUNING_MAX, normalizeTuning, OPS_BUFF_STATS, OPS_BUFF_MAX, normalizeOpsBuffs, normalizeRoomFlags,
  MIN_SEATS,
} from '../../../shared/constants.js';
// seat counts through the namespace: the live constants (before the 10-seat package) have MAX_SEATS 4 and no DEFAULT_SEATS
import * as SEAT_CONST from '../../../shared/constants.js';
import { RANDOM_MODE, RANDOM_MODE_NAME } from '../../../shared/randomMode.js';
import { HEX_GRADE_CHOICES, HEX_GRADE_NAME, HEX_GRADE_RANDOM, HEX_GRADE_COLOR } from '../../../shared/hexes.js';
import { HexCodex } from '../ui/hexCodex.js';
import {
  html, Button, Icon, MicroLabel, AvatarFrame, DifficultyIcon, Tooltip, confirmDialog, doctorNo, Spinner, Modal,
} from '../ui/components.js';
import { toast, toastError } from '../ui/toasts.js';
import { copyText } from '../ui/clipboard.js';
import { GuideButton } from '../ui/guide.js';
import { openStats } from './stats.js';
import { openFriends } from '../ui/friends.js';
import { NameCardLayer } from '../ui/namecards.js';
import { SettingsButton } from '../ui/settings.js';
import { LoadoutButton } from './loadout.js';
import { SupportButton } from './support.js';
import { ChatPanel } from './chat.js';
import * as roomMods from '../roomMods.js';
import { setMorphPairing as applyMorphPairing, setMorphSlotPolicy as applyMorphSlotPolicy } from '../ui/gameLogic/bonds.js';
import { roomModsOf, shortDigest } from '../roomMods.js';
import { loadCatalog, planAlignment, alignRoom, missingPackIds, storeFor } from '../mods/align.js';
import { net } from '../net.js';
import { store, useStore, shallowEqual, emptyMatch, isSpectating, serverNow, loadPref, savePref } from '../store.js';
import { data, useData } from '../data.js';
import { chessAvatarUrl } from '../ui/assetUrls.js';
import { CARD_PREF, cardOperators, seatPortrait } from '../ui/seatArt.js';
import { C2S } from '../../../shared/protocol.js';
import { difficultyInfo, ProtoCard, LAYER_TEXT, serverSeatMaxOf } from './lobby.js';
import { ProtocolScene } from '../ui/protocolScene.js';
import { SearchPanel, FoundPanel } from '../ui/matchFlow.js';
import { usePresence, useRise, afterLeave } from '../ui/transitions.js';
import { t, tc } from '../../../shared/i18n.js';

const MAX_SEATS = Number(SEAT_CONST.MAX_SEATS) || 4;
const DEFAULT_SEATS = Number(SEAT_CONST.DEFAULT_SEATS) || MAX_SEATS;

/**
 * Upper bound on the seat cards the client will pad out from `room.state.seatCap`. The server owns the real cap
 * (server/lobby.js LOBBY_DEFAULTS.maxSeats, 20 by default since 业主裁令 2026-10-12), so this is a SANITY CLAMP, not
 * policy: without it a bogus/hostile `seatCap` (1e9) loops 10⁹ times and dies with `RangeError: Invalid array length`
 * instead of drawing a room. Above it the extra seats are simply not drawn — they can hold nobody the client could
 * address anyway.
 */
const MAX_RENDERED_SEATS = 256;

/**
 * Seats padded to the room's capacity (co-op 4, solo 1, or the room's own `seatCap`), each null or a seat record.
 *
 * 座位容量 (100 人版移植, docs/PS100-MIGRATION.md §7): the cap comes from the ROOM (`room.state.seatCap`, sent only
 * when it differs from the official `MAX_SEATS` — so a 20-seat default room carries it and a 4-seat one does not),
 * never from a constant here — `seats` alone cannot tell "4 seats" from "100 seats with 96 empty". An absent/unusable
 * value keeps `MAX_SEATS` (a server too old to send the field is an official-room server, so this only ever
 * UNDER-asks), and anything above MAX_RENDERED_SEATS is clamped, so a 4-seat room renders exactly the four cards it
 * always did and a garbage cap cannot hang the tab.
 * @param {any} room room.state payload
 * @returns {(null | {seat:number, playerId:any, name:string, isBot:boolean, ready:boolean, connected:boolean})[]}
 */
export function normalizeSeats(room) {
  const declared = room?.seatCap;
  const cap = room?.mode === 'solo' ? 1
    : (Number.isInteger(declared) && declared >= 1 ? Math.min(declared, MAX_RENDERED_SEATS) : MAX_SEATS);
  const src = Array.isArray(room?.seats) ? room.seats : [];
  const out = [];
  for (let i = 0; i < cap; i++) {
    const s = src[i];
    out.push(s && typeof s === 'object' ? { ...s, seat: Number.isInteger(s.seat) ? s.seat : i } : null);
  }
  return out;
}

/**
 * Derived room facts for the local player.
 * @param {any} room
 * @param {any} myId
 */
export function roomFacts(room, myId) {
  const seats = normalizeSeats(room);
  const occupied = seats.filter(Boolean);
  const humans = occupied.filter((s) => !s.isBot);
  const mine = occupied.find((s) => s.playerId === myId) || null;
  const isHost = room?.hostId != null && room.hostId === myId;
  const others = humans.filter((s) => s.playerId !== myId);
  // The host never readies: starting the match is the host's ready (server rule), so the count
  // treats the host as ready — "已就绪 0/1" next to "准许进入模拟" would contradict itself.
  const isReady = (s) => !!s.ready || s.playerId === room?.hostId;
  const readyHumans = humans.filter(isReady).length;
  const othersReady = others.every((s) => s.ready && s.connected !== false);
  return {
    seats, occupied, humans, mine, isHost, readyHumans, isReady,
    emptySeats: seats.filter((s) => !s).length,
    canStart: isHost && othersReady && !!mine,
    othersReady,
    // spectator seats (never players: not in `humans`, never counted for ready / start)
    spectators: Array.isArray(room?.spectators) ? room.spectators.filter((s) => s && typeof s === 'object') : [],
    spectating: isSpectating(room, myId),
  };
}

/**
 * The co-op room option 「AI 队友最后选择」 (GitHub #338; room.setAiPicksLast, room.state.aiPicksLast): in the strategy and
 * 机变 drafts every human picks before the AI teammates. null in a solo room (no AI teammates); otherwise its state (off
 * when the server sends none) and whether this player may switch it — the host only, the others see it read-only.
 * @param {any} room room.state payload
 * @param {any} myId
 * @returns {{ on: boolean, editable: boolean } | null}
 */
export function aiLastOption(room, myId) {
  if (!room || room.mode === 'solo') return null;
  return { on: room.aiPicksLast === true, editable: room.hostId != null && room.hostId === myId };
}

/** Invite link for a room code (current page URL with ?room=CODE). */
export function inviteLink(code) {
  const loc = globalThis.location;
  const base = loc ? `${loc.origin}${loc.pathname}` : '';
  return `${base}?room=${encodeURIComponent(code)}${federationEnabled ? '&node='+currentNode() : ''}`;
}

/**
 * Copy text to the clipboard (async API with a textarea fallback for insecure contexts). Moved to ui/clipboard.js so
 * 干员调配 can use it without importing this screen (which imports loadout.js): re-exported here for existing callers.
 * @param {string} text
 * @returns {Promise<boolean>}
 */
export { copyText };

// 名片干员 portraits (the pick, else one chosen by the player id): ui/seatArt.js, shared with the strategy draft's rows
export { CARD_PREF, cardOperators, seatPortrait };
/** The server takes room.card (shared/protocol.js of the 10-seat package on): teammates then see one's pick. */
export const CARD_SYNC = !!C2S && Object.hasOwn(C2S, 'room.card');
// what else the server offers (its own shared/protocol.js): 开始搜寻 needs match.queue, 私密房间 room.setPrivate
const CAN_QUEUE = !!C2S && Object.hasOwn(C2S, 'match.queue');
const CAN_PRIVATE = !!C2S && Object.hasOwn(C2S, 'room.setPrivate');


/** 名片干员 picker: search, rarity, the operators' avatars; 默认 clears the pick. */
function CardPicker({ current, list, m, onPick, onClose }) {
  const [q, setQ] = useState('');
  const [star, setStar] = useState(0);
  const needle = q.trim().toLowerCase();
  const shown = list.filter((c) => (!star || c.rarity === star) && (!needle || String(c.name || '').toLowerCase().includes(needle)
    || String(c.appellation || '').toLowerCase().includes(needle)));
  return html`<${Modal} open=${true} title=${t('名片干员')} micro="SEAT CARD" onClose=${onClose} width="min(9.6rem, 94vw)" class="cardpick">
    <div class="cardpick__bar">
      <label class="cardpick__search"><${Icon} name="search" /><input type="search" value=${q} placeholder=${t('搜索干员')} onInput=${(e) => setQ(e.currentTarget.value)} /></label>
      <div class="cardpick__stars" role="radiogroup" aria-label=${t('稀有度')}>
        ${[[0, t('全部')], [6, '6★'], [5, '5★'], [4, '4★']].map(([v, label]) => html`<button key=${v} type="button" role="radio" aria-checked=${star === v ? 'true' : 'false'}
          class=${star === v ? 'is-on' : ''} onClick=${() => setStar(v)}>${label}</button>`)}
      </div>
    </div>
    <div class="cardpick__grid">
      <button type="button" class=${`cardpick__op cardpick__op--auto${!current ? ' is-on' : ''}`} onClick=${() => onPick('')} title=${t('按博士编号自动分配')}>
        <span class="cardpick__img"><${Icon} name="refresh" /></span><span class="cardpick__name">${t('默认')}</span></button>
      ${shown.map((c) => html`<button key=${c.charId} type="button" class=${`cardpick__op${current === c.charId ? ' is-on' : ''}`} onClick=${() => onPick(c.charId)} title=${c.name}>
        <span class="cardpick__img"><img src=${chessAvatarUrl(m, c)} alt="" loading="lazy" draggable=${false} /></span>
        <span class="cardpick__name">${c.name}</span>${c.rarity ? html`<span class=${`cardpick__star r${c.rarity}`}>${c.rarity}★</span>` : null}</button>`)}
    </div>
    <p class="cardpick__note"><${Icon} name="info" />${CARD_SYNC ? t('选择后，同盟里的博士都会看到这张立绘') : t('目前只有你自己看得到；服务器下次更新后，同盟里的其他博士也能看到你的选择')}</p>
  <//>`;
}

/**
 * 本房座位上限 (业主裁决 B5, docs/META.md §1.9) — the host's slider range for the room it is ALREADY in.
 *
 * `null` means "there is nothing to choose here, do not draw a slider at all": a solo room (its one-seat shape has no
 * cap to pick) and a room whose occupants already fill every legal seat (a slider with one stop is a dead control).
 *
 * The bounds are the SERVER's rules, mirrored so the host cannot drag into a refusal:
 *   * `max` = this server's ceiling (`welcome.maxSeats`, read through `serverSeatMaxOf`; `MAX_SEATS` 4 when the
 *     deployment said nothing), never below the room's current cap — a slider that cannot even show the current value
 *     would be lying about the room.
 *   * `min` = `max(MIN_SEATS, highest occupied seat + 1)`. That is exactly the server's eviction guard
 *     (`Lobby.setSeatCap` refuses `cap <= highest`), expressed on the frame the client actually holds, so every stop
 *     the host can reach is one the server accepts. It counts the HIGHEST OCCUPIED SEAT rather than the number of
 *     people, because seats may have holes (the creator leaving for good empties seat 0 while seat 2 stays taken) and
 *     a count would let the slider offer a cap that drops somebody at index 2.
 *
 * @param {any} room room.state payload
 * @param {number} serverMax the ceiling `welcome.maxSeats` announced (absent / unusable ⇒ MAX_SEATS)
 * @returns {{ min: number, max: number, value: number } | null}
 */
export function seatCapRoomRange(room, serverMax) {
  if (!room || room.mode === 'solo') return null;
  const seats = normalizeSeats(room);
  const cap = seats.length;
  const ceiling = Number.isInteger(serverMax) && serverMax >= 1 ? serverMax : MAX_SEATS;
  const max = Math.max(ceiling, cap);
  const highest = seats.reduce((m, s, i) => (s ? i : m), -1);
  const min = Math.min(Math.max(MIN_SEATS, highest + 1), max);
  if (max <= min) return null;
  return { min, max, value: Math.min(Math.max(cap, min), max) };
}

/**
 * The host's seat-count control INSIDE the room (`room.setSeatCap`, 业主裁决 B5). Rendered for the host only: for
 * everybody else the room already says how many seats it has through its seat cards, and `room.state.seatCap` is what
 * pads them (`normalizeSeats`).
 *
 * The server answers a refusal with a NAMED code (`SEAT_CAP_TOO_SMALL` when the new cap cannot hold the people already
 * here, `BAD_MSG` when the number itself is not a legal seat count), and `run` toasts it — the slider never silently
 * becomes a different number than the host asked for. `asked` keeps that request on screen until the room's own frame
 * agrees (or the request fails), so a slow round trip does not snap the control back under the host's finger.
 * @param {{ room: any, isHost: boolean, onPick: (n: number) => Promise<boolean> }} props
 */
function SeatCapSetter({ room, isHost, onPick }) {
  const range = isHost ? seatCapRoomRange(room, serverSeatMaxOf()) : null;
  const [asked, setAsked] = useState(null);
  useEffect(() => {
    if (asked != null && room && room.seatCap === asked) setAsked(null);
  }, [asked, room]);
  if (!range) return null;
  const shown = asked != null && asked >= range.min && asked <= range.max ? asked : range.value;
  const pct = Math.round(((shown - range.min) / (range.max - range.min)) * 100);
  const commit = async (v) => {
    const want = Math.min(Math.max(v, range.min), range.max);
    if (want === range.value) { setAsked(null); return; }
    setAsked(want);
    if (!(await onPick(want))) setAsked(null);   // the frame (or the refusal) is the truth again
  };
  return html`<div class="seat-cap seat-cap--room">
    <${MicroLabel} tone="mint">SEATS<//>
    <span class="seat-cap__name">${t('本房间人数上限')}</span>
    <input class="seat-cap__slider" type="range" min=${range.min} max=${range.max} step="1" value=${shown}
      style=${`--pct:${pct}%`} aria-label=${t('本房间人数上限')}
      aria-valuemin=${range.min} aria-valuemax=${range.max} aria-valuenow=${shown}
      title=${t('不能小于同盟内现有人数（含 AI 队友）')}
      onInput=${(e) => setAsked(Number(e.currentTarget.value))}
      onChange=${(e) => commit(Number(e.currentTarget.value))} />
    <span class="seat-cap__value num">${shown}<span class="t-dim"> / ${range.max}</span></span>
  </div>`;
}

function SeatCard({ seat, index, room, facts, myId, busy, onKick, onInvite, searching, portraits, onPickCard = null, onAddBot = null, onRemoveBot = null }) {
  const seatAccount = useAccount(seat && !seat.isBot ? seat.playerId : null);
  const [bad, setBad] = useState(null);
  const flash = useRise(!!seat && (seat.ready || seat.isBot || seat.playerId === room.hostId));
  if (!seat) {
    const invitable = room.mode !== 'solo' && !facts.spectating;
    return html`<article class=${`rseat rseat--empty${searching ? ' is-searching' : ''}`} style=${`--i:${index}`}>
      <span class="rseat__clip" aria-hidden="true"></span>
      <header class="rseat__strip"><i></i><span class="num">P${index + 1}</span></header>
      <div class="rseat__art">
        ${searching
          ? html`<span class="rseat__wait"><svg viewBox="0 0 40 48" aria-hidden="true"><path d="M20 2l5 5-5 5-5-5z" /><rect x="10" y="16" width="14" height="22" rx="3" /><path d="M24 22h10l-4 7 4 7H24" /></svg><small>STRONGHOLD PROTOCOL</small></span>`
          : invitable
            ? html`<button type="button" class="rseat__invite" onClick=${onInvite} title=${t('复制同盟密钥以邀请队友')}>
                <span class="rseat__plus" aria-hidden="true"></span><b>${t('邀请')}</b><small>${t('复制同盟密钥以邀请队友')}</small></button>`
            : html`<span class="rseat__wait"><small>${t('等待博士加入')}</small></span>`}
        <span class="rseat__noinfo" aria-hidden="true">NOINFO</span>
      </div>
      ${invitable && facts.isHost && onAddBot ? html`<button type="button" class="rseat__kick rseat__kick--bot" disabled=${busy === `add${index}`}
        onClick=${onAddBot} title=${t('添加 AI 队友')} aria-label=${t('添加 AI 队友')}><${Icon} name="robot" /><${Icon} name="plus" /></button>` : null}
      <div class="rseat__plate rseat__plate--empty" aria-hidden="true"></div>
    </article>`;
  }
  const isMe = seat.playerId === myId;
  const isHostSeat = seat.playerId === room.hostId;
  const offline = seat.connected === false && !seat.isBot;
  const ready = seat.ready || seat.isBot || isHostSeat;
  const src = seat.isBot ? null : seatPortrait(seat, portraits);
  const owner = isOwnerName(seat.name);
  const canPick = isMe && !seat.isBot && !!onPickCard;
  return html`<article class=${`rseat${ready ? ' is-ready' : ''}${flash ? ' is-flash' : ''}${isMe ? ' is-me' : ''}${isHostSeat ? ' is-host' : ''}${offline ? ' is-offline' : ''}${seat.isBot ? ' is-bot' : ''}`}
      style=${`--i:${index}`}>
    <span class="rseat__clip" aria-hidden="true"></span>
    <header class="rseat__strip"><i></i><span class="num">P${index + 1}</span></header>
    <div class=${`rseat__art${canPick ? ' is-pickable' : ''}`} onClick=${canPick ? onPickCard : undefined} title=${canPick ? t('点击更换名片干员') : undefined}>
      ${src && bad !== src ? html`<img src=${src} alt="" draggable=${false} loading="lazy" onError=${() => setBad(src)} />`
        : html`<span class="rseat__glyph">${seat.isBot ? html`<${Icon} name="robot" />` : [...(seat.name || '?')][0]}</span>`}
      ${canPick ? html`<button type="button" class="rseat__pick" onClick=${(e) => { e.stopPropagation(); onPickCard(); }} aria-label=${t('更换名片干员')}><${Icon} name="edit" /><span>${t('更换立绘')}</span></button>` : null}
      ${isHostSeat ? html`<span class="rseat__host">${t('创建者')}</span>` : null}
      ${offline ? html`<span class="rseat__lost"><${Icon} name="wifiOff" />${t('失去信号')}</span>` : null}
      <span class="rseat__state">${ready
        ? html`<span class="rseat__box"><${Icon} name="check" /></span>${isHostSeat && !seat.ready ? t('待命中') : t('已就绪')}`
        : html`<span class="rseat__box"></span>${t('准备中')}`}</span>
    </div>
    ${!seat.isBot && !isMe && facts.isHost ? html`<button type="button" class="rseat__kick" disabled=${busy === `kick${index}`}
      onClick=${() => onKick(index, seat.name, seat.playerId)} title=${t('将该博士移出同盟')} aria-label=${t('移出该博士')}><${Icon} name="user" /><${Icon} name="close" /></button>` : null}
    ${seat.isBot && facts.isHost && onRemoveBot ? html`<button type="button" class="rseat__kick rseat__kick--bot" disabled=${busy === `rm${index}`}
      onClick=${() => onRemoveBot(index)} title=${t('移除 AI 队友')} aria-label=${t('移除 AI 队友')}><${Icon} name="robot" /><${Icon} name="close" /></button>` : null}
    <div class=${`rseat__plate${seatAccount?.card ? ' has-nc' : ''}`}>
      <${NameCardLayer} card=${seatAccount?.card} />
      ${isMe ? html`<span class="rseat__me" title=${t('你')}><${Icon} name="info" /></span>` : null}
      <${AvatarFrame} size="sm" name=${seat.name} src=${seatAccount?.avatar || undefined} seat=${index} bot=${seat.isBot} self=${isMe} />
      <span class="rseat__who">
        <${TrophyBadge} count=${seatAccount?.trophies} class="tbadge--inline" /><b class=${`rseat__name${owner ? ' sp-owner-name' : ''}`}>${seat.name || t('博士')}</b><${AccountTag} playerId=${seat.isBot ? null : seat.playerId} />
        ${owner ? html`<span class="sp-owner-badge">${t('服主')}</span>` : null}
      </span>
      <small class="rseat__doc">${seat.isBot ? 'AUTONOMOUS UNIT' : `DOCTOR #${doctorNo(seat.playerId)}`}</small>
    </div>
  </article>`;
}

/** 观战席: the room's spectators (host: ✕ frees a seat), and 入座 for a spectator while a player seat is free. */
function SpectatorBar({ facts, myId, busy, onRemove, onSit }) {
  if (!facts.spectators.length) return null;
  return html`<section class="specbar" aria-label=${t('观战席')}>
    <span class="specbar__label"><${Icon} name="eye" />${t('观战席')}<b class="num">${facts.spectators.length}</b><span class="num t-dim">/${MAX_SPECTATORS}</span></span>
    ${facts.spectators.map((s) => html`<span key=${s.playerId} class=${`specbar__who${s.playerId === myId ? ' is-me' : ''}${s.connected === false ? ' is-offline' : ''}`}>
      ${s.connected === false ? html`<${Icon} name="wifiOff" />` : null}${s.name || t('博士')}${s.playerId === myId ? html`<span class="seat__you">${t('你')}</span>` : null}
      ${facts.isHost ? html`<${Button} variant="ghost" size="sm" square=${true} icon="close" loading=${busy === `rs${s.playerId}`}
        onClick=${() => onRemove(s.playerId)} aria-label=${t('移出观战者 {name}', { name: s.name || '' })} title=${t('移出该观战者')} />` : null}
    </span>`)}
    ${facts.spectating && facts.emptySeats > 0 ? html`<${Button} size="sm" icon="user" loading=${busy === 'sit'} onClick=${onSit}>${t('入座')}<//>` : null}
  </section>`;
}

/** The 「AI 队友最后选择」 switch (co-op): the host toggles it, everybody else sees its state. */
function AiLastToggle({ option, busy, onToggle }) {
  if (!option) return null;
  return html`<div class="ailast">
    <${Tooltip} text=${t('策略与机变轮选时，所有博士先于 AI 队友选择')}>
      <button type="button" role="switch" aria-checked=${option.on ? 'true' : 'false'}
          class=${`dpick__opt ailast__opt${option.on ? ' is-active' : ''}`} disabled=${!option.editable || !!busy}
          onClick=${() => option.editable && onToggle(!option.on)}>
        <${Icon} name="check" class=${option.on ? 'is-on' : ''} />${t('AI 队友最后选择')}
      </button>
    <//>
    ${option.editable ? null : html`<span class="t-dim">${t('由创建者设置')}</span>`}
  </div>`;
}

/**
 * 对局选项 (this fork): the room options panel — three tabs, host-only before the match, everyone else read-only.
 *   敌方强化 ENEMY  the four enemy sliders (怪物血量/攻击/防御/魔抗; room.setTuning → MatchCombat._sanitizeSpawns)
 *   我方增益 ALLY   the five operator sliders (干员生命/攻击/护甲/魔抗/攻速; room.setBuffs → spec.players[].buffs
 *                   → sim units.js, OPERATORS only)
 *   全局设置 GLOBAL two toggles (盟约层数上限解除 / 盟约定向刷新; room.setFlags → Match.flags)
 * One step of every slider is +10%, up to TUNING_MAX / OPS_BUFF_MAX steps (= +100%). Dragging fires many inputs, so
 * each slider group keeps a local draft and sends ONE request a moment after the drag stops (the server's broadcast
 * then overwrites the draft anyway).
 */
const TUNING_ROWS = Object.freeze([
  { k: 'hp', name: '怪物血量', micro: 'HP', icon: 'plus' },
  { k: 'atk', name: '怪物攻击', micro: 'ATK', icon: 'sword' },
  { k: 'def', name: '怪物防御', micro: 'DEF', icon: 'shield' },
  { k: 'res', name: '怪物魔抗', micro: 'RES', icon: 'snow' },
]);

const BUFF_ROWS = Object.freeze([
  { k: 'hp', name: '干员生命', micro: 'HP', icon: 'plus' },
  { k: 'atk', name: '干员攻击', micro: 'ATK', icon: 'sword' },
  { k: 'def', name: '干员护甲', micro: 'DEF', icon: 'shield' },
  { k: 'res', name: '干员魔抗', micro: 'RES', icon: 'snow' },
  { k: 'aspd', name: '干员攻速', micro: 'ASPD', icon: 'chevrons' },
]);

/** 开关设置 · 海克斯设置页（this fork, 自全局设置拆分）：海克斯草案的全部选项集中一页。 */
// 对局选项 · 全局设置 `morphPlus`（v0.05.2）：房间开关决定客户端这一局的变形同构体档位 ——
// 与服务端同源（服务端在 Match 构造时按同一个 flag 覆盖），避免「客户端按 plus 画、服务端按 official 拒」。
let _morphPlusSeen = null;
function syncMorphPlusFlag(flags) {
  const on = !flags || flags.morphPlus !== false;
  if (_morphPlusSeen === on) return;
  _morphPlusSeen = on;
  const option = on ? 'plus' : 'official';
  try { applyMorphPairing(option); applyMorphSlotPolicy(option); } catch { /* 老宿主没有这两个导出 */ }
}

const HEX_FLAG_ROWS = Object.freeze([
  { k: 'hexEnabled', name: '启用海克斯', micro: 'HEX', desc: '关闭后本局不出现海克斯三选一' },
  { k: 'hexTriple', name: '三海克斯局', micro: '3 HEX', desc: '海克斯改在第 1 / 5 / 9 回合共发放三次（默认 1 / 7 两次）；「自选海克斯」上限随之为 3 条' },
]);

/** 开关设置 · 全局设置页（this fork）：盟约 / 无尽等非海克斯的全局规则。 */
const GLOBAL_FLAG_ROWS = Object.freeze([
  { k: 'bondLayerUncap', name: '盟约层数上限解除', micro: 'LAYER CAP', desc: '解除 999 层上限，层数可一直叠' },
  { k: 'morphPlus', name: '装备拓展', micro: 'EQUIP+', beta: '0.1', desc: '变形同构体不占装备栏、每名干员最多一件、只与最左侧道具配对；进阶（升星）干员多一格装备位（关闭 = 引擎原版）' },
  { k: 'bondShopBias', name: '盟约定向刷新', micro: 'SHOP BIAS', desc: '商店 20% 概率按已激活盟约定向抽干员' },
  { k: 'endless', name: '无尽模式', micro: 'ENDLESS', desc: '原层数打完后每 5 关进行一次 Boss，期间每关敌人所有属性 +20% 累进（无上限）；所有盟约层数解锁无上限', beta: 'BETA 0.1' },
  { k: 'keepFunds', name: '回合结束保留资金', micro: 'KEEP FUNDS', desc: '休整期结束时不再清空剩余资金，可以存钱（开启无尽模式时自动开启）' },
  { k: 'buySlot', name: '购买上阵栏位', micro: 'BUY SLOT', desc: '开局后可在局内花 25 / 50 / 75 资金购买 3 个额外上阵栏位（生命值旁出现购买按钮）' },
]);

const OPT_TABS = Object.freeze([
  { k: 'enemy', name: '敌方强化', micro: 'ENEMY', icon: 'warn' },
  { k: 'ally', name: '我方增益', micro: 'ALLY', icon: 'sword' },
  { k: 'global', name: '全局设置', micro: 'GLOBAL', icon: 'info' },
  { k: 'hex', name: '海克斯设置', micro: 'HEX', icon: 'book' },
]);

/** 一条滑动行（敌方 / 我方两组共用）：label + range + `+N%`。 */
function OptSlider({ row, value, max, disabled, onInput }) {
  return html`<label class="opts__row${disabled ? ' is-ro' : ''}">
    <span class="opts__label"><${Icon} name=${row.icon} />${t(row.name)}<${MicroLabel}>${row.micro}<//></span>
    <input class="opts__range" type="range" min="0" max=${max} step="1" value=${value}
      style=${`--pct:${(value / max) * 100}%`} disabled=${disabled}
      aria-label=${t('{name} +{n}%', { name: t(row.name), n: value * 10 })}
      onInput=${(e) => onInput(row.k, Number(e.currentTarget.value))} />
    <span class=${`opts__val num${value > 0 ? ' is-on' : ''}`}>+${value * 10}%</span>
  </label>`;
}

/** 一组滑动条（本地草稿 + 停止拖动 220ms 后一次性下发）。 */
function SliderPane({ rows, value, norm, max, disabled, onSend, hint, warn }) {
  const [draft, setDraft] = useState(() => norm(value));
  const timer = useRef(0);
  useEffect(() => () => clearTimeout(timer.current), []);
  // the server's broadcast wins: another change (or a clamp) resets the local draft
  useEffect(() => { setDraft(norm(value)); }, [value]);
  const drag = (k, v) => {
    if (disabled) return;
    const next = { ...draft, [k]: v };
    setDraft(next);
    clearTimeout(timer.current);
    timer.current = setTimeout(() => onSend(next), 220);
  };
  const total = rows.reduce((a, r) => a + (norm(value)[r.k] || 0), 0);
  return html`<div class="opts__pane">
    <p class="opts__hint">${hint}</p>
    <div class="opts__grid">
      ${rows.map((r) => html`<${OptSlider} key=${r.k} row=${r} value=${draft[r.k] || 0} max=${max} disabled=${disabled} onInput=${drag} />`)}
    </div>
    ${total > 0 ? html`<p class="opts__warn t-orange">${warn(total * 10)}</p>` : null}
  </div>`;
}


/** 开关行（海克斯/全局两页共用）：switch + 名称/说明 + 右侧插槽 + BETA 角标。 */
function FlagRow({ f, on, disabled, onToggle, children }) {
  return html`<div class="opts__flag">
    <button type="button" role="switch" aria-checked=${on ? 'true' : 'false'} disabled=${disabled}
      class=${`opts__switch${on ? ' is-on' : ''}`} onClick=${onToggle}>
      <i></i><span>${on ? t('开启') : t('关闭')}</span>
    </button>
    <span class="opts__flagtext">
      <b>${t(f.name)}<${MicroLabel} tone=${f.beta ? 'gold' : 'mint'}>${f.micro}<//></b><span>${t(f.desc)}</span>
    </span>
    ${children}
    ${f.beta ? html`<span class="opts__beta num" title=${t('该模式尚在测试，可能遇到 bug，谨慎游玩')}>${typeof f.beta === 'string' ? f.beta : t('BETA')}</span>` : null}
  </div>`;
}

/** 时长行（数字输入，0/清空 = 官方默认；下发防抖由父级 sendTimers 处理）。 */
function SecRow({ label, micro, hint, value, disabled, min, max, onNew }) {
  return html`<div class="opts__flag">
    <span class="opts__flagtext"><b>${t(label)}<${MicroLabel}>${micro}<//></b><span>${t(hint)}</span></span>
    <input class="opts__num num" type="number" min=${min} max=${max} value=${value || ''} placeholder=${t('默认')}
      disabled=${disabled} aria-label=${t(label)}
      onInput=${(e) => { const v = Math.max(0, Math.min(max, Math.trunc(Number(e.currentTarget.value) || 0))); onNew(v); }} />
    <span class="opts__val num">${value > 0 ? `${value}s` : t('默认')}</span>
  </div>`;
}

/** 海克斯设置（this fork, 自全局设置拆分为独立页签）：草案开关 / 三海克斯局 / 自选海克斯 / 草案等级 / 选择时长。 */
function HexPane({ room, disabled, onSend, onGrade, onHexPicks, onNoRepeat = () => {}, hexSec, onHexSec, myId = null, isHost = false }) {
  const [draft, setDraft] = useState(() => normalizeRoomFlags(room.flags));
  const [codex, setCodex] = useState(false);
  const [codexPick, setCodexPick] = useState(false);
  useEffect(() => { setDraft(normalizeRoomFlags(room.flags)); }, [room.flags]);
  const toggle = (k) => {
    if (disabled) return;
    const next = { ...draft, [k]: !draft[k] };
    setDraft(next);
    onSend(next);
    // 关掉三海克斯局时，超出数量的自选队列截断到新的草案数（服务端 ≤3 兜底）
    if (k === 'hexTriple' && Array.isArray(room.hexPicks)) {
      const max = next.hexTriple ? 3 : 2;
      if (room.hexPicks.length > max) onHexPicks(room.hexPicks.slice(0, max));
    }
  };
  // 海克斯等级 (v0.03.3, 用户要求)：改成**一组四个按钮**（随机 / 白银 / 黄金 / 炫彩）。
  // 未开自选时：依次点击，第 1 次点到的等阶给第 1 次海克斯、第 2 次给第 2 次、第 3 次给第 3 次……
  // 按钮上的数字 = 该等阶占的是「第几次」（三海克斯局才有第 3 次）。
  const drafts = draft.hexTriple ? 3 : 2;
  const grades = [room.hexGrade1 || HEX_GRADE_RANDOM, room.hexGrade2 || HEX_GRADE_RANDOM, room.hexGrade3 || HEX_GRADE_RANDOM].slice(0, drafts);
  const filledSlots = grades.filter((g) => g !== HEX_GRADE_RANDOM).length;
  const nextSlot = useRef(filledSlots >= drafts ? 1 : filledSlots + 1);
  const assignGrade = (g) => {
    if (disabled) return;
    const slot = Math.min(drafts, Math.max(1, nextSlot.current));
    const next = grades.slice();
    next[slot - 1] = g;
    nextSlot.current = slot >= drafts ? 1 : slot + 1;
    onGrade(next[0] || HEX_GRADE_RANDOM, next[1] || HEX_GRADE_RANDOM, next[2] || HEX_GRADE_RANDOM);
  };
  const resetGrades = () => {
    nextSlot.current = 1;
    onGrade(HEX_GRADE_RANDOM, HEX_GRADE_RANDOM, HEX_GRADE_RANDOM);
  };
  const slotsOf = (g) => grades.map((x, i) => (x === g ? i + 1 : 0)).filter(Boolean);
  // v0.04.3：自选队列**每人各一份**（room.setHexPicks 对成员开放）——自己有就用自己的，没有时房主回落到房间主队列
  const ownPicks = myId && room.hexPicksBy ? room.hexPicksBy[myId] : null;
  const hexPicks = Array.isArray(ownPicks) ? ownPicks : (isHost && Array.isArray(room.hexPicks) ? room.hexPicks : []);
  // 自选海克斯 (this fork)：普通双海克斯局也能用 —— 上限随三海克斯局开关自适应（双 2 条 / 三 3 条）
  const pickMax = draft.hexTriple ? 3 : 2;
  return html`<div class="opts__pane">
    <p class="opts__hint">${t('本局的海克斯规则 · 开局后不可更改')}</p>
    ${HEX_FLAG_ROWS.map((f) => html`<${FlagRow} key=${f.k} f=${f} on=${draft[f.k]} disabled=${disabled} onToggle=${() => toggle(f.k)}>
      ${f.k === 'hexEnabled' ? html`<button type="button" class="opts__codex" disabled=${disabled}
        onClick=${() => { setCodexPick(false); setCodex(true); }}>
        <${Icon} name="book" />${t('图鉴')}
      </button>` : null}
    <//>`)}
    <div class="opts__flag">
      <span class="opts__flagtext"><b>${t('自选海克斯')}<${MicroLabel} tone="mint">PICK<//></b>
        <span>${t('从图鉴指定本局海克斯，按顺序在草案回合自动发放（上限随三海克斯局：双 2 条 / 三 3 条）')}</span></span>
      <button type="button" class=${`opts__codex${hexPicks.length ? ' is-on' : ''}`} disabled=${!draft.hexEnabled || (disabled && !draft.hexEnabled)}
        onClick=${() => { setCodex(false); setCodexPick(true); setCodex(true); }}>
        <${Icon} name="book" />${t('选择')}<span class="num"> ${hexPicks.length}/${pickMax}</span>
      </button>
    </div>
    <div class="opts__flag">
      <span class="opts__flagtext"><b>${t('海克斯等级')}<${MicroLabel} tone="mint">GRADE<//></b>
        <span>${t('依次点击：第 1 次点到给第 1 次海克斯、第 2 次给第 2 次……（随机 = 三档等概率掷骰）；按钮上的数字是「第几次」')}</span></span>
      <button type="button" class="opts__grade-reset" disabled=${disabled} onClick=${resetGrades}>${t('重置')}</button>
    </div>
    <div class="opts__grades" role="group" aria-label=${t('海克斯等级')}>
      ${HEX_GRADE_CHOICES.map((g) => {
        const slots = slotsOf(g);
        return html`<button key=${g} type="button" class=${`opts__gradebtn${slots.length ? ' is-on' : ''}`}
          disabled=${disabled} style=${HEX_GRADE_COLOR[g] ? `--gc:${HEX_GRADE_COLOR[g]}` : null}
          onClick=${() => assignGrade(g)}>
          <span class="opts__gradebtn-name">${t(g === HEX_GRADE_RANDOM ? '随机' : (HEX_GRADE_NAME[g] || g))}</span>
          ${slots.map((n) => html`<i key=${n} class="opts__gradebtn-badge num">${n}</i>`)}
        </button>`;
      })}
    </div>
    ${/* 稀有度不重复 (v0.03.3, 玩家反馈已采纳)：只在三个等阶槽**全是随机**时可用；不开 = 现在的按权重随机 */''}
    <${FlagRow} f=${{ k: 'hexNoRepeat', name: '稀有度不重复', micro: 'NO REPEAT',
        desc: '每次海克斯的稀有度都与上一次不同（白银→黄金→炫彩顺延）；仅当上面等阶全部为「随机」时可用（不开启 = 按权重随机）' }}
      on=${room.hexNoRepeat === true} disabled=${disabled || grades.some((g) => g !== HEX_GRADE_RANDOM)}
      onToggle=${() => onNoRepeat(!(room.hexNoRepeat === true))} />
    ${room.mode !== 'solo' ? html`<${SecRow} label="海克斯选择时长" micro="HEX TIME"
      hint="三选一的倒计时秒数（10–120；清空 = 官方默认 15/25 秒；仅联合模式可设定）"
      value=${hexSec} disabled=${disabled} min=${10} max=${120} onNew=${onHexSec} />` : null}
    ${codex ? html`<${HexCodex} onClose=${() => setCodex(false)}
      ...${(codexPick ? { picked: hexPicks, pickMax, onPickDone: (ids) => onHexPicks(ids) } : {})} />` : null}
  </div>`;
}

/** 全局设置（this fork, 海克斯拆出后）：盟约规则 / 无尽模式 / 准备回合时长。 */
function GlobalPane({ room, disabled, onSend, prepSec, onPrepSec }) {
  const [draft, setDraft] = useState(() => normalizeRoomFlags(room.flags));
  useEffect(() => { setDraft(normalizeRoomFlags(room.flags)); }, [room.flags]);
  const toggle = (k) => {
    if (disabled) return;
    const next = { ...draft, [k]: !draft[k] };
    // 无尽模式默认开「回合结束保留资金」(用户要求)：打开无尽时一并打开存钱（之后仍可单独关掉）
    if (k === 'endless' && next.endless) next.keepFunds = true;
    setDraft(next);
    onSend(next);
  };
  return html`<div class="opts__pane">
    <p class="opts__hint">${t('本局生效的全局规则 · 开局后不可更改')}</p>
    ${GLOBAL_FLAG_ROWS.map((f) => html`<${FlagRow} key=${f.k} f=${f} on=${draft[f.k]} disabled=${disabled} onToggle=${() => toggle(f.k)} />`)}
    ${room.mode !== 'solo' ? html`<div class="opts__timers">
      <p class="opts__hint">${t('房间时长 · 只对本房间的联合模式生效（独立模拟不可设定）')}</p>
      <${SecRow} label="准备回合时长" micro="PREP TIME"
        hint="准备阶段的倒计时秒数（15–600；清空 = 数据表默认；本就不限时的回合保持不限时）"
        value=${prepSec} disabled=${disabled} min=${15} max=${600} onNew=${onPrepSec} />
    </div>` : null}
  </div>`;
}

/** 对局选项面板（紧凑版）：默认收起成一条细栏（占一条标题行的高度），点开后是**竖排单列**的窄卡 ——
 *  滑条逐行堆叠、开关与等级设定纵向排列，不再横向铺满整行挤压房间原有的布局。
 *  收起时标题栏右侧显示摘要徽章（敌+X% / 我+X% / 层数∞ / 定向刷 / 海克斯关 / 一·黄金 …），不开面板也能一眼看到当前设置。 */
/**
 * ── 对局选项「保存方案」(this fork, v0.03.2, 用户要求) ─────────────────────────────────────────
 * 把房间当前的对局选项整份存进 localStorage；下次开房间时由房主（含独立模拟）自动套用。
 * 只存客户端能下发的部分：开关旗子 / 双方滑条 / 自选海克斯 / 两次草案等级 / 时长。
 */
const ROOM_PRESET_KEY = 'sp-hexmod-room-preset';

/** 读取保存的方案（无 / 脏数据 → null）。 */
function loadRoomPreset() {
  try {
    const raw = localStorage.getItem(ROOM_PRESET_KEY);
    if (!raw) return null;
    const p = JSON.parse(raw);
    return p && typeof p === 'object' ? p : null;
  } catch { return null; }
}

/** 保存当前房间的对局选项；返回是否成功（浏览器禁用存储时 false）。 */
function saveRoomPreset(room) {
  try {
    localStorage.setItem(ROOM_PRESET_KEY, JSON.stringify({
      at: Date.now(),
      flags: normalizeRoomFlags(room.flags),
      tuning: normalizeTuning(room.tuning),
      buffs: normalizeOpsBuffs(room.buffs),
      hexPicks: Array.isArray(room.hexPicks) ? room.hexPicks.slice() : [],
      hexGrade1: room.hexGrade1 || HEX_GRADE_RANDOM,
      hexGrade2: room.hexGrade2 || HEX_GRADE_RANDOM,
      hexGrade3: room.hexGrade3 || HEX_GRADE_RANDOM,
      hexNoRepeat: room.hexNoRepeat === true,
      hexChoiceSec: Number(room.hexChoiceSec) || 0,
      prepSec: Number(room.prepSec) || 0,
    }));
    return true;
  } catch { return false; }
}

/** 清除保存的方案。 */
function clearRoomPreset() {
  try { localStorage.removeItem(ROOM_PRESET_KEY); } catch { /* 忽略 */ }
}

/** 非默认设置的条数（方形按钮上的小角标）。 */
function OPT_CHIP_COUNT(room) {
  const tn = normalizeTuning(room.tuning), bn = normalizeOpsBuffs(room.buffs), fl = normalizeRoomFlags(room.flags);
  let n = 0;
  for (const k of TUNING_STATS) n += (tn[k] || 0) ? 1 : 0;
  for (const k of OPS_BUFF_STATS) n += (bn[k] || 0) ? 1 : 0;
  if (fl.bondLayerUncap) n++;
  if (fl.bondShopBias) n++;
  if (!fl.hexEnabled) n++;
  if (fl.hexTriple) n++;
  if (fl.endless) n++;
  if (fl.keepFunds) n++;
  if (fl.buySlot) n++;
  if (Array.isArray(room.hexPicks) && room.hexPicks.length) n++;
  for (const g of [room.hexGrade1, room.hexGrade2, room.hexGrade3]) if (g && g !== HEX_GRADE_RANDOM) n++;
  if (room.hexNoRepeat === true) n++;
  return n;
}

function OptionsPanel({ room, isHost, myId = null, busy, onTuning, onBuffs, onFlags, onGrade, onHexPicks, onTimers, onNoRepeat = () => {}, mode = 'inline' }) {
  const [tab, setTab] = useState('enemy');
  const [open, setOpen] = useState(false);
  // 非房主也能「尝试」操作：发送层（RoomScreen 的 hostOnly 包装）会弹提示且不发请求，服务端再有 NOT_HOST 兜底
  const disabled = !!busy;
  const active = OPT_TABS.find((x) => x.k === tab) || OPT_TABS[0];
  // 房间设置 · 时长 (this fork, 仅联合模式)：状态收在面板层（海克斯/全局两页各取所需），
  // 数字输入停止 500ms 后一次性下发（0/清空 = 官方默认）
  const [hexSec, setHexSec] = useState(() => room.hexChoiceSec || 0);
  const [prepSec, setPrepSec] = useState(() => room.prepSec || 0);
  useEffect(() => { setHexSec(room.hexChoiceSec || 0); setPrepSec(room.prepSec || 0); }, [room.hexChoiceSec, room.prepSec]);
  const timer = useRef(0);
  useEffect(() => () => clearTimeout(timer.current), []);
  const sendTimers = (hex, prep) => {
    clearTimeout(timer.current);
    timer.current = setTimeout(() => onTimers({ hexChoice: hex > 0 ? hex : 0, prep: prep > 0 ? prep : 0 }), 500);
  };
  const onHexSec = (v) => { setHexSec(v); sendTimers(v, prepSec); };
  const onPrepSec = (v) => { setPrepSec(v); sendTimers(hexSec, v); };
  // 收起时的摘要：把当前非默认的设置压成几个小徽章
  const tn = normalizeTuning(room.tuning), bn = normalizeOpsBuffs(room.buffs), fl = normalizeRoomFlags(room.flags);
  const chips = [];
  const tsum = TUNING_STATS.reduce((a, k) => a + (tn[k] || 0), 0);
  const bsum = OPS_BUFF_STATS.reduce((a, k) => a + (bn[k] || 0), 0);
  if (tsum) chips.push(`敌 +${tsum * 10}%`);
  if (bsum) chips.push(`我 +${bsum * 10}%`);
  if (fl.bondLayerUncap) chips.push('层数∞');
  if (fl.bondShopBias) chips.push('定向刷');
  if (!fl.hexEnabled) chips.push('海克斯关');
  if (fl.hexTriple) chips.push('三海克斯');
  if (fl.endless) chips.push('无尽·BETA0.1');
  if (fl.keepFunds) chips.push('存钱');
  if (fl.buySlot) chips.push('购栏位');
  if (Array.isArray(room.hexPicks) && room.hexPicks.length) chips.push(`自选 ${room.hexPicks.length}`);
  if (room.hexNoRepeat === true) chips.push('稀有度不重复');
  for (const [i, g] of [room.hexGrade1, room.hexGrade2, room.hexGrade3].entries()) {
    if (g && g !== HEX_GRADE_RANDOM) chips.push(`${i ? '二·' : '一·'}${t(HEX_GRADE_NAME[g])}`);
  }
  // 面板本体（两种用法共用）：mode='modal' 时只给内容 —— 房间页把「对局选项」集成到了
  // 「开始模拟」左侧的方形按钮里，点开是一个弹层（用户要求，v0.03.2）
  const body = html`<div class=${`opts__open${mode === 'modal' ? ' is-modal' : ''}`}>
      <nav class="opts__tabs" role="tablist" aria-label=${t('对局选项分类')}>
        ${OPT_TABS.map((x) => html`<button key=${x.k} type="button" role="tab" aria-selected=${tab === x.k ? 'true' : 'false'}
          class=${`opts__tab${tab === x.k ? ' is-active' : ''}`} onClick=${() => setTab(x.k)}>
          <${Icon} name=${x.icon} />${t(x.name)}
        </button>`)}
      </nav>
      <div class="opts__body" role="tabpanel" aria-label=${t(active.name)}>
        ${tab === 'enemy' ? html`<${SliderPane} rows=${TUNING_ROWS} value=${room.tuning} norm=${normalizeTuning} max=${TUNING_MAX}
          disabled=${disabled} onSend=${onTuning}
          hint=${t('每格 +10%，最高 +100% · 强化本局全部敌人')}
          warn=${(n) => t('敌人已强化 {total}%', { total: n })} />`
      : tab === 'ally' ? html`<${SliderPane} rows=${BUFF_ROWS} value=${room.buffs} norm=${normalizeOpsBuffs} max=${OPS_BUFF_MAX}
          disabled=${disabled} onSend=${onBuffs}
          hint=${t('每格 +10%，最高 +100% · 只加强干员（召唤物不受益）')}
          warn=${(n) => t('干员已增益 {total}%', { total: n })} />`
      : tab === 'global' ? html`<${GlobalPane} room=${room} disabled=${disabled} onSend=${onFlags} prepSec=${prepSec} onPrepSec=${onPrepSec} />`
      : html`<${HexPane} room=${room} disabled=${disabled} onSend=${onFlags} onGrade=${onGrade} onHexPicks=${onHexPicks}
          onNoRepeat=${onNoRepeat} hexSec=${hexSec} onHexSec=${onHexSec} myId=${myId} isHost=${isHost} />`}
      </div>
      ${!isHost ? html`<p class="opts__note">${t('由创建者设置')}</p>` : null}
</div>`;
  if (mode === 'modal') return body;
  return html`<section class=${`opts brackets${open ? ' is-open' : ''}`} aria-label=${t('对局选项')}>
    <button type="button" class="opts__bar" aria-expanded=${open ? 'true' : 'false'} onClick=${() => setOpen(!open)}>
      <span class="opts__title"><${Icon} name="info" />${t('对局选项')}<${MicroLabel}>MATCH OPTIONS<//></span>
      <span class="opts__chips">${chips.map((c) => html`<i key=${c} class="opts__chip num">${c}</i>`)}</span>
      <span class=${`opts__chev${open ? ' is-open' : ''}`} aria-hidden="true">▾</span>
    </button>
    ${open ? body : null}
  </section>`;
}

/** mm:ss of a duration in seconds. */
const clock = (s) => `${String(Math.floor(Math.max(0, s) / 60)).padStart(2, '0')}:${String(Math.floor(Math.max(0, s)) % 60).padStart(2, '0')}`;

/** 选择模拟协议 over the room (host): the difficulty cards and 确认. */
function RoomProtocol({ room, variant, onClose, onPick, busy, leaving = false }) {
  const [pick, setPick] = useState(room.difficulty);
  useEffect(() => {
    const onKey = (e) => { if (e.key === 'Escape') { e.stopPropagation(); onClose(); } };
    addEventListener('keydown', onKey);
    return () => removeEventListener('keydown', onKey);
  }, []);
  return html`<div class=${`rs-proto${leaving ? ' is-leaving' : ''}`} style=${`--d-color:${DIFFICULTY_COLORS[pick]}`} role="dialog" aria-label=${t('选择模拟协议')}
      onMouseDown=${(e) => { if (e.target === e.currentTarget) onClose(); }}>
    <div class="rs-proto__scene" aria-hidden="true"><${ProtocolScene} key=${pick} difficulty=${pick} /></div>
    <section class="rs-proto__side">
      <h2 class="rs-proto__title">${t('选择模拟协议')}</h2>
      <div class="proto-list rs-proto__list" role="radiogroup" aria-label=${t('模拟难度')}>
        ${DIFFICULTIES.map((d) => html`<${ProtoCard} key=${d} roomMode=${room.mode} difficulty=${d} selected=${pick === d} onSelect=${setPick}
          random=${room.random === true} variant=${variant} />`)}
      </div>
      <button type="button" class="proto-start rs-proto__ok" disabled=${!!busy} onClick=${() => (pick === room.difficulty ? onClose() : onPick(pick))}>
        <span class="proto-start__mark" aria-hidden="true"><span class="proto-start__rook"><i>[</i><${Icon} name="rook" /><i>]</i></span><small>STRONGHOLD<br />PROTOCOL</small></span>
        <span class="proto-start__label">${busy === 'diff' ? html`<${Spinner} size="sm" />` : null}${t('确认')}</span>
        <span class="proto-start__deco" aria-hidden="true"></span>
      </button>
    </section>
  </div>`;
}

/** ⚙ of the bottom pill: 私密房间, 人数上限 (with the 10-seat constants), AI 队友最后选择, 无限火力 branch. */
function RoomOptions({ room, facts, myId, busy, online, variant, onPrivate, onSeatCap, onAiLast, onVariant, onClose, leaving = false }) {
  const coop = room.mode !== 'solo';
  const host = facts.isHost;
  useEffect(() => {
    const away = (e) => { if (!e.target.closest?.('.rs-opts, .rs-pill__gear')) onClose(); };
    const onKey = (e) => { if (e.key === 'Escape') { e.stopPropagation(); onClose(); } };
    addEventListener('pointerdown', away); addEventListener('keydown', onKey);
    return () => { removeEventListener('pointerdown', away); removeEventListener('keydown', onKey); };
  }, []);
  return html`<div class=${`rs-opts${leaving ? ' is-leaving' : ''}`} role="dialog" aria-label=${t('同盟设置')}>
    <h4>${t('同盟设置')}${host ? null : html`<small>${t('由创建者设置')}</small>`}</h4>
    ${coop && CAN_PRIVATE ? html`<label class="rs-opt"><input type="checkbox" checked=${room.private === true} disabled=${!host || !!busy || !online} onChange=${(e) => onPrivate(e.currentTarget.checked)} />
      <span>${t('私密房间')}<small>${room.private ? t('仅凭同盟密钥或邀请加入，不能搜寻队友') : t('公开大厅可见，可以搜寻队友')}</small></span></label>` : null}
    <${SeatCapSetter} room=${room} isHost=${host} onPick=${onSeatCap} />
    <${AiLastToggle} option=${aiLastOption(room, myId)} busy=${busy} onToggle=${onAiLast} />
    ${room.random === true ? html`<div class="rs-opt rs-opt--variant"><span>${t('模式分支')}</span>
      <div class="dpick" role="radiogroup" aria-label=${t('模式分支')}>
        ${[['blitz', t('快速突袭 {totalRounds} 回合', { totalRounds: RANDOM_MODE.totalRounds })], ['endurance', t('持久鏖战 {totalRounds} 回合', { totalRounds: RANDOM_MODE.endurance.totalRounds })], ['marathon', t('最长时赛 {totalRounds} 回合', { totalRounds: RANDOM_MODE.marathon.totalRounds })]].map(([v, label]) => html`
          <button key=${v} type="button" role="radio" aria-checked=${variant === v ? 'true' : 'false'} class=${`dpick__opt${variant === v ? ' is-active' : ''}`}
            disabled=${!!busy || !host} onClick=${() => variant !== v && host && onVariant(v)}>${label}</button>`)}
      </div></div>` : null}
  </div>`;
}

/**
 * 本房间使用 mod (W-A/W-D, DESIGN §28.16): the set THIS room declared, shown to every member and spectator from
 * `room.state.mods`, ALONG WITH whether this client really holds it. Absent when the room declared none, in which case
 * this component returns nothing — a room on a plain install (or one whose host ticked nothing) looks exactly as it did
 * before this feature.
 *
 * W-D is the second half: the panel asks `planAlignment` (public/js/mods/align.js) whether the bytes on THIS client
 * rebuild every pack the room declared, offers to download exactly those (`alignRoom`), draws the progress `sync`
 * reports, and tells the room screen whether the Ready button may be offered at all. A server that carries packs this
 * client cannot name is called out by name instead of silently staying 「未就绪」.
 * @param {{ room: any, onAlignment?: (state: { ok: boolean, needed: boolean, missing: number }|null) => void }} props
 */
function RoomModsPanel({ room, onAlignment = null }) {
  syncMorphPlusFlag(room && room.flags);
  const mods = roomModsOf(room);
  const [plan, setPlan] = useState(null);
  const [progress, setProgress] = useState(null);
  const [busy, setBusy] = useState(false);
  const [checked, setChecked] = useState(false);
  const alive = useRef(true);
  useEffect(() => () => { alive.current = false; }, []);
  const report = onAlignment || (() => {});
  const digest = mods ? mods.digest : null;

  // Ask once per room set: the answer decides both what this panel shows and whether Ready is offered. A room without a
  // declaration reports 「无需对齐」 and the panel disappears.
  useEffect(() => {
    if (!digest) { setPlan(null); setChecked(true); report(null); return undefined; }
    let live = true;
    setChecked(false);
    (async () => {
      const catalog = await loadCatalog();
      const next = await planAlignment({ catalog, mods, store: storeFor() });
      if (!live || !alive.current) return;
      setPlan(next);
      setChecked(true);
      report({ ok: next.ok, needed: next.needed, missing: next.missingFiles });
    })().catch(() => { if (live) { setChecked(true); setPlan(null); report(null); } });
    return () => { live = false; };
    // `digest` is the identity of the set: the same packs re-announced must not re-download or re-hash
  }, [digest]);

  if (!mods) return null;
  const known = plan ? plan.packs : null;
  const unknown = plan ? plan.unknown : [];
  const missingFiles = plan ? plan.missingFiles : 0;
  const ready = !!plan && plan.ok;

  const fill = async () => {
    if (busy) return;
    setBusy(true);
    setProgress({ done: 0, total: 0 });
    try {
      const catalog = await loadCatalog();
      const next = await alignRoom({
        catalog, mods, store: storeFor(),
        onProgress: (e) => { if (alive.current && (e.type === 'done' || e.type === 'file-start' || e.type === 'file-done' || e.type === 'file-skipped')) setProgress({ done: e.done ?? 0, total: e.total ?? 0 }); },
      });
      if (!alive.current) return;
      setPlan(next);
      report({ ok: next.ok, needed: next.needed, missing: next.missingFiles });
      if (!next.ok) toast(t('模组仍未就绪：{ids}', { ids: missingPackIds(next).join(', ') || '—' }), 'warn');
    } catch (err) {
      if (alive.current) toastError(err);
    } finally {
      if (alive.current) { setBusy(false); setProgress(null); }
    }
  };

  return html`<div class="room-mods brackets">
    <${MicroLabel} tone="mint">ROOM MODS<//>
    <span class="room-mods__title">${t('本房间使用模组（{n} 个）', { n: mods.packs.length })}</span>
    <span class="room-mods__digest num" title=${mods.digest}>${shortDigest(mods.digest)}…</span>
    ${ready ? html`<span class="room-mods__state t-mint">${t('本机已就绪')}</span>` : null}
    <ul class="room-mods__list">
      ${mods.packs.map((p) => {
        const state = known ? known.find((x) => x.id === p.id) : null;
        return html`<li key=${p.id}>
          <span class="room-mods__id">${p.id}</span>
          <span class="room-mods__meta">${t(LAYER_TEXT[p.layer] || p.layer)}${p.combat ? ` · ${t('会改动战斗结果')}` : ''}</span>
          ${state && !state.ok ? html`<span class="room-mods__state t-orange">${state.known ? t('本机缺件') : t('本服务器没有这个包')}</span>` : null}
        </li>`;
      })}
    </ul>
    ${checked && plan && !plan.ok
      ? html`<div class="room-mods__fill">
          <span class="t-lo">${unknown.length ? t('房间点名了本服务器没有的模组：{ids}', { ids: unknown.join(', ') }) : t('本机还缺 {n} 个模组文件', { n: missingFiles })}</span>
          <${Button} variant="secondary" size="sm" icon="refresh" loading=${busy} disabled=${busy || unknown.length > 0} onClick=${fill}>
            ${busy && progress && progress.total ? t('正在补齐 {done}/{total}', { done: progress.done, total: progress.total }) : t('补齐模组')}<//>
        </div>`
      : null}
  </div>`;
}

/** Room screen component. */
export function RoomScreen() {
  const room = useStore((s) => s.room);
  const me = useStore((s) => s.me, shallowEqual);
  const conn = useStore((s) => s.connection, shallowEqual);
  const mm = useStore((s) => s.matchmaking, shallowEqual);
  const [busy, setBusy] = useState(null);
  const [picker, setPicker] = useState(false);
  const [opts, setOpts] = useState(false);
  const [searchWant, setSearchWant] = useState(false); // the host asked to search and has not stopped
  const [searchSince, setSearchSince] = useState(0);
  const [found, setFound] = useState(false);
  const [lastMatching, setLastMatching] = useState(0); // a short grace while the host's client queues the room again
  const [since] = useState(() => Date.now());
  // 对齐状态（W-D, DESIGN §28.16）：房间声明了集合而本机还没拿到那几个包时，**不给**准备就绪这个按钮 —— 服务器
  // 那边「全员就绪才能开始」这条规则不变，这里只是不让玩家点一个注定让房间开不起来的按钮。
  const [align, setAlign] = useState(null);
  const alive = useRef(true);
  const inFlight = useRef(false); // synchronous guard against double clicks (state updates are async)
  const requeue = useRef(false);
  const prevEmpty = useRef(null);
  const [, tick] = useState(0);
  useEffect(() => { const id = setInterval(() => tick((x) => x + 1), 1000); return () => { clearInterval(id); alive.current = false; }; }, []);
  useData('chess', 'assets');
  const m = data.get('assets');
  // 名片干员: the pickable operators, the default pool (5★/6★ by charId, the same order on every client), one's pick
  const cardList = useMemo(() => cardOperators(data.list('chess')), [data.get('chess')]);
  const [myCard, setMyCard] = useState(() => { const v = loadPref(CARD_PREF, ''); return typeof v === 'string' ? v : ''; });
  const [picking, setPicking] = useState(false);
  const portraits = useMemo(() => ({
    pool: cardList.filter((c) => (c.rarity ?? 0) >= 5).sort((a, b) => (a.charId < b.charId ? -1 : 1)),
    byChar: new Map(cardList.map((c) => [c.charId, c])), m, myId: me.playerId, myCard,
  }), [cardList, m, me.playerId, myCard]);
  const pickCard = (charId) => {
    setMyCard(charId); savePref(CARD_PREF, charId); setPicking(false);
  };
  // tell the server (teammates see it) once it knows room.card; a refused id stays local
  const seatCard = room ? (roomFacts(room, me.playerId).mine?.card || '') : '';
  useEffect(() => {
    if (!CARD_SYNC || !room || conn.status !== 'online' || seatCard === (myCard || '')) return;
    if (myCard && !portraits.byChar.has(myCard)) return;
    net.request('room.card', { charId: myCard || '' }).catch(() => {});
  }, [room?.code, myCard, seatCard, conn.status]);

  // arrived through 搜寻队友 (match.found for this room): 搜寻成功 once
  useEffect(() => {
    if (room && mm?.status === 'found' && mm.roomCode === room.code) {
      setFound(true);
      store.patch('matchmaking', { status: 'idle' });
    }
  }, [room?.code, mm?.status]);
  useEffect(() => { if (!found) return undefined; const id = setTimeout(() => alive.current && setFound(false), 1900); return () => clearTimeout(id); }, [found]);

  const online = conn.status === 'online';
  const coop = room ? room.mode !== 'solo' : false;
  const facts = room ? roomFacts(room, me.playerId) : null;
  const searchable = CAN_QUEUE && !!room && coop && facts.isHost && room.private !== true && facts.seats.length <= DEFAULT_SEATS && !room.inMatch;
  const firepower = room?.random === true;
  const variant = room?.variant === 'endurance' || room?.variant === 'marathon' ? room.variant : 'blitz';

  // the server ends a room's search turn after 10 s without bots: queue again while the host still wants it
  const prevMatching = useRef(null);
  const endedAt = useRef(0);
  useEffect(() => {
    if (!room) return undefined;
    // the end of a search turn: the others keep the panel for a moment while the host's client queues again
    if (prevMatching.current && !room.matching) { endedAt.current = Date.now(); setLastMatching(endedAt.current); }
    prevMatching.current = room.matching || null;
    if (room.matching) return undefined;
    if (!searchWant || !searchable || facts.emptySeats === 0 || !online || requeue.current) return undefined;
    requeue.current = true;
    const id = setTimeout(() => {
      net.request('match.queue', { mode: room.mode, difficulty: room.difficulty, random: firepower, ...(firepower ? { variant } : {}), fillBots: false })
        .catch((err) => { if (alive.current) { setSearchWant(false); toastError(err); } })
        .finally(() => { requeue.current = false; });
    }, 400);
    return () => { clearTimeout(id); requeue.current = false; };
  }, [room?.matching, searchWant, searchable, facts?.emptySeats, online]);
  // seats filled while searching → 搜寻成功; a stale wish is dropped
  useEffect(() => {
    if (!facts) return;
    const empty = facts.emptySeats;
    const wasSearching = searchWant || !!room.matching || Date.now() - endedAt.current < 2500;
    if (prevEmpty.current != null && empty < prevEmpty.current && wasSearching && empty === 0) setFound(true);
    if (empty === 0 && searchWant) setSearchWant(false);
    prevEmpty.current = empty;
  }, [facts?.emptySeats]);
  useEffect(() => { if (!searchable && searchWant) setSearchWant(false); }, [searchable]);
  const searching = !!room && coop && facts.emptySeats > 0 && (!!room.matching || (facts.isHost ? searchWant : Date.now() - lastMatching < 1600));
  // the overlays stay mounted while they fade out; 离开同盟 fades the room before the request goes out
  const [searchShown, searchLeaving] = usePresence(searching && !found, 220);
  const [foundShown, foundLeaving] = usePresence(found, 320);
  const [protoShown, protoLeaving] = usePresence(picker && !!facts?.isHost, 220);
  const [optsShown, optsLeaving] = usePresence(opts, 160);
  const [exiting, setExiting] = useState(false);

  if (!room) return null;
  const myReady = !!facts.mine?.ready;
  const info = difficultyInfo(room.mode, room.difficulty, { random: firepower, variant });
  const variantName = variant === 'endurance' ? t('持久鏖战') : variant === 'marathon' ? t('最长时赛') : t('快速突袭');
  const modeName = firepower ? `${RANDOM_MODE_NAME} · ${variantName}` : coop ? t('同盟模拟') : t('独立模拟');
  const searchElapsed = facts.isHost && searchSince ? (Date.now() - searchSince) / 1000
    : room.matching?.startedAt ? (serverNow() - room.matching.startedAt) / 1000 : 0;

  // Returns whether the request actually went through: the seat-cap slider uses that to decide whether to keep showing
  // what the host asked for or to fall back to the room's own frame. Every existing caller ignores the value.
  const run = async (kind, fn) => {
    if (inFlight.current) return false;
    if (!online) { toast(t('连接中断，请稍候重试'), 'warn'); return false; }
    inFlight.current = true;
    setBusy(kind);
    try { await fn(); return true; } catch (err) { toastError(err); return false; } finally {
      inFlight.current = false;
      if (alive.current) setBusy(null);
    }
  };

  const toggleReady = () => run('ready', () => net.request('room.ready', { ready: !myReady }));
  const start = () => run('start', () => net.request('room.start', {}));
  const queueMatch = () => run('match', async () => {
    await net.request('match.queue', { mode: room.mode, difficulty: room.difficulty, random: firepower, ...(firepower ? { variant } : {}), fillBots: false });
    setSearchWant(true); setSearchSince(Date.now());
  });
  // 房主切换无限火力分支（blitz / endurance）——room.setRandom 带 variant
  const setVariant = (v) => run('variant', () => net.request('room.setRandom', { random: true, variant: v }));
  const cancelMatch = () => { setSearchWant(false); setLastMatching(0); if (room.matching) run('cancel-match', () => net.request('match.cancel', {})); };
  // the host removes a human before the match (community report #17): asked first; the player may join again. The
  // confirmed player's id goes along: if they left and someone else took the seat meanwhile, the server refuses it.
  const kick = async (seat, name, playerId) => {
    if (inFlight.current) return;
    const ok = await confirmDialog({ title: t('移出同盟'), text: t('确定将「{name}」移出同盟吗？对方可以凭同盟密钥重新加入。', { name: name || t('博士') }), okText: t('移出'), danger: true });
    if (ok) run(`kick${seat}`, () => net.request('room.kick', { seat, playerId }));
  };
  // 对局选项 (this fork): 滑动条停止拖动后一次性下发（面板内已防抖），所以这里不再加 busy 门禁
  // 对局选项权限 (this fork)：只有房主（创建房间的人）可以更改设置；其他人尝试修改时弹提示且不发送
  const hostOnly = (fn) => (...args) => {
    if (!facts.isHost) { toast(t('对局选项仅房主（创建房间的人）可以修改')); return; }
    return fn(...args);
  };
  const setTuning = hostOnly((tuning) => net.request('room.setTuning', { tuning }).catch(toastError));
  const setBuffs = hostOnly((buffs) => net.request('room.setBuffs', { buffs }).catch(toastError));
  const setFlags = hostOnly((flags) => net.request('room.setFlags', { flags }).catch(toastError));
  // 稀有度不重复 (v0.03.3)：房主开关，开局前可改
  const setHexNoRepeat = hostOnly((on) => net.request('room.setHexNoRepeat', { on: on === true }).catch(toastError));
  const setHexGrade = hostOnly((draft1, draft2, draft3) => net.request('room.setHexGrade',
    draft3 === undefined ? { draft1, draft2 } : { draft1, draft2, draft3 }).catch(toastError));
  // 「自选海克斯」(this fork)：host-only before the match —— 图鉴选择模式的确认（room.setHexPicks）
  // v0.04.3：自选海克斯对**所有成员**开放（各自选自己那份；服务端只接受本房成员，一人一份）
  const setHexPicks = (picks) => net.request('room.setHexPicks', { picks }).catch(toastError);
  // 房间设置 · 时长 (this fork)：host-only before the match, 仅联合模式（room.setTimers）
  const setTimers = hostOnly(({ hexChoice, prep }) => net.request('room.setTimers', { hexChoice, prep }).catch(toastError));
  // ── 对局选项弹层 + 保存方案 (this fork, v0.03.2, 用户要求) ────────────────────────────────
  // 「对局选项」收进开始模拟左侧的方形按钮，点开是一个类似更新公告的弹层；弹层里可以「保存方案」——
  // 存到 localStorage，下次开房间时自动套用（房主 / 独立模拟才下发，队友看不到自己的方案）。
  const [optModal, setOptModal] = useState(false);
  const [presetAt, setPresetAt] = useState(() => Number(loadRoomPreset()?.at) || 0);
  const presetApplied = useRef(false);
  const saveCurrentPreset = () => {
    const ok = saveRoomPreset(room);
    if (!ok) { toastError(t('保存方案失败（浏览器存储不可用）')); return; }
    setPresetAt(Date.now());
    toast(t('方案已保存 · 下次开局自动套用'));
  };
  const dropPreset = () => {
    clearRoomPreset();
    setPresetAt(0);
    toast(t('已清除保存的方案'));
  };
  useEffect(() => {
    if (presetApplied.current || !facts.isHost || !online) return;
    const preset = loadRoomPreset();
    if (!preset) return;
    presetApplied.current = true;
    try {
      if (preset.flags) setFlags(preset.flags);
      if (preset.tuning) setTuning(preset.tuning);
      if (preset.buffs) setBuffs(preset.buffs);
      if (Array.isArray(preset.hexPicks)) setHexPicks(preset.hexPicks);
      if (preset.hexGrade1 || preset.hexGrade2 || preset.hexGrade3) setHexGrade(preset.hexGrade1 || HEX_GRADE_RANDOM, preset.hexGrade2 || HEX_GRADE_RANDOM, preset.hexGrade3 || HEX_GRADE_RANDOM);
      if (preset.hexNoRepeat) setHexNoRepeat(true);
      if (coop && (preset.hexChoiceSec || preset.prepSec)) setTimers({ hexChoice: preset.hexChoiceSec || 0, prep: preset.prepSec || 0 });
      if (presetAt) toast(t('已套用保存的对局方案'));
    } catch { /* 单人 / 非房主：忽略 */ }
  }, [facts.isHost, online]);

  // 测试工具 (this fork, 仅作者账号 zwl —— 服务端按会话名门禁，其他人发请求会被 NOT_HOST 拒掉)：
  // 无敌开关 + 重开一局并直跳任意关（1–15，含 14 最终决战 / 15 隐秘核心），用于亲自复现 Boss 战问题。
  const isZwl = me.name === 'zwl';
  const [debugRound, setDebugRound] = useState(14);
  const [godOn, setGodOn] = useState(false);
  const debugJump = () => net.request('room.debug', { op: 'jump', round: debugRound })
    .then(() => toast(t('测试：已重开一局并进入第 {r} 关', { r: debugRound })))
    .catch(toastError);
  const debugGod = () => {
    const next = !godOn;
    net.request('room.debug', { op: 'god', on: next })
      .then(() => { setGodOn(next); toast(next ? t('测试：无敌已开启') : t('测试：无敌已关闭')); })
      .catch(toastError);
  };
  const setPrivate = (isPrivate) => run('privacy', () => net.request('room.setPrivate', { private: isPrivate }));
  // 本房座位上限 (业主裁决 B5): the `code` goes along so the request can only ever address THIS room — a tab acting on a
  // stale frame gets NOT_IN_ROOM instead of resizing whatever room it happens to be in now.
  const setSeatCap = (seatCap) => run('seatcap', () => net.request('room.setSeatCap', { code: room.code, seatCap }));
  // 「添加 AI 队友」：包版房间把空席位的入口只留了「邀请」，而服务端 `room.addBot` / `room.removeBot` 一直都在
  // （HEAD 的引擎房间有这两个按钮，见本次 CHANGELOG 0.18.4）。按业主裁定补回**入口**，协议与服务端一字未动。
  const addBot = () => run('add', () => net.request('room.addBot', {}));
  const removeBot = (seat) => run(`rm${seat}`, () => net.request('room.removeBot', { seat }));
  const setDifficulty = (difficulty) => run('diff', async () => { await net.request('room.setDifficulty', { difficulty }); setPicker(false); });
  const setAiLast = (on) => run('ailast', () => net.request('room.setAiPicksLast', { on }));
  // spectator seats: the host frees one; a spectator takes a free player seat with room.join of this room
  const removeSpectator = (playerId) => run(`rs${playerId}`, () => net.request('room.removeSpectator', { playerId }));
  const sit = () => run('sit', () => net.request('room.join', roomMods.buildJoinPayload(room.code)));
  const copy = async (what) => {
    const modeLabel = firepower ? `${RANDOM_MODE_NAME} · ` : '';
    const ok = await copyText(what === 'code' ? room.code : t('{0} {name}邀请你加入卫戍协议：盟约【{modeLabel}{3}】', { 0: inviteLink(room.code), name: me.name, modeLabel, 3: DIFFICULTY_NAMES[room.difficulty] }));
    if (ok) toast(what === 'code' ? t('同盟密钥复制成功，可前往邀请队友') : t('已复制邀请链接'), 'success');
    else toast(t('复制失败，请手动复制'), 'warn');
  };
  const leave = async () => {
    if (inFlight.current) return;
    const othersHere = facts.humans.some((s) => s.playerId !== me.playerId);
    if (facts.isHost && othersHere) {
      const ok = await confirmDialog({ title: t('离开同盟'), text: t('你是同盟的创建者，离开后创建者身份将移交或同盟解散。确定离开吗？'), okText: t('离开'), danger: true });
      if (!ok) return;
    }
    inFlight.current = true;
    setBusy('leave');
    setExiting(true);
    await afterLeave(200);
    try {
      await net.request('room.leave', {});
    } catch (err) {
      if (err?.code !== 'NOT_IN_ROOM') toastError(err);
    } finally {
      // Leaving locally is always safe: the server either confirmed or no longer has us in the room.
      store.set({ room: null, match: emptyMatch() });
      inFlight.current = false;
      if (alive.current) setBusy(null);
    }
  };

  const toFill = Math.max(0, Math.min(DEFAULT_SEATS, facts.seats.length) - facts.occupied.length);
  const statusLine = !online
    ? html`<span class="t-orange"><${Icon} name="wifiOff" />${t('连接中断，正在重连…')}</span>`
    : facts.spectating
      ? html`<span class="t-lo"><${Icon} name="eye" />${t('观战中 · 不占博士席位，模拟开始后可切换观看各位博士')}</span>`
    : !coop
      ? html`<span class="t-mint">${t('*模拟协议已就绪，准许进入模拟')}</span>`
    : facts.isHost
      ? facts.canStart
        ? facts.emptySeats && searchable
          ? html`<span>${t('精确搜寻：将搜寻 {n} 位同难度的博士', { n: toFill })}<span class="t-mint"> · ${t('也可直接开始模拟')}</span></span>`
          : html`<span class="t-mint">${t('*同盟人数达标，准许进入模拟')}</span>`
        : html`<span class="t-lo">${t('等待所有博士准备就绪')}</span>`
      : myReady
        ? html`<span class="t-mint">${t('已就绪 · 等待创建者开始模拟')}</span>`
        : html`<span class="t-lo">${t('准备就绪后，创建者即可开始模拟')}</span>`;

  return html`<div class=${`screen room-screen rs${coop ? '' : ' rs--solo'}${facts.seats.length > DEFAULT_SEATS ? ' rs--big' : ''}${exiting ? ' is-leaving' : ''}`} style=${`--d-color:${DIFFICULTY_COLORS[room.difficulty]}; --n:${facts.seats.length}`}>
    <div class="rs__bg" aria-hidden="true"></div>
    <header class="rs-top">
      <div class="rs-top__left">
        <${Tooltip} text=${t('离开同盟')} placement="bottom">
          <button type="button" class="rs-exit" disabled=${busy === 'leave'} onClick=${leave} aria-label=${t('离开同盟')}><${Icon} name="exit" /></button>
        <//>
        <div class="rs-clock">
          <b>${modeName}<span class="rs-clock__sep"></span>${t('同盟已等待')} <span class="num">${clock((Date.now() - since) / 1000)}</span></b>
          <span>${t('当前延迟')}<b class=${`num rs-ping rs-ping--${!online || !Number.isFinite(conn.ping) ? 'off' : conn.ping < 60 ? 'low' : conn.ping < 200 ? 'mid' : 'high'}`}>${online && Number.isFinite(conn.ping) ? Math.round(conn.ping) : '--'}</b>ms</span>
        </div>
        <div class="rs-tools">
          <${Button} variant="secondary" size="sm" square=${true} icon="chart" class="stats-entry" onClick=${openStats} title=${t('统计数据')} aria-label=${t('统计数据')} />
          ${coop && !openFriends.unavailable ? html`<${Button} variant="secondary" size="sm" square=${true} icon="users" class="rs-friends" onClick=${() => openFriends()} title=${t('好友 · 邀请好友加入')} aria-label=${t('好友')} />` : null}
          <${SettingsButton} class="room-settings" variant="secondary" square=${true} />
          <${GuideButton} class="room-guide" variant="secondary" square=${true} />
        </div>
      </div>
      <div class="rs-top__right">
        ${coop ? html`<label class="rs-public" title=${facts.isHost
          ? t('公开后，你的同盟会出现在所有博士大厅的「缺人同盟」列表')
          : t('仅创建者可以更改是否公开')}>
          <span class="rs-public__label">${t('公开')}</span>
          <input type="checkbox" class="rs-public__switch" role="switch" checked=${room.isPublic !== false} disabled=${!facts.isHost}
            onChange=${(e) => net.request('room.setPublic', { isPublic: e.currentTarget.checked }).catch(() => {})} aria-label=${t('是否公开同盟')} />
        </label>` : null}
        <${LoadoutButton} from="room" size="md" class="hub-plate hub-plate--loadout rs-loadout" label=${t('干员调配')} />
        <${SupportButton} from="room" size="md" class="room-support" />
        ${coop ? html`<div class="rs-key">
          <span class="rs-key__k">${t('同盟密钥')}</span>
          <b class="rs-key__code num selectable" aria-label=${t('同盟密钥 {code}', { code: room.code })}>${room.code}</b>
          <button type="button" class="rs-key__copy" onClick=${() => copy('code')}>${t('复制')}</button>
          <button type="button" class="rs-key__link" onClick=${() => copy('link')} title=${t('复制邀请链接')} aria-label=${t('复制邀请链接')}><${Icon} name="link" /></button>
          ${openFriends.unavailable ? null : html`<button type="button" class="rs-key__friends" onClick=${() => openFriends('list')} title=${t('从好友列表邀请好友加入同盟')}><${Icon} name="users" /><span>${t('邀请好友')}</span></button>`}
        </div>` : html`<div class="rs-key rs-key--solo"><${MicroLabel}>SINGLE OPERATOR<//><span>${t('仅限 1 名博士')}</span></div>`}
      </div>
    </header>

    <main class="rs-seats">
      ${facts.seats.map((s, i) => html`<${SeatCard} key=${s ? `p${s.playerId}` : `e${i}`} seat=${s} index=${i} room=${room} facts=${facts}
        myId=${me.playerId} busy=${busy} onKick=${kick} onInvite=${() => copy('code')} searching=${searching} portraits=${portraits}
        onPickCard=${cardList.length ? () => setPicking(true) : null} onAddBot=${addBot} onRemoveBot=${removeBot} />`)}
      ${coop ? null : html`<aside class="solo-brief rs-brief brackets">
        <${MicroLabel} tone="mint">BRIEFING<//>
        <h2>${DIFFICULTY_NAMES[room.difficulty] ? t(DIFFICULTY_NAMES[room.difficulty]) : ''}<span class="num t-dim"> ${info.code}</span></h2>
        ${(room.flags?.endless || room.flags?.hexTriple) ? html`<div class="rs-brief__tags">
          ${room.flags?.endless ? html`<span class="rs-tag rs-tag--endless">${t('无尽模式')}</span>` : null}
          ${room.flags?.hexTriple ? html`<span class="rs-tag rs-tag--hex">${t('三海克斯')}</span>` : null}
        </div>` : null}
        <p>${info.desc}</p>
        <ul>
          ${info.effects.map((e) => html`<li key=${e}>${e}</li>`)}
          <li>${t('共')} <b class="num">${info.rounds}</b> ${tc('rounds', '回合')}${info.hidden ? t('，满足条件时进入隐秘核心') : ''}</li>
          <li>${t('独立模拟中休整期与机变阶段不限时')}</li>
        </ul>
      </aside>`}
    </main>
    ${/* 对局选项已移到「开始模拟」左侧的方形按钮（弹层形式，见下方 rs-foot__right） */ ''}
    ${isZwl ? html`<div class="dbg-strip" role="group" aria-label=${t('测试工具')}>
      <span class="dbg-strip__tag">TEST</span>
      <label class="dbg-strip__round">${t('关卡')}
        <select class="dbg-strip__sel num" value=${debugRound} onChange=${(e) => setDebugRound(Number(e.target.value) || 14)}>
          ${Array.from({ length: 15 }, (_, i) => html`<option key=${i + 1} value=${i + 1} selected=${debugRound === i + 1}>${i + 1}</option>`)}
        </select>
      </label>
      <${Button} variant="amber" size="sm" onClick=${debugJump}>${t('跳转测试')}<//>
      <${Button} variant=${godOn ? 'primary' : 'secondary'} size="sm" onClick=${debugGod}>${godOn ? t('无敌：开') : t('无敌：关')}<//>
    </div>` : null}
    <${RoomModsPanel} room=${room} onAlignment=${setAlign} />
    <${ChatPanel} />
    <${SpectatorBar} facts=${facts} myId=${me.playerId} busy=${busy} onRemove=${removeSpectator} onSit=${sit} />

    <${Modal} open=${optModal} title=${t('对局选项')} micro="MATCH OPTIONS" tone="gold" width="min(9.2rem, 96vw)"
      class="opts-modal" onClose=${() => setOptModal(false)}>
      <${OptionsPanel} room=${room} isHost=${facts.isHost} busy=${busy} onTuning=${setTuning} onBuffs=${setBuffs}
        onFlags=${setFlags} onGrade=${setHexGrade} onHexPicks=${setHexPicks} onTimers=${setTimers} myId=${me.playerId}
        onNoRepeat=${setHexNoRepeat} mode="modal" />
      <div class="opts-preset">
        <p class="opts-preset__note">${presetAt
          ? t('已保存方案（{when}）· 下次开局自动套用', { when: new Date(presetAt).toLocaleString() })
          : t('把当前设置保存为方案，下次开局自动套用（房主 / 独立模拟生效）')}</p>
        <div class="opts-preset__btns">
          <${Button} variant="primary" size="sm" onClick=${saveCurrentPreset}>${t('保存方案')}<//>
          ${presetAt ? html`<${Button} variant="secondary" size="sm" onClick=${dropPreset}>${t('清除方案')}<//>` : null}
          <${Button} variant="secondary" size="sm" onClick=${() => setOptModal(false)}>${t('完成')}<//>
        </div>
      </div>
    <//>

    <footer class="rs-foot">
      <div class="rs-foot__left" aria-hidden="true"></div>
      <div class="rs-foot__center">
        <p class="rs-hint">${coop ? html`<span class="rs-ready num" title=${t('已就绪')}>${facts.humans.map((s) => html`<${Icon} key=${s.playerId} name="user" class=${facts.isReady(s) ? 'is-on' : ''} />`)}<b>${facts.readyHumans}</b>/${facts.humans.length}</span>` : null}${statusLine}</p>
        <div class="rs-pill">
          ${coop && CAN_QUEUE ? html`<span class="rs-pill__mode" title=${t('精确搜寻：只与选择相同难度的博士组成同盟')}><${Icon} name="search" />${t('精确搜寻')}</span><i class="rs-pill__sep"></i>` : null}
          <button type="button" class="rs-pill__diff" disabled=${!facts.isHost || !!busy} onClick=${() => setPicker(true)}
            title=${facts.isHost ? t('更改模拟难度') : t('由创建者选择')}><${DifficultyIcon} difficulty=${room.difficulty} />${t(DIFFICULTY_NAMES[room.difficulty])}</button>
          <button type="button" class=${`rs-pill__gear${opts ? ' is-on' : ''}`} onClick=${() => setOpts((v) => !v)} title=${t('同盟设置')} aria-label=${t('同盟设置')} aria-expanded=${opts ? 'true' : 'false'}>
            <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M10.3 2h3.4l.5 2.6 1.9.8 2.2-1.5 2.4 2.4-1.5 2.2.8 1.9 2.6.5v3.4l-2.6.5-.8 1.9 1.5 2.2-2.4 2.4-2.2-1.5-1.9.8-.5 2.6h-3.4l-.5-2.6-1.9-.8-2.2 1.5-2.4-2.4 1.5-2.2-.8-1.9L2 13.7v-3.4l2.6-.5.8-1.9-1.5-2.2 2.4-2.4 2.2 1.5 1.9-.8zM12 8.5a3.5 3.5 0 1 0 0 7 3.5 3.5 0 0 0 0-7z" fill-rule="evenodd" /></svg>
          </button>
          ${optsShown ? html`<${RoomOptions} room=${room} facts=${facts} myId=${me.playerId} busy=${busy} online=${online} variant=${variant}
            onPrivate=${setPrivate} onSeatCap=${setSeatCap} onAiLast=${setAiLast} onVariant=${setVariant} onClose=${() => setOpts(false)} leaving=${optsLeaving} />` : null}
        </div>
      </div>
      <div class="rs-foot__right">
        ${facts.isHost ? html`<button type="button" class=${`rs-optbtn${optModal ? ' is-on' : ''}`}
            onClick=${() => setOptModal(true)} title=${t('对局选项（可保存方案）')} aria-label=${t('对局选项')} aria-haspopup="dialog">
            <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 6h10v2H4zM4 11h16v2H4zM4 16h7v2H4z" /><circle cx="18" cy="7" r="2.4" /><circle cx="14" cy="17" r="2.4" /></svg>
            <span class="rs-optbtn__label">${t('对局选项')}</span>
            ${OPT_CHIP_COUNT(room) ? html`<i class="rs-optbtn__badge num">${OPT_CHIP_COUNT(room)}</i>` : null}
          </button>` : null}
        ${facts.isHost && searchable && facts.emptySeats > 0 && !searching
          ? html`<button type="button" class="rs-search" disabled=${!online || busy === 'match'} onClick=${queueMatch}>
              <${Icon} name="search" />${t('开始搜寻')}${busy === 'match' ? html`<${Spinner} size="sm" />` : null}</button>` : null}
        ${facts.isHost
          ? html`<button type="button" class="proto-start rs-go" disabled=${!facts.canStart || !online || busy === 'start'} onClick=${start}
              title=${facts.canStart ? undefined : t('仍有博士未准备就绪')}>
              <span class="proto-start__mark" aria-hidden="true"><span class="proto-start__rook"><i>[</i><${Icon} name="rook" /><i>]</i></span><small>STRONGHOLD<br />PROTOCOL</small></span>
              <span class="proto-start__label">${busy === 'start' ? html`<${Spinner} size="sm" />` : null}${t('开始模拟')}</span>
              <span class="proto-start__deco" aria-hidden="true"></span></button>`
          : facts.spectating
            ? html`<button type="button" class="proto-start rs-go" disabled=${true}><span class="proto-start__label"><${Icon} name="eye" />${t('观战中')}</span></button>`
          : html`<button type="button" class=${`proto-start rs-go${myReady ? ' is-ready' : ''}`} disabled=${!online || !facts.mine || busy === 'ready' || !!(align && align.needed && !align.ok)} onClick=${toggleReady}
              title=${align && align.needed && !align.ok ? t('模组未就绪：先补齐本房间的模组文件') : myReady ? t('再次点击取消就绪') : undefined}>
              <span class="rs-go__box" aria-hidden="true">${myReady ? html`<${Icon} name="check" />` : null}</span>
              <span class="proto-start__label">${busy === 'ready' ? html`<${Spinner} size="sm" />` : null}${myReady ? t('已就绪') : t('准备就绪')}</span>
              <span class="proto-start__deco" aria-hidden="true"></span></button>`}
      </div>
    </footer>

    ${searchShown ? html`<${SearchPanel} class=${`rs-searchpanel${searchLeaving ? ' is-leaving' : ''}`} elapsed=${searchElapsed}
      onStop=${facts.isHost ? cancelMatch : null} stopping=${busy === 'cancel-match'}
      note=${facts.isHost ? t('搜寻期间可随时直接开始模拟') : t('创建者正在搜寻队友')}
      tags=${[{ key: 'mode', label: t('精确搜寻'), icon: html`<${Icon} name="search" />` },
        { key: 'diff', label: t(DIFFICULTY_NAMES[room.difficulty]), color: DIFFICULTY_COLORS[room.difficulty], icon: html`<${DifficultyIcon} difficulty=${room.difficulty} />` }]} />` : null}
    ${foundShown ? html`<${FoundPanel} class=${foundLeaving ? 'is-leaving' : ''} seats=${facts.seats.length} text=${t('同盟集结完毕')} />` : null}
    ${picking ? html`<${CardPicker} current=${myCard} list=${cardList} m=${m} onPick=${pickCard} onClose=${() => setPicking(false)} />` : null}
    ${protoShown ? html`<${RoomProtocol} room=${room} variant=${variant} busy=${busy} onClose=${() => setPicker(false)} onPick=${setDifficulty} leaving=${protoLeaving} />` : null}
  </div>`;
}
