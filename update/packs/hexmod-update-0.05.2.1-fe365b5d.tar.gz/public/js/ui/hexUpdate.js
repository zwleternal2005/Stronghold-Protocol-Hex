// public/js/ui/hexUpdate.js — 标题屏的自动更新界面（方案 D「极简大字」，2026-10-19）。
//
// 四个状态：检测到新版本 → 更新中（百分比 / MB/s / 换源）→ 完成（服务端重启后自动刷新）→ 所有源失败（网盘 + 加群）。
// 数据来自同源的 `GET /update-check`（其中 `auto` 是 server/autoUpdate.js 的状态）；动作是
// `POST /update/start` 与 `POST /update/cancel`（JSON Content-Type，同源）。
//
// 一条纪律：没有配置发布仓库（`auto.enabled === false`）时，这里退化成「前往网盘更新」，绝不显示一个按不动的按钮。
// 断线是预期内的 —— 更新完成后服务端会退出并以退出码 42 重启，页面轮询 /healthz，回来即 reload。

import { html } from './components.js';
import { useEffect, useState } from '../../vendor/hooks.module.js';
import { t } from '../../../shared/i18n.js';

const QUARK_URL = 'https://pan.quark.cn/s/eb95218b2bab';
const QQ_URL = 'https://qm.qq.com/q/nq862gDfQA';
const GROUP = '189434216';
const BUSY_PHASES = ['downloading', 'verifying', 'applying'];

/** 同源拉一次更新检查结果；拿不到（旧服务器 / 网络错）就保持 null。 */
export function useHexUpdateCheck() {
  const [view, setView] = useState(null);
  useEffect(() => {
    let alive = true;
    fetch('/update-check')
      .then((r) => (r.ok ? r.json() : null))
      .then((v) => { if (alive && v && typeof v === 'object') setView(v); })
      .catch(() => {});
    return () => { alive = false; };
  }, []);
  return view;
}

const mb = (n) => (n >= 1048576 ? `${(n / 1048576).toFixed(1)} MB` : `${Math.max(0, Math.round(n / 1024))} KB`);
const speedText = (bps) => (bps >= 1048576 ? `${(bps / 1048576).toFixed(1)} MB/s` : `${Math.max(0, Math.round(bps / 1024))} KB/s`);

function codeText(code, rooms) {
  if (code === 'ROOMS') return t('还有对局在进行，结束对局后再更新。').replace('{}', rooms || '');
  if (code === 'NEED_FULL') return t('这个版本需要下载完整包，请从网盘更新。');
  if (code === 'BUSY') return t('更新已经在进行中。');
  if (code === 'NO_UPDATE') return t('没有可用的更新。');
  return t('更新启动失败，请从网盘更新或稍后重试。');
}

/**
 * 标题屏的更新弹窗。
 * @param {{ view?: any, onDismiss?: Function }} props
 */
export function HexUpdateBanner({ view: viewProp, onDismiss }) {
  const fetched = useHexUpdateCheck();
  const base = viewProp !== undefined ? viewProp : fetched;
  const [auto, setAuto] = useState(null);
  const [phase, setPhase] = useState('idle');
  const [progress, setProgress] = useState({ pct: 0, bytes: 0, total: 0, speed: 0 });
  const [tried, setTried] = useState([]);
  const [error, setError] = useState('');
  const [dismissed, setDismissed] = useState(false);

  // 第一次拿到 payload 时接管服务端状态（之后由轮询刷新）。
  useEffect(() => {
    if (!base || auto) return;
    const a = base.auto || { enabled: false, phase: 'idle', progress: { pct: 0, bytes: 0, total: 0, speed: 0 } };
    setAuto(a);
    setPhase(a.phase || 'idle');
    if (a.progress) setProgress(a.progress);
    if (a.error) setError(a.error);
    if (a.tried) setTried(a.tried);
  }, [base, auto]);

  // 轮询：只在「正在查 / 正在下 / 刚打开还没查到」时跑，稳定后停手。
  const polling = !!(auto && auto.enabled && !dismissed && (
    ['checking'].concat(BUSY_PHASES).includes(phase) || (phase === 'idle' && !auto.latest)
  ));
  useEffect(() => {
    if (!polling) return undefined;
    let alive = true;
    const tick = async () => {
      try {
        const r = await fetch('/update/status', { cache: 'no-store' });
        if (!r.ok) return;
        const v = await r.json();
        if (!alive || !v || typeof v !== 'object') return;
        setAuto(v);
        setPhase(v.phase || 'idle');
        if (v.progress) setProgress(v.progress);
        if (v.error) setError(v.error);
        if (Array.isArray(v.tried)) setTried(v.tried);
      } catch { /* 服务端正在重启：下一轮再试 */ }
    };
    const id = setInterval(tick, 600);
    tick();
    return () => { alive = false; clearInterval(id); };
  }, [polling, phase]);

  // 更新完成：服务端退出并以 42 重启 —— 轮询 /healthz，确认「新进程」就绪后再刷新整页。
  // v0.05.2 修复：原来「一看到 200 就 reload」会抢跑 —— 旧进程还没退出时 /healthz 照样 200，
  // reload 后的加载正好落进「旧进程已走、新进程未起」的空窗，于是卡在更新完成界面，要手动再刷一次才进。
  // 现在必须确认是**新进程**才 reload，判据取三者之一：
  //   ① build 变了（新代码已生效）；② uptime 回绕到 ≤ 60 秒（服务端刚起）；③ 期间探测到过连接失败（旧进程确定已走）。
  // 超时只是把界面切成 RESTART SLOW，**后台仍每 3 秒探测**，服务端一回来就自动刷新，不再要求玩家手动刷。
  useEffect(() => {
    if (phase !== 'done' && phase !== 'timeout') return undefined;
    let alive = true;
    let tries = 0;
    let firstBuild = null;
    let sawDrop = false;
    const slow = phase === 'timeout';
    (async () => {
      // 给「应用完成 → 进程退出」留一点时间（1.2 秒），但不要过长；slow 模式直接开查。
      await new Promise((res) => setTimeout(res, slow ? 0 : 1200));
      while (alive) {
        tries += 1;
        try {
          const r = await fetch('/healthz', { cache: 'no-store' });
          if (r.ok) {
            let j = null;
            try { j = await r.json(); } catch { j = null; }
            const b = j && typeof j.build === 'string' ? j.build : null;
            const up = Number(j && j.uptimeSec);
            if (b && firstBuild == null) firstBuild = b;
            const fresh = sawDrop
              || (b && firstBuild && b !== firstBuild)
              || (Number.isFinite(up) && up >= 0 && up <= 60);
            if (fresh) { alive = false; window.location.reload(); return; }
          }
        } catch { sawDrop = true; }
        if (!slow && tries >= 150) { setPhase('timeout'); return; }   // ≈2 分钟：切成 RESTART SLOW，effect 以 slow 模式重跑
        await new Promise((res) => setTimeout(res, slow ? 3000 : 800));
      }
    })();
    return () => { alive = false; };
  }, [phase]);

  useEffect(() => {
    const onKey = (e) => { if (e.key === 'Escape' && !BUSY_PHASES.includes(phase)) dismiss(); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [phase]);

  if (dismissed || !base) return null;
  const a = auto || base.auto || null;
  const outdated = !!(base.outdated || (a && a.outdated));
  if (!outdated) return null;
  // 旧服务器（没有 auto 字段）也能用：只给网盘按钮。
  const enabled = !!(a && a.enabled);
  const latest = (a && a.latest) || base.latest || '';
  const notes = (a && a.notes) || base.notes || '';
  const packSize = (a && a.packSize) || 0;
  const compatible = !a || a.compatible !== false;
  const shownPhase = BUSY_PHASES.includes(phase) ? 'busy' : phase;
  const pct = Math.max(0, Math.min(100, Math.round(progress.pct || 0)));

  // 函数声明（不是 const）：上面的 Esc effect 在组件提前 return 时也会挂着，这里必须可提升。
  function dismiss() { setDismissed(true); onDismiss?.(); }
  const downloadUrl = base.downloadUrl || QUARK_URL;
  const openQuark = () => window.open(downloadUrl, '_blank', 'noopener');
  const openQq = () => window.open(QQ_URL, '_blank', 'noopener');

  async function start() {
    setPhase('downloading');
    setError('');
    try {
      const r = await fetch('/update/start', { method: 'POST', headers: { 'content-type': 'application/json' }, body: '{}' });
      const j = await r.json().catch(() => ({}));
      if (!r.ok || !j.ok) { setPhase('failed'); setError(codeText(j.error, j.rooms)); }
    } catch {
      setPhase('failed');
      setError(t('无法连接服务端，请从网盘更新。'));
    }
  }

  async function cancel() {
    try {
      await fetch('/update/cancel', { method: 'POST', headers: { 'content-type': 'application/json' }, body: '{}' });
    } catch { /* ignore */ }
    setPhase('available');
    setProgress({ pct: 0, bytes: 0, total: 0, speed: 0 });
    setError('');
  }

  if (shownPhase === 'done' || phase === 'timeout') {
    const back = phase === 'timeout';
    return html`<div class="hexupd2" role="dialog" aria-modal="true" aria-label=${t('更新完成')}>
      <div class="hexupd2__veil" aria-hidden="true"></div>
      <div class="hexupd2__panel">
        <p class="hexupd2__kick">${back ? 'RESTART SLOW' : 'UPDATE COMPLETE'}</p>
        <div class="hexupd2__ring"><svg viewBox="0 0 24 24"><path d="M4 12.5l5 5L20 6.5"/></svg></div>
        <h2 class="hexupd2__title">${t('已更新到')} <em>v${latest}</em></h2>
        <p class="hexupd2__sub">${back ? t('服务端启动较慢，正在后台等待，就绪后会自动刷新。') : t('正在重启服务端并刷新界面…')}</p>
        ${back
          ? html`<div class="hexupd2__links"><button type="button" class="hexupd2__link" onClick=${() => window.location.reload()}>${t('立即刷新')}</button></div>`
          : html`<p class="hexupd2__count">${t('将在服务端就绪后自动刷新')}</p>`}
      </div>
    </div>`;
  }

  if (shownPhase === 'failed') {
    const list = tried.length ? tried : [];
    return html`<div class="hexupd2" role="dialog" aria-modal="true" aria-label=${t('更新失败')}>
      <div class="hexupd2__veil" aria-hidden="true"></div>
      <div class="hexupd2__panel">
        <p class="hexupd2__kick">UPDATE FAILED</p>
        <div class="hexupd2__failmark">!</div>
        <h2 class="hexupd2__title">${t('所有更新源都无法更新')}</h2>
        <p class="hexupd2__sub">${t('请点击下方按钮前往网盘更新。')}</p>
        ${list.length ? html`<div class="hexupd2__list">${list.map((x) => html`<div><span>${x.host}</span><b>${x.error || t('失败')}</b></div>`)}</div>` : null}
        ${error && !list.length ? html`<p class="hexupd2__cause">${error}</p>` : null}
        <div class="hexupd2__btns">
          <button type="button" class="hexupd2__pill hexupd2__pill--gold" onClick=${openQuark}>${t('前往夸克网盘')}</button>
          <button type="button" class="hexupd2__pill hexupd2__pill--mint" onClick=${openQq}>${t('加群')} ${GROUP}</button>
        </div>
      </div>
    </div>`;
  }

  if (shownPhase === 'busy') {
    const verifying = phase === 'verifying' || phase === 'applying';
    const p = verifying ? 100 : pct;
    const label = phase === 'verifying' ? t('正在校验文件…') : phase === 'applying' ? t('正在安装…') : t('正在更新');
    return html`<div class="hexupd2" role="dialog" aria-modal="true" aria-label=${t('正在更新')}>
      <div class="hexupd2__veil" aria-hidden="true"></div>
      <div class="hexupd2__panel">
        <p class="hexupd2__kick">DOWNLOADING${a && a.source ? ` · ${a.source}` : ''}</p>
        <div class="hexupd2__pct">${p}<span>%</span></div>
        <div class="hexupd2__thin"><i style=${{ width: `${p}%` }}></i></div>
        <div class="hexupd2__row">
          <span>${label}${verifying ? '' : ` · ${mb(progress.bytes || 0)} / ${mb(progress.total || packSize)}`}</span>
          <span class="hexupd2__sp">${verifying ? '' : speedText(progress.speed || 0)}<span>${a && a.count ? `${a.count} ${t('个文件')}` : ''}</span></span>
        </div>
        <p class="hexupd2__tiny">${t('若长时间没有进度，可从网盘更新，或加群')} <b>${GROUP}</b> ${t('手动更新。')}</p>
        <div class="hexupd2__links">
          <button type="button" class="hexupd2__link" onClick=${cancel}>${t('取消更新')}</button>
          <button type="button" class="hexupd2__link" onClick=${openQuark}>${t('打开更新网盘')}</button>
        </div>
      </div>
    </div>`;
  }

  // 检测到新版本（也是「需要完整包」「旧服务器」的落点）
  return html`<div class="hexupd2" role="dialog" aria-modal="true" aria-label=${t('发现新版本')}>
    <div class="hexupd2__veil" aria-hidden="true"></div>
    <div class="hexupd2__panel">
      <p class="hexupd2__kick">${enabled ? 'UPDATE AVAILABLE' : 'UPDATE VIA NETDISK'}</p>
      <h2 class="hexupd2__title">${t('有新版本')} <em>v${latest}</em></h2>
      <p class="hexupd2__sub">
        ${t('当前')} v${base.current || ''}${packSize ? html` · ${t('增量')} <b>${mb(packSize)}</b>` : ''}<br />
        ${enabled && compatible ? t('更新后自动重启服务端并刷新界面') : t('这个版本需要完整包，请从网盘下载。')}
      </p>
      ${notes ? html`<p class="hexupd2__notes">${notes}</p>` : null}
      ${error ? html`<p class="hexupd2__cause">${error}</p>` : null}
      <div class="hexupd2__btns">
        ${enabled && compatible
          ? html`<button type="button" class="hexupd2__pill hexupd2__pill--gold" onClick=${start}>${t('立即更新')}</button>`
          : html`<button type="button" class="hexupd2__pill hexupd2__pill--gold" onClick=${openQuark}>${t('前往夸克网盘')}</button>`}
        <button type="button" class="hexupd2__pill" onClick=${dismiss}>${t('暂不更新')}</button>
      </div>
    </div>
  </div>`;
}
