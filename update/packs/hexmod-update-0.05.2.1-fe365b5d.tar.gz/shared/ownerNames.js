// shared/ownerNames.js — 作者/服主身份名（v0.04.3，用户要求）。
//
// 两个名字（大小写不敏感、忽略首尾空白）：
//   · 在界面上带**金色 OP 角标**（public/js/ui/ownerName.js 渲染，CSS .sp-owner-name）；
//   · 只有**本地网络（同一个 Wi-Fi / 局域网）**的客户端能用 —— 公网（含内网穿透进来的玩家）说自己是这两个名字
//     会被 server/net.js 的 hello 直接拒绝（"name is reserved"）。
//
// 为什么门禁放在服务端：名字是客户端自己报的；没有服务端这一层，任何人改个名字就能冒充作者并拿到 OP 角标。

/** @type {readonly string[]} 作者名（规范化后比较：小写 + 去空白） */
export const OWNER_NAMES = Object.freeze(['zwl', 'Eternal千溟兮']);

const norm = (name) => String(name ?? '').trim().toLowerCase();

/** @param {string} name @returns {boolean} 这个昵称是否受保护（用来决定要不要检查来源地址） */
export function isOwnerName(name) {
  const n = norm(name);
  return !!n && OWNER_NAMES.some((x) => norm(x) === n);
}

/**
 * 这个地址是不是「本地网络」：回环 / 局域网私有段 / 链路本地 / IPv6 ULA。
 * 内网穿透（cloudflared 等）在 `trustProxy: 'auto'` 下会解析成真实公网来源，因此远程玩家拿到的是公网地址。
 * @param {string} addr 形如 `127.0.0.1`、`192.168.43.12`、`::1`、`fe80::1`、`2001:db8::1`
 * @returns {boolean}
 */
export function isPrivateAddress(addr) {
  const a = String(addr ?? '').trim().toLowerCase().replace(/^\[|\]$/g, '');
  if (!a) return false;
  const v4 = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(a.split('%')[0]);
  if (v4) {
    const [o1, o2] = [Number(v4[1]), Number(v4[2])];
    if (o1 === 127) return true;                       // 回环
    if (o1 === 10) return true;                        // 10/8
    if (o1 === 192 && o2 === 168) return true;         // 192.168/16（家用 Wi-Fi / 热点）
    if (o1 === 172 && o2 >= 16 && o2 <= 31) return true; // 172.16/12
    if (o1 === 169 && o2 === 254) return true;         // 169.254/16 链路本地
    return false;
  }
  const v6 = a.split('%')[0];
  if (v6 === '::1') return true;
  if (/^f[cd]/.test(v6)) return true;                  // fc00::/7 ULA
  if (/^fe[89ab]/.test(v6)) return true;               // fe80::/10 链路本地
  return false;
}

/**
 * 服主公网地址白名单 (v0.05.1)：服务器跑在公网时，服主自己从家里登录拿到的也是公网 IP，
 * isPrivateAddress 会把他判成"远程玩家"，于是 zwl / Eternal千溟兮 被拒。用环境变量 SP_OWNER_IPS 显式放行：
 *   · 精确 IPv4 / IPv6：111.22.33.44、2001:db8::5
 *   · IPv4 通配：111.22.33.*
 *   · IPv4 CIDR：111.22.33.0/24
 * 留空 = 不额外放行（行为与从前完全一致）。
 * @param {string} str
 * @returns {string[]}
 */
export function parseOwnerIps(str) {
  return String(str ?? '')
    .split(',')
    .map((x) => x.trim().toLowerCase().replace(/^\[|\]$/g, ''))
    .filter(Boolean);
}

/** @param {string} addr @param {string[]} list @returns {boolean} */
export function isOwnerAddressAllowed(addr, list) {
  const a = String(addr ?? '').trim().toLowerCase().replace(/^\[|\]$/g, '').split('%')[0];
  if (!a || !Array.isArray(list) || !list.length) return false;
  const v4 = /^(\d{1,3}\.){3}\d{1,3}$/;
  const toInt = (ip) => ip.split('.').reduce((n, o) => ((n << 8) + (Number(o) & 255)) >>> 0, 0);
  for (const raw of list) {
    const rule = String(raw || '').trim().toLowerCase();
    if (!rule) continue;
    if (rule === '*' || rule === 'any') return true;
    if (rule.includes('/')) {
      const [net, bitsRaw] = rule.split('/');
      const bits = Number(bitsRaw);
      if (v4.test(a) && v4.test(net) && Number.isInteger(bits) && bits >= 0 && bits <= 32) {
        const mask = bits === 0 ? 0 : (0xffffffff << (32 - bits)) >>> 0;
        if ((toInt(a) & mask) === (toInt(net) & mask)) return true;
      }
      continue;
    }
    if (rule.includes('*')) {
      const re = new RegExp('^' + rule.split('*').map((x) => x.replace(/[.+?^${}()|[\]\\]/g, '\\$&')).join('[0-9a-f:.]+') + '$');
      if (re.test(a)) return true;
      continue;
    }
    if (a === rule) return true;
  }
  return false;
}
