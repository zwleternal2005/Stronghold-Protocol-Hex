// server/autoUpdate.js — the in-app updater: check → download → verify → apply → restart.
//
// The publisher (`tools/publish-update.mjs`) signs a `manifest.json` and builds one `.tar.gz` with only the files that
// changed; this module fetches both from the first mirror that answers, verifies the Ed25519 signature and every
// SHA-256, backs up what it replaces (so a failure can be rolled back), then asks the process to exit with code 42 —
// `scripts/launch.mjs` sees 42 and starts the server again. A browser cannot restart a Node process; that loop is the
// supervisor's job.
//
// Discipline: nothing here runs unless the player clicks 更新. A failed check or a dead mirror changes no file and
// never blocks the title screen. Every write is `.tmp` + rename; every replaced file is copied to
// `var/update-backup/<version>/` first; `removed` files are moved there too (never a blind delete).

import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';
import { once } from 'node:events';
import { compareHexVersions } from '../shared/hexMod.js';
import { parsePatchManifest, verifyManifestSignature, sha256, formatBytes, PACK_MAX_BYTES } from '../shared/updateProtocol.js';
import { tarUnpack } from '../shared/tar.js';

const MANIFEST_TTL_MS = 30 * 60_000;
/** v0.04.1 热更新门禁：待重启状态的轮询周期 / 空闲自动重启兜底时长。 */
const RESTART_POLL_MS = 3000;
const AUTO_RESTART_MS = 15 * 60_000;
const FETCH_TIMEOUT_MS = 8000;
const DEFAULT_MIRRORS = ['https://ghfast.top/', 'https://gh-proxy.com/', ''];
const PHASES = new Set(['idle', 'checking', 'available', 'downloading', 'verifying', 'applying', 'done', 'failed', 'cancelled']);

/** The routes routes.js answers (POST start/cancel, GET status). */
export const UPDATE_STATUS_URL = '/update/status';
export const UPDATE_START_URL = '/update/start';
export const UPDATE_RESTART_URL = '/update/restart';
export const UPDATE_CANCEL_URL = '/update/cancel';


/** update/config.json → the URLs the agent tries, or { enabled: false, reason }. */
export function loadUpdateConfig(root, env = process.env) {
  const file = path.join(root, 'update', 'config.json');
  let raw = null;
  try { raw = JSON.parse(fs.readFileSync(file, 'utf8')); } catch { /* missing or broken: disabled */ }
  const repo = String(env.SP_UPDATE_REPO || raw?.repo || '').trim();
  const branch = String(raw?.branch || 'main').trim();
  const manifestPath = String(raw?.manifestPath || 'update/manifest.json').trim().replace(/^\/+/, '');
  const mirrors = Array.isArray(raw?.mirrors) && raw.mirrors.length ? raw.mirrors.map(String) : DEFAULT_MIRRORS;

  // explicit override (local tests, a private CDN): a comma-separated list of manifest URLs
  const override = String(env.SP_UPDATE_MANIFEST_URLS || '').trim();
  if (override) {
    const urls = override.split(',').map((s) => s.trim()).filter(Boolean);
    if (urls.length) return { enabled: true, reason: '', repo, branch, manifestUrls: urls, mirrors, source: 'env' };
  }
  if (!/^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/.test(repo) || /YOUR_|example/i.test(repo)) {
    return { enabled: false, reason: 'update/config.json has no GitHub repo yet', repo: '', branch, manifestUrls: [], mirrors };
  }
  const rawBase = `https://raw.githubusercontent.com/${repo}/${branch}/${manifestPath}`;
  return {
    enabled: true, reason: '', repo, branch, source: 'github',
    manifestUrls: mirrors.map((m) => m + rawBase),
    rawBase,
    mirrors,   // 安装包下载也走镜像（mirrorUrls(cfg.mirrors, pack.url)）—— 漏了它 pack 只会试直连
  };
}

function mirrorUrls(mirrors, url) {
  const out = [];
  for (const m of mirrors || []) { const u = m + url; if (!out.includes(u)) out.push(u); }
  if (!out.includes(url)) out.push(url);
  return out;
}

function rmrf(p) {
  try { fs.rmSync(p, { recursive: true, force: true }); } catch { /* best effort */ }
}

function sha256FileSync(abs) {
  return sha256(fs.readFileSync(abs));
}

async function readLimited(res, max) {
  const len = Number(res.headers.get('content-length') || 0);
  if (len > max) throw new Error(`响应过大 (${formatBytes(len)})`);
  const buf = Buffer.from(await res.arrayBuffer());
  if (buf.length > max) throw new Error(`响应过大 (${formatBytes(buf.length)})`);
  return buf;
}

/**
 * @param {{ root: string, current: string, config?: object, log?: object, busy?: () => number,
 *           restart?: () => void, publicKey?: string, fetchImpl?: typeof fetch }} opts
 */
export function createUpdateAgent(opts) {
  const root = path.resolve(opts.root);
  const current = String(opts.current || '0.0.0');
  const log = opts.log || console;
  const doFetch = opts.fetchImpl || ((...a) => globalThis.fetch(...a));
  const busy = opts.busy || (() => 0);
  const publicKey = opts.publicKey;

  const stateRoot = path.join(root, 'var');
  const stagingRoot = path.join(stateRoot, 'update-staging');
  const backupRoot = path.join(stateRoot, 'update-backup');
  const stateFile = path.join(stateRoot, 'update-state.json');

  let cfg = opts.config || loadUpdateConfig(root);
  let manifest = null;
  let manifestAt = 0;
  let phase = 'idle';
  let error = '';
  let errorCode = '';
  let bytes = 0;
  let total = 0;
  let speed = 0;
  let source = '';
  let sampleAt = 0;
  let sampleBytes = 0;
  let ac = null;
  let checking = null;
  let restartFn = opts.restart || (() => {});
  let restartTimer = null;
  // v0.04.1 热更新门禁：apply 完成后**不立刻重启** —— 轮询 busy()（在局/占用的房间数），等所有玩家回到
  // 主页面（busy === 0）再重启；期间客户端大厅通过 lobby.stats 的 update.waiting 弹「是否立即重启」。
  let waitingRestart = false;
  let restartPoll = null;
  let idleSince = 0;
  /** Which mirrors were tried and why they failed (shown in the failure dialog). */
  let tried = [];

  const newer = () => !!manifest && compareHexVersions(manifest.version, current) > 0;
  const compatible = () => !!manifest && manifest.from.some((v) => compareHexVersions(v, current) === 0);

  function pct() {
    if (!total) return phase === 'done' ? 100 : 0;
    return Math.max(0, Math.min(100, Math.floor((bytes / total) * 100)));
  }

  function view() {
    return {
      enabled: !!(cfg && cfg.enabled),
      reason: (cfg && cfg.reason) || '',
      phase,
      current,
      latest: manifest ? manifest.version : '',
      outdated: newer(),
      compatible: compatible(),
      notes: manifest ? manifest.notes : '',
      publishedAt: manifest ? manifest.publishedAt : '',
      size: manifest ? manifest.totalBytes : 0,
      packSize: manifest ? manifest.pack.size : 0,
      count: manifest ? manifest.files.size : 0,
      removed: manifest ? manifest.removed.length : 0,
      source,
      checkedAt: manifestAt,
      progress: { bytes, total, pct: pct(), speed },
      waiting: waitingRestart,
      error,
      errorCode,
      tried: tried.slice(0, 4),
      repo: (cfg && cfg.repo) || '',
    };
  }

  function fail(code, message) {
    phase = 'failed';
    errorCode = code;
    error = message;
    log.warn(`[update] ${code}: ${message}`);
  }

  async function tryManifest(url) {
    // 缓存击穿 (v0.05)：镜像 / raw CDN 对**同一个 URL** 会缓存，发版后可能拿到「新 manifest + 旧 sig」导致签名失败
    // （或反过来把旧版本当成最新）。给清单与签名都带上同一个时间戳查询参数，镜像按完整 URL 缓存 → 每次都是最新的一份。
    const bust = `?t=${Date.now()}`;
    const res = await doFetch(url + bust, { signal: AbortSignal.timeout(FETCH_TIMEOUT_MS) });
    if (!res || !res.ok) throw new Error(`HTTP ${res ? res.status : 'no response'}`);
    const buf = await readLimited(res, 4 * 1024 * 1024);
    const sigRes = await doFetch(`${url}.sig${bust}`, { signal: AbortSignal.timeout(FETCH_TIMEOUT_MS) });
    if (!sigRes || !sigRes.ok) throw new Error(`签名 HTTP ${sigRes ? sigRes.status : 'no response'}`);
    const sig = (await sigRes.text()).trim();
    if (!verifyManifestSignature(buf, sig, publicKey)) throw new Error('签名校验失败');
    const m = parsePatchManifest(JSON.parse(buf.toString('utf8')));
    if (!m) throw new Error('清单格式不对');
    return m;
  }

  async function check({ force = false } = {}) {
    if (!cfg || !cfg.enabled) return view();
    if (checking) return checking;
    if (!force && manifest && Date.now() - manifestAt < MANIFEST_TTL_MS) return view();
    if (['downloading', 'verifying', 'applying', 'done'].includes(phase)) return view();

    checking = (async () => {
      if (phase !== 'failed') phase = 'checking';
      const failures = [];
      tried = [];
      for (const url of cfg.manifestUrls) {
        try {
          const m = await tryManifest(url);
          manifest = m;
          manifestAt = Date.now();
          source = new URL(url).host;
          tried = [];
          error = '';
          errorCode = '';
          phase = newer() ? 'available' : 'idle';
          log.info(`[update] 最新版本 v${m.version}（本地 v${current}）· ${m.files.size} 个文件 / ${formatBytes(m.totalBytes)} · 来源 ${source}`);
          return view();
        } catch (e) {
          const msg = e?.message || String(e);
          let host = url;
          try { host = new URL(url).host; } catch { /* keep the raw url */ }
          failures.push(`${host}: ${msg}`);
          tried.push({ host, error: msg });
        }
      }
      // keep an older good manifest if we had one; only report if there was none
      if (!manifest) {
        fail('CHECK_FAILED', `所有更新源都连不上（${failures.join('；')}）`);
      } else {
        log.warn(`[update] 检查更新失败，沿用上次结果：${failures.join('；')}`);
        if (phase === 'checking') phase = newer() ? 'available' : 'idle';
      }
      return view();
    })().finally(() => { checking = null; });

    return checking;
  }

  function sample() {
    const now = Date.now();
    if (sampleAt && now - sampleAt >= 400) {
      speed = Math.max(0, Math.round(((bytes - sampleBytes) * 1000) / (now - sampleAt)));
      sampleAt = now;
      sampleBytes = bytes;
    } else if (!sampleAt) {
      sampleAt = now;
      sampleBytes = bytes;
    }
  }

  async function downloadTo(url, dest, signal) {
    const res = await doFetch(url, { signal, headers: { 'user-agent': 'hexmod-updater/1' } });
    if (!res || !res.ok) throw new Error(`HTTP ${res ? res.status : 'no response'}`);
    const declared = Number(res.headers.get('content-length') || 0);
    if (declared > PACK_MAX_BYTES) throw new Error(`安装包过大 (${formatBytes(declared)})`);
    total = manifest.pack.size || declared;
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    const out = fs.createWriteStream(dest);
    try {
      for await (const chunk of res.body) {
        if (signal.aborted) throw new Error('已取消');
        bytes += chunk.length;
        if (bytes > PACK_MAX_BYTES) throw new Error('安装包超出上限');
        if (!out.write(chunk)) await once(out, 'drain');
        sample();
      }
      await new Promise((resolve, reject) => out.end((e) => (e ? reject(e) : resolve())));
    } catch (e) {
      try { out.destroy(); } catch { /* ignore */ }
      throw e;
    }
  }

  function backupOf(version) { return path.join(backupRoot, version); }

  function apply(entries) {
    const backup = backupOf(manifest.version);
    const applied = [];
    try {
      for (const [rel, want] of manifest.files) {
        const src = entries.get(rel);
        if (!src || src.length !== want.size || sha256(src) !== want.sha256) throw new Error(`文件校验失败：${rel}`);
        const dst = path.join(root, ...rel.split('/'));
        const existed = fs.existsSync(dst);
        if (existed) {
          const b = path.join(backup, ...rel.split('/'));
          fs.mkdirSync(path.dirname(b), { recursive: true });
          fs.copyFileSync(dst, b);
        }
        fs.mkdirSync(path.dirname(dst), { recursive: true });
        const tmp = `${dst}.tmp-${process.pid}`;
        fs.writeFileSync(tmp, src);
        fs.renameSync(tmp, dst);
        applied.push({ rel, existed, removed: false });
      }
      for (const rel of manifest.removed) {
        const dst = path.join(root, ...rel.split('/'));
        if (!fs.existsSync(dst)) continue;
        const b = path.join(backup, ...rel.split('/'));
        fs.mkdirSync(path.dirname(b), { recursive: true });
        fs.copyFileSync(dst, b);
        fs.unlinkSync(dst);
        applied.push({ rel, existed: true, removed: true });
      }
    } catch (e) {
      rollback(applied, backup);
      throw e;
    }
    return applied;
  }

  function rollback(applied, backup) {
    for (const item of [...applied].reverse()) {
      try {
        const dst = path.join(root, ...item.rel.split('/'));
        if (item.removed || !item.existed) { fs.rmSync(dst, { force: true }); continue; }
        const b = path.join(backup, ...item.rel.split('/'));
        if (fs.existsSync(b)) { fs.mkdirSync(path.dirname(dst), { recursive: true }); fs.copyFileSync(b, dst); }
      } catch (e) {
        log.error(`[update] 回滚 ${item.rel} 失败`, e);
      }
    }
    log.warn(`[update] 已回滚 ${applied.length} 个文件`);
  }

  function writeState(applied) {
    try {
      fs.mkdirSync(stateRoot, { recursive: true });
      const body = {
        version: manifest.version,
        from: current,
        appliedAt: new Date().toISOString(),
        files: applied.length,
        backup: path.relative(root, backupOf(manifest.version)).replace(/\\/g, '/'),
      };
      const tmp = `${stateFile}.tmp`;
      fs.writeFileSync(tmp, JSON.stringify(body, null, 2));
      fs.renameSync(tmp, stateFile);
      return body;
    } catch (e) {
      log.warn('[update] 无法写更新状态文件', e);
      return null;
    }
  }

  function pruneBackups() {
    try {
      const dirs = fs.readdirSync(backupRoot, { withFileTypes: true }).filter((d) => d.isDirectory())
        .map((d) => ({ name: d.name, at: fs.statSync(path.join(backupRoot, d.name)).mtimeMs }))
        .sort((a, b) => b.at - a.at);
      for (const d of dirs.slice(2)) rmrf(path.join(backupRoot, d.name));
    } catch { /* nothing to prune */ }
  }

  async function run() {
    const stage = path.join(stagingRoot, manifest.version);
    rmrf(stage);
    fs.mkdirSync(stage, { recursive: true });
    const packPath = path.join(stage, manifest.pack.name);
    const urls = mirrorUrls(cfg.mirrors, manifest.pack.url);
    let lastErr = null;
    let ok = false;
    tried = [];
    for (const url of urls) {
      if (ac.signal.aborted) break;
      let host = url;
      try { host = new URL(url).host; } catch { /* raw */ }
      try {
        source = host;
        log.info(`[update] 下载安装包：${source}`);
        bytes = 0; speed = 0; sampleAt = 0; sampleBytes = 0;
        await downloadTo(url, packPath, ac.signal);
        const got = sha256FileSync(packPath);
        if (got !== manifest.pack.sha256) throw new Error('安装包 SHA-256 不匹配');
        ok = true;
        break;
      } catch (e) {
        lastErr = e;
        tried.push({ host, error: e?.message || String(e) });
        rmrf(packPath);
        log.warn(`[update] 源 ${host} 失败：${e?.message || e}`);
      }
    }
    if (!ok) throw new Error(`所有更新源都无法下载${lastErr ? `（${lastErr.message}）` : ''}`);

    if (ac.signal.aborted) throw new Error('已取消');
    phase = 'verifying';
    speed = 0;
    const raw = zlib.gunzipSync(fs.readFileSync(packPath));
    const entries = tarUnpack(raw);
    if (entries.size !== manifest.files.size) throw new Error(`安装包文件数不符（${entries.size} ≠ ${manifest.files.size}）`);
    for (const [rel, want] of manifest.files) {
      const buf = entries.get(rel);
      if (!buf || buf.length !== want.size || sha256(buf) !== want.sha256) throw new Error(`文件校验失败：${rel}`);
    }

    phase = 'applying';
    const applied = apply(entries);
    writeState(applied);
    pruneBackups();
    rmrf(stage);
    bytes = total = manifest.pack.size;
    speed = 0;
    phase = 'done';
    waitingRestart = true;
    log.info(`[update] 更新完成 v${current} → v${manifest.version}（${applied.length} 个文件）。文件已落盘 —— 等所有对局结束、大家回到主页面后再重启（大厅会弹「是否立即重启」）。`);
    clearTimeout(restartTimer);
    if (!restartPoll) {
      restartPoll = setInterval(() => pollRestart(), RESTART_POLL_MS);
      restartPoll.unref?.();
    }
  }

  /** 待重启门禁的轮询：busy>0（有人在局/占用房间）→ 继续等；空闲满 AUTO_RESTART_MS 才自动重启（兜底，通常由人在主页面点「立即重启」）。 */
  function pollRestart() {
    if (!waitingRestart) { clearInterval(restartPoll); restartPoll = null; return; }
    const rooms = busy();
    if (rooms > 0) { idleSince = 0; return; }
    if (!idleSince) idleSince = Date.now();
    if (Date.now() - idleSince >= AUTO_RESTART_MS) {
      log.info(`[update] 主页面空闲超过 ${Math.round(AUTO_RESTART_MS / 60000)} 分钟，自动重启应用更新`);
      forceRestart();
    }
  }

  /** 真正执行重启（清门禁 → restartFn；index.js 的 restartFn 会优雅关服 —— 对局收到 shutdown —— 再 exit 42）。 */
  function forceRestart() {
    waitingRestart = false;
    idleSince = 0;
    clearInterval(restartPoll);
    restartPoll = null;
    clearTimeout(restartTimer);
    restartTimer = setTimeout(() => { try { restartFn(); } catch (e) { log.error('[update] restart failed', e); } }, 150);
  }

  /**
   * v0.04.1：主页面弹窗里「立即重启服务器」的入口（POST /update/restart，同源 JSON 准入与 start/cancel 相同）。
   * 只有「已应用待重启」状态可用；仍有对局/占用房间时拒绝（ROOMS）—— 重启会解散房间，必须等大家回到主页面。
   */
  function restartNow() {
    if (!waitingRestart) return { ok: false, error: 'NO_UPDATE' };
    const rooms = busy();
    if (rooms > 0) return { ok: false, error: 'ROOMS', rooms };
    forceRestart();
    return { ok: true };
  }

  function start() {
    if (['downloading', 'verifying', 'applying'].includes(phase)) return { ok: false, error: 'BUSY' };
    if (!manifest) return { ok: false, error: 'NO_UPDATE' };
    if (!newer()) return { ok: false, error: 'NO_UPDATE' };
    if (!compatible()) return { ok: false, error: 'NEED_FULL' };
    const rooms = busy();
    if (rooms > 0) return { ok: false, error: 'ROOMS', rooms };
    phase = 'downloading';
    error = '';
    errorCode = '';
    bytes = 0;
    total = manifest.pack.size;
    speed = 0;
    ac = new AbortController();
    run().catch((e) => {
      if (ac?.signal.aborted) { if (phase !== 'done') phase = 'cancelled'; return; }
      fail('APPLY_FAILED', e?.message || String(e));
    });
    return { ok: true };
  }

  function cancel() {
    if (!['downloading', 'verifying'].includes(phase)) return { ok: false, error: 'NOT_RUNNING' };
    try { ac?.abort(); } catch { /* ignore */ }
    phase = 'cancelled';
    error = '已取消更新';
    errorCode = 'CANCELLED';
    rmrf(path.join(stagingRoot, manifest?.version || ''));
    return { ok: true };
  }

  function setRestart(fn) { restartFn = fn; }
  function setConfig(next) { cfg = next || loadUpdateConfig(root); }

  /** Read the last applied update (the UI shows it once). */
  function appliedState() {
    try { return JSON.parse(fs.readFileSync(stateFile, 'utf8')); } catch { return null; }
  }

  return { check, start, cancel, restartNow, view, setRestart, setConfig, appliedState, config: () => cfg, current, phases: PHASES };
}
