// server/http/admin.js — 运维面板（v0.05.1）：实时房间 / 玩家 / 流量 / 负载 / 连接超时状态 + 手动关房。
//
// 挂载条件：环境变量 `SP_ADMIN_TOKEN` 非空才挂（否则整块 404，功能不存在）。
// 鉴权：`?token=` 或请求头 `x-admin-token`，定长比较（timingSafeEqual）。
//
// 路由：
//   GET  /admin                → 单页面板（内联 HTML，无外部依赖，3 秒轮询）
//   GET  /api/admin/state      → JSON 快照
//   POST /api/admin/room-close → { code, confirm } 关房（confirm 必须等于 code，二次确认）
//
// 数据来源全部是现成的：`lobby.rooms`（房间/座位）、`lobby.registry`（会话）、`room.match`（关卡/阶段）、
// `traffic.snapshot()`（流量）、`process.*`（负载）。**不写任何状态到磁盘**，重启即清零。

import { timingSafeEqual } from 'node:crypto';
import { monitorEventLoopDelay } from 'node:perf_hooks';

export const ADMIN_HTML_PATH = '/admin';
export const ADMIN_STATE_PATH = '/api/admin/state';
export const ADMIN_CLOSE_PATH = '/api/admin/room-close';

const MB = 1024 * 1024;

function sendJson(res, status, body) {
  const out = JSON.stringify(body);
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(out);
}

function readBody(req, limit = 4096) {
  return new Promise((resolve) => {
    let size = 0;
    const chunks = [];
    req.on('data', (c) => {
      size += c.length;
      if (size > limit) { req.destroy(); resolve(''); return; }
      chunks.push(c);
    });
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    req.on('error', () => resolve(''));
  });
}

/**
 * @param {{ lobby: any, traffic?: any, startedAt?: number, token?: string, log?: any, now?: () => number }} deps
 * @returns {((req: any, res: any, parts: { rawPath: string, query?: string }) => boolean) | null}
 */
export function createAdminHandler({ lobby, traffic = null, startedAt = Date.now(), token, log = null, now = Date.now }) {
  if (!token || !lobby) return null;
  const want = Buffer.from(String(token));
  const admit = (req) => {
    let given = req.headers['x-admin-token'];
    if (!given && typeof req.url === 'string') {
      const q = req.url.indexOf('?') >= 0 ? req.url.slice(req.url.indexOf('?') + 1) : '';
      const m = /(?:^|&)token=([^&]*)/.exec(q);
      if (m) given = decodeURIComponent(m[1]);
    }
    if (typeof given !== 'string' || !given) return false;
    const got = Buffer.from(given);
    return got.length === want.length && timingSafeEqual(got, want);
  };

  const hDelay = monitorEventLoopDelay({ resolution: 20 });
  hDelay.enable();
  let lastCpu = process.cpuUsage();
  let lastCpuAt = now();

  const snapshot = () => {
    const at = now();
    const cu = process.cpuUsage();
    const elapsedMs = Math.max(1, at - lastCpuAt);
    const cpuPct = Math.round((((cu.user - lastCpu.user) + (cu.system - lastCpu.system)) / 1000 / elapsedMs) * 1000) / 10;
    lastCpu = cu; lastCpuAt = at;
    const mem = process.memoryUsage();
    // 先读上一轮采到的循环延迟，再 reset（reset 之后立即读会是 NaN → JSON null）
    const loopMeanMs = hDelay.count > 0 ? Math.round((hDelay.mean / 1e6) * 100) / 100 : 0;
    const loopP99Ms = hDelay.count > 0 ? Math.round((hDelay.percentile(99) / 1e6) * 100) / 100 : 0;
    hDelay.reset();

    const rooms = [];
    let humans = 0; let bots = 0; let matches = 0; let spectators = 0;
    for (const room of lobby.rooms.values()) {
      if (!room || room.disposed) continue;
      const seats = [];
      let hostName = null;
      for (const s of room.seats) {
        if (!s) continue;
        const session = lobby.registry.byId(s.playerId);
        if (s.playerId === room.hostId) hostName = s.name || null;
        if (!s.isBot && !s.left) humans++;
        if (s.isBot) bots++;
        seats.push({
          seat: s.seat,
          playerId: s.playerId,
          name: s.name || '',
          bot: !!s.isBot,
          left: !!s.left,
          ready: !!s.ready,
          connected: s.isBot ? true : !!(session && session.connected),
          addr: session ? session.addr : null,
          idleMin: session ? Math.floor((at - (Number(session.lastActionAt) || at)) / 60000) : null,
          rosterIdleMin: session ? Math.floor((at - (Number(session.rosterSigAt) || at)) / 60000) : null,
          bytesIn: session ? Number(session.bytesIn) || 0 : 0,
          bytesOut: session ? Number(session.bytesOut) || 0 : 0,
        });
      }
      const m = room.match || null;
      if (m) matches++;
      spectators += room.spectators.length;
      let boss = null;
      try { boss = m && typeof m.isBossRound === 'function' ? !!m.isBossRound(m.round) : null; } catch { boss = null; }
      rooms.push({
        code: room.code,
        mode: room.mode || null,
        difficulty: room.difficulty || null,
        hostName,
        seatCap: room.seatCap || null,
        humans: seats.filter((s) => !s.bot && !s.left).length,
        bots: seats.filter((s) => s.bot).length,
        spectators: room.spectators.length,
        spectatorList: room.spectators.map((x) => ({ name: x.name, playerId: x.playerId, connected: !!x.connected })),
        inMatch: !!m,
        round: m ? Number(m.round) || 0 : null,
        phase: m ? String(m.phase || '') : null,
        boss,
        idleSince: room.idleSince || 0,
        seats,
      });
    }
    rooms.sort((a, b) => String(a.code).localeCompare(String(b.code)));

    const snap = traffic && typeof traffic.snapshot === 'function' ? traffic.snapshot() : null;
    return {
      ok: true,
      at: new Date(at).toISOString(),
      uptimeSec: Math.round((at - startedAt) / 1000),
      totals: {
        rooms: rooms.length,
        matches,
        humans,
        bots,
        spectators,
        sessions: lobby.registry ? lobby.registry.size : null,
        sockets: snap ? snap.ws.open : null,
      },
      load: {
        rssMB: Math.round(mem.rss / MB * 10) / 10,
        heapMB: Math.round(mem.heapUsed / MB * 10) / 10,
        cpuPct,
        loopMeanMs,
        loopP99Ms,
        loadavg: typeof process.loadavg === 'function' ? process.loadavg().map((n) => Math.round(n * 100) / 100) : [],
      },
      idlePolicy: {
        connIdleMin: Math.max(0, Number(process.env.SP_IDLE_CONN_MIN ?? 60)),
        roomIdleMin: Math.max(0, Number(process.env.SP_ROOM_IDLE_MIN ?? 5)),
        roomIdleMatchMin: Math.max(0, Number(process.env.SP_ROOM_IDLE_MATCH_MIN ?? 20)),
        sweepSec: Math.max(5, Number(process.env.SP_ROOM_SWEEP_SEC ?? 60)),
      },
      traffic: snap,
      rooms,
    };
  };

  return (req, res, parts) => {
    const path = parts && parts.rawPath ? parts.rawPath : String(req.url || '').split('?')[0];
    if (path !== ADMIN_HTML_PATH && path !== ADMIN_STATE_PATH && path !== ADMIN_CLOSE_PATH) return false;
    if (!admit(req)) { sendJson(res, 401, { ok: false, error: 'unauthorized' }); return true; }

    if (path === ADMIN_HTML_PATH) {
      if (req.method !== 'GET' && req.method !== 'HEAD') { sendJson(res, 405, { ok: false, error: 'method' }); return true; }
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
      res.end(ADMIN_HTML);
      return true;
    }
    if (path === ADMIN_STATE_PATH) {
      if (req.method !== 'GET' && req.method !== 'HEAD') { sendJson(res, 405, { ok: false, error: 'method' }); return true; }
      let body;
      try { body = snapshot(); } catch (e) {
        if (log) log.error?.('[admin] snapshot failed', e);
        sendJson(res, 500, { ok: false, error: 'snapshot failed' });
        return true;
      }
      sendJson(res, 200, body);
      return true;
    }
    // POST /api/admin/room-close
    if (req.method !== 'POST') { sendJson(res, 405, { ok: false, error: 'method' }); return true; }
    readBody(req).then((raw) => {
      let msg = null;
      try { msg = JSON.parse(raw || '{}'); } catch { msg = null; }
      const code = msg && typeof msg.code === 'string' ? msg.code.trim().toUpperCase() : '';
      const confirm = msg && typeof msg.confirm === 'string' ? msg.confirm.trim().toUpperCase() : '';
      if (!code) { sendJson(res, 400, { ok: false, error: 'code required' }); return; }
      if (confirm !== code) { sendJson(res, 400, { ok: false, error: 'confirm mismatch（二次确认未通过）' }); return; }
      const room = lobby.rooms.get(code);
      if (!room) { sendJson(res, 404, { ok: false, error: 'room not found' }); return; }
      try {
        lobby.disposeRoom(room, 'admin');
        if (log) log.info?.(`[admin] room ${code} closed by operator`);
        sendJson(res, 200, { ok: true, code });
      } catch (e) {
        if (log) log.error?.('[admin] close room failed', e);
        sendJson(res, 500, { ok: false, error: 'close failed' });
      }
    }).catch(() => sendJson(res, 400, { ok: false, error: 'bad body' }));
    return true;
  };
}

const ADMIN_HTML = `<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>卫戍协议 · 服务器面板</title>
<style>
:root{--bg:#0d1117;--card:#161b22;--line:#232b36;--tx:#e6edf3;--dim:#8b949e;--ok:#3fb950;--warn:#d29922;--bad:#f85149;--gold:#d9a441}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--tx);font:13px/1.55 ui-sans-serif,system-ui,"Segoe UI",sans-serif}
header{display:flex;flex-wrap:wrap;gap:10px 18px;align-items:center;padding:12px 18px;border-bottom:1px solid var(--line);position:sticky;top:0;background:var(--bg);z-index:5}
h1{margin:0;font-size:15px;font-weight:500;color:var(--gold)}
.kv{color:var(--dim)}.kv b{color:var(--tx);font-weight:500}
main{padding:14px 18px 40px}
table{width:100%;border-collapse:collapse;margin:6px 0 18px}
th,td{text-align:left;padding:6px 8px;border-bottom:1px solid var(--line);white-space:nowrap}
th{color:var(--dim);font-weight:500;font-size:12px}
tr.room:hover{background:#1b2230}
.tag{display:inline-block;padding:0 6px;border-radius:5px;font-size:11px;border:1px solid var(--line);color:var(--dim)}
.tag.ok{color:var(--ok);border-color:rgba(63,185,80,.5)}.tag.warn{color:var(--warn);border-color:rgba(210,153,34,.5)}.tag.bad{color:var(--bad);border-color:rgba(248,81,73,.5)}
button{font:inherit;color:var(--tx);background:#21262d;border:1px solid var(--line);border-radius:6px;padding:3px 10px;cursor:pointer}
button:hover{border-color:var(--bad);color:var(--bad)}
.mono{font-family:ui-monospace,Consolas,monospace}
.seats{color:var(--dim);font-size:12px;white-space:normal}
#mask{position:fixed;inset:0;background:rgba(0,0,0,.65);display:none;align-items:center;justify-content:center;z-index:20}
#dlg{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:18px;max-width:380px;width:92%}
#dlg h2{margin:0 0 8px;font-size:14px;font-weight:500;color:var(--bad)}
#dlg p{margin:0 0 10px;color:var(--dim)}
#dlg input{width:100%;padding:6px 8px;background:#0d1117;border:1px solid var(--line);border-radius:6px;color:var(--tx);font:inherit}
#dlg .row{display:flex;gap:8px;justify-content:flex-end;margin-top:12px}
#dlg .danger{border-color:var(--bad);color:var(--bad)}
#err{color:var(--bad);font-size:12px;min-height:16px;margin-top:6px}
</style></head><body>
<header>
  <h1>卫戍协议 · 服务器面板</h1>
  <span class="kv">房间 <b id="t-rooms">-</b></span>
  <span class="kv">对局中 <b id="t-matches">-</b></span>
  <span class="kv">真人 <b id="t-humans">-</b></span>
  <span class="kv">机器人 <b id="t-bots">-</b></span>
  <span class="kv">连接 <b id="t-sockets">-</b></span>
  <span class="kv">运行 <b id="t-up">-</b></span>
  <span class="kv">RSS <b id="t-rss">-</b></span>
  <span class="kv">CPU <b id="t-cpu">-</b></span>
  <span class="kv">事件循环 <b id="t-loop">-</b></span>
  <span class="kv" id="t-status">·</span>
</header>
<main>
  <div class="kv" id="policy" style="margin-bottom:8px"></div>
  <table><thead><tr>
    <th>房间</th><th>状态</th><th>关卡</th><th>模式</th><th>人数</th><th>座位 / 博士 ID / 空闲</th><th>流量（收 / 发）</th><th></th>
  </tr></thead><tbody id="rows"><tr><td colspan="8" class="kv">加载中…</td></tr></tbody></table>
</main>
<div id="mask"><div id="dlg">
  <h2>确认关闭房间</h2>
  <p>这会立刻解散该房间：对局中止、所有玩家被移出。请把房间码原样输入以确认。</p>
  <p class="mono" id="dlg-code" style="color:var(--tx);font-size:15px"></p>
  <input id="dlg-input" placeholder="输入房间码确认" autocomplete="off">
  <div id="err"></div>
  <div class="row"><button id="dlg-cancel">取消</button><button id="dlg-ok" class="danger" disabled>确认关闭</button></div>
</div></div>
<script>
const TOKEN = new URLSearchParams(location.search).get('token') || '';
const Q = '?token=' + encodeURIComponent(TOKEN);
const fmtBytes = (n) => n < 1024 ? n + ' B' : n < 1048576 ? (n/1024).toFixed(1) + ' KB' : (n/1048576).toFixed(2) + ' MB';
const fmtDur = (s) => { const d = Math.floor(s/86400), h = Math.floor(s%86400/3600), m = Math.floor(s%3600/60); return d ? d+'d '+h+'h' : h ? h+'h '+m+'m' : m+'m'; };
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"]/g, (c) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
let pending = null;

function idleTag(min, limit) {
  if (min == null) return '<span class="tag">-</span>';
  const cls = min >= limit ? 'bad' : min >= limit * 0.5 ? 'warn' : 'ok';
  return '<span class="tag ' + cls + '">' + min + ' 分钟</span>';
}

async function tick() {
  try {
    const r = await fetch('/api/admin/state' + Q, { cache: 'no-store' });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    const d = await r.json();
    document.getElementById('t-rooms').textContent = d.totals.rooms;
    document.getElementById('t-matches').textContent = d.totals.matches;
    document.getElementById('t-humans').textContent = d.totals.humans;
    document.getElementById('t-bots').textContent = d.totals.bots;
    document.getElementById('t-sockets').textContent = d.totals.sockets;
    document.getElementById('t-up').textContent = fmtDur(d.uptimeSec);
    document.getElementById('t-rss').textContent = d.load.rssMB + ' MB';
    document.getElementById('t-cpu').textContent = d.load.cpuPct + '%';
    document.getElementById('t-loop').textContent = d.load.loopMeanMs + ' ms';
    document.getElementById('t-status').textContent = '更新于 ' + new Date(d.at).toLocaleTimeString();
    document.getElementById('policy').textContent = '僵尸连接：连续 ' + d.idlePolicy.connIdleMin + ' 分钟无操作且阵容未变 → 断开；空房：' + d.idlePolicy.roomIdleMin + ' 分钟（对局中 ' + d.idlePolicy.roomIdleMatchMin + ' 分钟）回收；扫描每 ' + d.idlePolicy.sweepSec + ' 秒。';
    const rows = d.rooms.map((x) => {
      const st = x.inMatch ? '<span class="tag warn">对局中</span>' : '<span class="tag ok">等待中</span>';
      const rounds = x.inMatch ? ('R' + x.round + (x.boss ? ' · BOSS' : '') + ' · ' + x.phase) : '-';
      const seats = x.seats.map((s) => {
        const who = '<span class="mono">' + esc(s.name || '?') + '</span> <span class="tag">' + esc(s.playerId.slice(0, 8)) + '</span>';
        const bot = s.bot ? ' <span class="tag">AI</span>' : (s.connected ? '' : ' <span class="tag bad">断线</span>');
        return who + bot + ' ' + idleTag(s.idleMin, d.idlePolicy.connIdleMin);
      }).join('<br>');
      const traffic = x.seats.length
        ? fmtBytes(x.seats.reduce((a, s) => a + s.bytesIn, 0)) + ' / ' + fmtBytes(x.seats.reduce((a, s) => a + s.bytesOut, 0))
        : '-';
      return '<tr class="room"><td class="mono">' + esc(x.code) + '</td><td>' + st + '</td><td>' + esc(rounds) + '</td><td>' +
        esc((x.mode || '') + ' / ' + (x.difficulty || '')) + '</td><td>' + x.humans + ' 人' + (x.bots ? ' + ' + x.bots + ' AI' : '') + '</td>' +
        '<td class="seats">' + (seats || '<span class="kv">空</span>') + '</td><td class="mono">' + traffic + '</td>' +
        '<td><button data-code="' + esc(x.code) + '">关闭</button></td></tr>';
    }).join('');
    document.getElementById('rows').innerHTML = rows || '<tr><td colspan="8" class="kv">当前没有房间</td></tr>';
    document.querySelectorAll('button[data-code]').forEach((b) => { b.onclick = () => openDialog(b.dataset.code); });
  } catch (e) {
    document.getElementById('t-status').innerHTML = '<span style="color:var(--bad)">拉取失败：' + esc(e.message) + '</span>';
  }
}

function openDialog(code) {
  pending = code;
  document.getElementById('dlg-code').textContent = code;
  document.getElementById('dlg-input').value = '';
  document.getElementById('err').textContent = '';
  document.getElementById('dlg-ok').disabled = true;
  document.getElementById('mask').style.display = 'flex';
  document.getElementById('dlg-input').focus();
}
function closeDialog() { pending = null; document.getElementById('mask').style.display = 'none'; }
document.getElementById('dlg-cancel').onclick = closeDialog;
document.getElementById('dlg-input').oninput = (e) => {
  document.getElementById('dlg-ok').disabled = e.target.value.trim().toUpperCase() !== pending;
};
document.getElementById('dlg-ok').onclick = async () => {
  const code = pending;
  const confirm = document.getElementById('dlg-input').value.trim().toUpperCase();
  const btn = document.getElementById('dlg-ok');
  btn.disabled = true;
  try {
    const r = await fetch('/api/admin/room-close' + Q, { method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ code, confirm }) });
    const d = await r.json().catch(() => ({}));
    if (!r.ok || !d.ok) throw new Error(d.error || ('HTTP ' + r.status));
    closeDialog(); tick();
  } catch (e) {
    document.getElementById('err').textContent = '失败：' + e.message;
    btn.disabled = false;
  }
};
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeDialog(); });
tick(); setInterval(tick, 3000);
</script></body></html>`;
