// server/match/match/battleOpts.js — the ONE assembly of the Battle options a Match hands to its Battle class.
//
// A Match assembles a Battle on exactly two paths, and both must produce the SAME fields:
//   * 真跑 — `MatchCombat.newBattle` (server/match/match/combat.js): the battle the server really runs, and the one a
//     bot's rehearsal runs (server/match/bot.js);
//   * 复算 — `MatchClientCombat._specBattle` (server/match/match/clientCombat.js): the headless run of a client field,
//     a takeover, and the `SP_VERIFY` re-computation of a client's result.
// Everything the two paths decide **from the match itself** lives here, once. The per-path inputs stay at the call
// sites: 真跑 spreads its own `opts` (the round's spec-shaped fields), 复算 reads them back out of the client's BattleSpec
// (`createBattleFromSpec` does that reading) — and 复算 adds `recordEvents: false` (see `specBattleOpts` below).
//
// The five keys below accumulated by being written out twice, and the A-fix (DESIGN §28.12.1, docs/design/mod-layer.md)
// is what a missing half costs: `tokenKits` was added to `combat.js` and not to `_specBattle`, so the server
// re-computation ran a kit-carrying room against the built-in registry. A sixth key now has one place to go — and
// `test/battleOpts.test.js` pins that both paths read this one.
//
// KEY DISCIPLINE (byte-for-byte compatibility, the same rule as `server/sim/spec.js` and `server/lobby.js`): every
// optional key is spread ONLY when the match really has it, so a plain install produces the exact object shape it
// produced before each feature landed. An explicitly passed `opts.<key>` always wins (`baseBattleOpts` spreads the
// caller's options over the match's own fields), which is the precedence both call sites had.

// 缺省档的名字（`morphPairing` 那一格的 KEY DISCIPLINE：只有非缺省档才写那个键，而缺省档本身会变）。
import { MORPH_PAIRING_DEFAULT } from '../../../shared/morph.js';

/**
 * Base Battle options of one battle of this match: the match's data source, its sim content mode and its logger, with
 * the caller's own options spread over them (an explicit `opts.data` / `opts.content` / `opts.logger` wins, as it did
 * at both call sites).
 * @param {{ ds: any, battleContent?: string, log?: object }} owner the Match (`this`)
 * @param {object} opts the round's own options (fieldId, kind, seed, …)
 */
export function baseBattleOpts(owner, opts = {}) {
  return { data: owner.ds, content: owner.battleContent, logger: owner.log, ...opts };
}

/**
 * The match-owned extras, in ONE place:
 *   工坊行为层 (docs/WORKSHOP.md §4) — the operator kit table (`kits`, `roomAssets.forRoom(room.modSet)` trimmed to
 *     the room's declared packs, §28.16); 召唤物的行为层 (§4.7) — the summon table, another key space (`tokenKits`);
 *   包声明的战斗逻辑 (`server.battle`, DESIGN §28.17) — the pack's real `install(battle)` functions (`battleInstallers`,
 *     a function cannot cross the wire, so 复算 takes the same array and the browser rebuilds it from the spec);
 *   限伤 override (`SP_BOSS_HIT_LIMIT`, shared/constants.js bossHitLimitFrom) — an explicit per-battle value wins,
 *     absent leaves the key out so the battle falls back to BOSS_HIT_LIMIT.
 * Each key is set only from the match's own copy — never from a process-wide registry.
 */
export function battleOptsFromMatch(owner, opts = {}) {
  const full = baseBattleOpts(owner, opts);
  // an explicit opts.kits always wins (the browser may inject its own map); a match without packs is `null` ⇒ no key,
  // so the battle is byte-for-byte the one a plain install runs
  if (owner.workshopKits && !full.kits) full.kits = owner.workshopKits;
  if (owner.workshopTokenKits && !full.tokenKits) full.tokenKits = owner.workshopTokenKits;
  if (Array.isArray(owner.battleInstallers) && owner.battleInstallers.length && !full.battleInstallers) full.battleInstallers = owner.battleInstallers;
  if (owner.bossHitLimit !== undefined && full.bossHitLimit === undefined) full.bossHitLimit = owner.bossHitLimit;
  // 行为开关 `morphPairing`（DESIGN §28.43.1）：只在**非缺省档**才写这个键 —— 缺省档一个键都不多，于是没声明
  // 这一格的战斗与「不传档位」逐字节相同（KEY DISCIPLINE）。判据是 `MORPH_PAIRING_DEFAULT` 而不是写死的档位名：
  // 缺省档在 2026-10-22 由 `official` 翻成 `plus`，写死的话**显式声明 `official` 的房间会在战斗侧退回 plus**
  // （`Battle` 把这一格压进 `withMorphPairing`，缺键 = 走缺省档）。
  if (owner.morphPairing && owner.morphPairing !== MORPH_PAIRING_DEFAULT && full.morphPairing === undefined) full.morphPairing = owner.morphPairing;
  return full;
}

/**
 * `createBattleFromSpec` options for the SECOND path (`_specBattle`): the same match-owned extras through the same
 * helper — the match's own kit tables, the same installers, the same 限伤 override — plus what only a re-computation
 * needs. Keeping this here (and not in clientCombat.js) is what makes the two paths share one assembly: a sixth key
 * cannot reach one path and stop at the other.
 *
 * `recordEvents` is the ONE deliberate difference: 真跑 records the battle's events (the client-side authority replays
 * them, and `b.opts.recordEvents !== false` is the engine default), while a re-computation only needs the RESULT — it
 * must not pay for a history nobody reads. It therefore does not change a single field of the result.
 * @param {{ ds: any, log?: object, BattleClass: Function }} owner the Match (`this`)
 * @param {{ sharedBoss?: object|null }} [o] `sharedBoss` = the pool a boss-like field credits (server/match/finalAssault.js)
 */
export function specBattleOpts(owner, { sharedBoss = null } = {}) {
  return {
    BattleClass: owner.BattleClass,
    sharedBoss,
    logger: owner.log,
    recordEvents: false,
    ...battleOptsFromMatch(owner, {}),
  };
}
