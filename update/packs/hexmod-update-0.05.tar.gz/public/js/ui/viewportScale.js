// public/js/ui/viewportScale.js — 全局等比缩放（v0.05，替代原来的 CSS 媒体查询）。
//
// 需求（用户）：先前那批「小屏改版式 / 媒体查询」全部回退；改为**运行时判定**：
//   ① 低分辨率（宽 < 900 或 高 < 600 CSS px）或  ② 手机浏览器（UA / 触摸 + 粗指针）
//   → 整个界面按 19.2 × 10.8 的设计稿**等比缩小**，不动任何布局（列数、换行一律保持桌面形态）。
// 手机浏览器横屏是主场景：取 min(视口宽/19.2, 视口高/10.8)，横屏 844×390 → 36px，竖屏 390×844 → 20px。
// 桌面/平板正常分辨率**不接管**：由 theme.css 里 html 的 clamp(40px, …) 原规则决定，行为与旧版逐字节一致。
//
// 判定细节：
//   · 手机浏览器：UA 命中移动端标识，或（多点触控 + pointer: coarse）；桌面触屏（coarse + 鼠标）不算
//   · 视口尺寸优先取 `visualViewport`（手机浏览器地址栏/工具栏占位时 innerHeight 会虚高，横屏尤其明显）
//   · 监听 resize / orientationchange / visualViewport.resize / 指针类型变化，重算（rAF 节流）

const MIN_MOBILE = 10;      // 手机缩到极小也留 10px，保证整屏装得下
const MIN_DESKTOP_FIT = 12; // 桌面小窗（<900×600）的下限
const MAX_FONT = 240;       // 与 theme.css 的上限一致
const MOBILE_UA = /Android|iPhone|iPod|iPad|Mobile|HarmonyOS|Windows Phone|MicroMessenger|Phone/i;

/** 是否手机浏览器（UA 或 触摸 + 粗指针）。 */
export function isMobileBrowser(win = globalThis) {
  const nav = win.navigator || {};
  const ua = String(nav.userAgent || '');
  if (MOBILE_UA.test(ua)) return true;
  const touch = Number(nav.maxTouchPoints || 0) > 1;
  const coarse = !!(win.matchMedia && win.matchMedia('(pointer: coarse)').matches);
  return touch && coarse;
}

/** 视口尺寸（优先 visualViewport，手机横屏时比 innerHeight 准）。 */
export function viewportSize(win = globalThis) {
  const vv = win.visualViewport;
  const w = Math.max(1, Math.round((vv && vv.width) || win.innerWidth || 0));
  const h = Math.max(1, Math.round((vv && vv.height) || win.innerHeight || 0));
  return { w, h };
}

/** 是否需要接管缩放：手机浏览器，或低分辨率（宽 < 900 / 高 < 600）。 */
export function needsFitScale(win = globalThis) {
  if (isMobileBrowser(win)) return true;
  const { w, h } = viewportSize(win);
  return w < 900 || h < 600;
}

/** 等比缩放后的根字号（px）。设计稿 19.2rem × 10.8rem。 */
export function fitFontSize(win = globalThis) {
  const { w, h } = viewportSize(win);
  const raw = Math.min(w / 19.2, h / 10.8);
  const min = isMobileBrowser(win) ? MIN_MOBILE : MIN_DESKTOP_FIT;
  return Math.max(min, Math.min(raw, MAX_FONT));
}

/**
 * 应用一次（可重复调用）。接管时写内联 `font-size` + `data-ui-scale="fit"`；
 * 不需要接管时清掉内联样式，交回 theme.css 的 clamp 规则。
 * @returns {number|null} 实际根字号（未接管为 null）
 */
export function applyViewportScale(win = globalThis) {
  const doc = win.document;
  if (!doc || !doc.documentElement) return null;
  const root = doc.documentElement;
  if (!needsFitScale(win)) {
    root.style.removeProperty('font-size');
    delete root.dataset.uiScale;
    return null;
  }
  const px = Math.round(fitFontSize(win) * 100) / 100;
  root.style.setProperty('font-size', `${px}px`);
  root.dataset.uiScale = 'fit';
  return px;
}

let installed = false;
let raf = 0;

/** 挂监听并立即应用一次（幂等；main.js 启动时调用）。 */
export function installViewportScale(win = globalThis) {
  if (installed) return;
  installed = true;
  const schedule = () => {
    if (typeof win.requestAnimationFrame === 'function') {
      if (raf) win.cancelAnimationFrame(raf);
      raf = win.requestAnimationFrame(() => { raf = 0; applyViewportScale(win); });
    } else {
      applyViewportScale(win);
    }
  };
  applyViewportScale(win);
  win.addEventListener?.('resize', schedule);
  win.addEventListener?.('orientationchange', schedule);
  win.visualViewport?.addEventListener?.('resize', schedule);
  const mq = win.matchMedia?.('(pointer: coarse)');
  if (mq && typeof mq.addEventListener === 'function') mq.addEventListener('change', schedule);
  return applyViewportScale(win);
}
