// public/js/ui/warLadderBar.js — 战争天梯顶栏组件（v0.05，海克斯 bx_war_ladder 专属）
//
// **专属位置**：对局顶栏 `.gtop__center` 的**第一个位置**（搜索按钮左侧）。这个槽位属于战争天梯，
// 其它控件不要插到这里（`gtop__wl` 只在本组件存在时渲染，宽度 flex:0 0 auto，正常流布局 ⇒ 与相邻控件永不重叠）。
// 展开面板从槽位下方浮出（top:100%），落在战场画布上方、不会盖住顶栏里的其它按钮；面板自身 `z-index` 低于模态层。
//
// 数据：`priv.warLadder = { on, ammo, tier, pierce, truePct }`（server/match/player/views.js）。
// 阶梯数学与文案：`shared/warLadder.js` + `shared/hexes.js` 的 `extra.warLadder`（服务端同一份，不用两边各写一遍）。

import { useEffect, useRef, useState } from '../../vendor/hooks.module.js';
import { html } from './components.js';
import { HEXES } from '../../../shared/hexes.js';
import { tierAt, tierCount, nextTier, needForNext } from '../../../shared/warLadder.js';
import { fmtPierce, PIERCE_TERM } from '../../../shared/pierce.js';

const specOf = () => (HEXES.find((h) => h && h.id === 'bx_war_ladder') || {}).warLadder || null;

/** 图标：左半子弹（白）+ 右半拉特兰十字（红）。 */
function LadderIcon({ size = 22 }) {
  const uid = useRef(`wl${Math.random().toString(36).slice(2, 8)}`).current;
  return html`<svg width=${size} height=${size} viewBox="0 0 32 32" fill="none" aria-hidden="true">
    <defs>
      <clipPath id=${`L${uid}`}><rect x="0" y="0" width="16" height="32" /></clipPath>
      <clipPath id=${`R${uid}`}><rect x="16" y="0" width="16" height="32" /></clipPath>
    </defs>
    <circle cx="16" cy="16" r="14.2" fill="#0a0a0a" stroke="rgba(255,255,255,.45)" stroke-width="1.2" />
    <g clip-path=${`url(#L${uid})`}>
      <path d="M11 6.2c2.1 2.2 3.2 4.7 3.2 7.4V24a2.4 2.4 0 0 1-2.4 2.4H10.2A2.4 2.4 0 0 1 7.8 24V13.6c0-2.7 1.1-5.2 3.2-7.4z"
        fill="#ffffff" fill-opacity=".92" />
      <rect x="7.8" y="20.4" width="6.4" height="2.2" rx="1" fill="#0a0a0a" fill-opacity=".65" />
      <circle cx="11" cy="15.4" r="1.5" fill="#0a0a0a" fill-opacity=".6" />
    </g>
    <g clip-path=${`url(#R${uid})`}>
      <path d="M24 7.6v16.8M16.4 16h15.2" stroke="#ff3b3b" stroke-width="2.6" stroke-linecap="round" />
      <circle cx="24" cy="16" r="3.9" fill="none" stroke="#ff3b3b" stroke-width="1.3" />
    </g>
    <path d="M16 2.4v27.2" stroke="#000" stroke-width="1.6" opacity=".92" />
  </svg>`;
}

/**
 * 顶栏战争天梯。
 * @param {{ wl?: { on?: boolean, ammo?: number, tier?: number } | null }} props
 */
export function WarLadderBar({ wl }) {
  const [open, setOpen] = useState(false);
  const [tip, setTip] = useState(null);      // { i, x, y, below }
  const [now, setNow] = useState(0);
  const spec = specOf();
  const ammo = Math.max(0, Math.trunc(Number(wl && wl.ammo) || 0));

  // 达成一档时让横条闪一下（不阻塞操作）
  const tierNow = spec ? tierCount(spec, ammo) : 0;
  const prevTier = useRef(tierNow);
  useEffect(() => {
    if (tierNow > prevTier.current) {
      setNow(Date.now());
      prevTier.current = tierNow;
    }
  }, [tierNow]);
  const flash = now > 0;

  if (!wl || !wl.on || !spec) return null;
  const next = nextTier(spec, ammo);
  const cur = tierNow > 0 ? tierAt(spec, tierNow - 1) : null;
  const prevT = cur ? cur.t : 0;
  const pct = Math.max(0, Math.min(100, ((ammo - prevT) / Math.max(1, next.t - prevT)) * 100));

  // 面板里的节点窗口：当前阶前 2 ~ 后 4
  const from = Math.max(0, tierNow - 2);
  const to = tierNow + 4;
  const lo = tierAt(spec, from).t;
  const hi = tierAt(spec, to).t;
  const span = Math.max(1, hi - lo);

  const showTip = (i, el) => {
    const r = el.getBoundingClientRect();
    const below = r.top < 110;
    setTip({ i, x: r.left + r.width / 2, y: below ? r.bottom + 8 : r.top - 8, below });
  };

  return html`<div class="gtop__wl" data-ui-slot="war-ladder" aria-label=${'战争天梯'}>
    <button type="button" class=${`wbar tapx${flash ? ' is-flash' : ''}`} onClick=${() => setOpen((v) => !v)}
      aria-expanded=${open ? 'true' : 'false'} title=${`战争阶梯：已消耗 ${ammo} 发`}>
      <span class="wbar__icon"><${LadderIcon} size=${22} /></span>
      <span class="wbar__bar"><span class="wbar__fill" style=${`width:${pct}%`}></span></span>
      <span class="wbar__txt">${ammo}<i>/</i>${next.t}</span>
      <span class="wbar__tier">${`第 ${tierNow} 阶`}</span>
    </button>

    ${open ? html`<div class="wlpanel" role="dialog" aria-label=${'战争天梯'}>
      <div class="wlpanel__head">
        <span class="wlpanel__icon"><${LadderIcon} size=${20} /></span>
        <b>${'战争阶梯'}</b>
        <span class="wlpanel__chip">${`第 ${tierNow} 阶`}</span>
        ${Number(wl.pierce) > 0
          ? html`<span class="wlpanel__chip wlpanel__chip--pierce" title=${PIERCE_TERM.desc}>${fmtPierce(Number(wl.pierce) / 100)} ${PIERCE_TERM.name}</span>`
          : null}
        <span class="wlpanel__meta">${ammo} 发 · ${`下一阶还差 ${needForNext(spec, ammo)}`}</span>
      </div>
      <div class="wltrack">
        <div class="wltrack__rail"></div>
        <div class="wltrack__done" style=${`width:${Math.max(0, Math.min(100, ((ammo - lo) / span) * 100))}%`}></div>
        ${Array.from({ length: to - from + 1 }, (_, n) => {
          const i = from + n;
          const t = tierAt(spec, i);
          const st = ammo >= t.t ? 'done' : (i === tierNow ? 'now' : 'todo');
          const left = Math.max(0.6, Math.min(99.4, ((t.t - lo) / span) * 100));
          return html`<div class=${`wlnode ${st === 'todo' ? '' : st}`} style=${`left:${left}%`} data-i=${i}
            onMouseEnter=${(e) => showTip(i, e.currentTarget)}
            onMouseLeave=${() => setTip(null)}
            onTouchStart=${(e) => {
              const el = e.currentTarget;
              const timer = setTimeout(() => showTip(i, el), 320);
              el.__wlTimer = timer;
            }}
            onTouchEnd=${(e) => { clearTimeout(e.currentTarget.__wlTimer); setTimeout(() => setTip(null), 1500); }}
            onTouchMove=${(e) => clearTimeout(e.currentTarget.__wlTimer)}>
            <span>${t.t >= 10000 ? `${(t.t / 1000).toFixed(1)}k` : t.t}</span>
          </div>`;
        })}
      </div>
      <div class="wlpanel__foot">
        <span>${cur ? `${cur.t} 发 · ${cur.label}` : '尚未达成任何阶梯'}</span>
        <span class="wlpanel__next">${`下一阶 ${next.t} 发 · ${next.label}`}</span>
      </div>
      ${tip ? html`<div class=${`wltip ${ammo >= tierAt(spec, tip.i).t ? 'done' : (tip.i === tierNow ? 'now' : 'todo')}${tip.below ? ' is-below' : ''}`}
        style=${`left:${tip.x}px;top:${tip.y}px`}>
        <b>${tierAt(spec, tip.i).t} 发</b><em>${`第 ${tip.i + 1} 阶`}</em>
        <p>${tierAt(spec, tip.i).label}</p>
        <i>${ammo >= tierAt(spec, tip.i).t ? '已达成' : (tip.i === tierNow ? `还差 ${tierAt(spec, tip.i).t - ammo} 发` : '未达成')}</i>
      </div>` : null}
    </div>` : null}
  </div>`;
}
