// public/js/ui/ownerName.js — 作者/服主昵称的标记（v0.04.3，用户要求）。
//
// 名字表在 shared/ownerNames.js（服务端也用同一份做「只有本地网络能用这两个名字」的门禁）。
// 界面里凡是带 `sp-owner-name` 类的昵称，CSS 会在前面画一个金色「OP」角标（public/css/components.css）。

import { isOwnerName as isProtectedOwnerName } from '../../../shared/ownerNames.js';

/** @param {string} name @returns {boolean} 这个名字是否受保护（作者名） */
export function isOwnerName(name) {
  return isProtectedOwnerName(name);
}

/**
 * Plain DOM: put `name` (and `suffix`) into `element`; an owner name gets the golden OP badge.
 * @param {Element} element @param {string} name @param {string} [suffix]
 */
export function decorateOwnerName(element, name, suffix = '') {
  if (!element) return element;
  element.textContent = `${name ?? ''}${suffix}`;
  if (isProtectedOwnerName(name)) element.classList.add('sp-owner-name');
  return element;
}
