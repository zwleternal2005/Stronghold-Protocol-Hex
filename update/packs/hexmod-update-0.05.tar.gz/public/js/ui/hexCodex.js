// public/js/ui/hexCodex.js — 海克斯图鉴 (this fork): a read-only fullscreen overlay listing EVERY hex grouped by its
// grade (白银 / 黄金 / 炫彩). Opened from the room options panel's 图鉴 button (next to the 启用海克斯 switch).
//
// 布局完全自包含（`.hexcodex__*`，样式在 room.css）：**不要**复用 spov / spcard 骨架 —— spov 是 absolute 定位、
// 依赖对局界面的定位祖先与左侧栏偏移（game-panels.css `inset: 0 0 0 2.8rem`），在房间页会塌陷成一小块且无法滚动
// （实测踩过）。这里用 fixed 全屏浮层 + 内部滚动的面板，Esc / 遮罩 / 关闭键三种方式关闭。

import { html, MicroLabel } from './components.js';
import { useEffect, useState } from '../../vendor/hooks.module.js';
import { GIcon, Img, RichText } from './gameComponents.js';

import { data } from '../data.js';
import { HEXES, HEX_GRADE, HEX_GRADE_NAME, HEX_GRADE_COLOR } from '../../../shared/hexes.js';
import { hexChangeOf } from '../../../shared/hexChanges.js';
import { HexGlyphIcon } from './hexGlyph.js';

/** `#rrggbb` → `rgba(..., a)`（品质轮廓用；脏输入原样返回）。 */
function withAlpha(color, a) {
  const m = /^#([0-9a-fA-F]{6})$/.exec(String(color || ''));
  if (!m) return color || null;
  const n = parseInt(m[1], 16);
  return `rgba(${(n >> 16) & 255}, ${(n >> 8) & 255}, ${n & 255}, ${a})`;
}
import { t } from '../../../shared/i18n.js';

const cx = (...p) => p.flat().filter(Boolean).join(' ');

/** verdict → 图鉴标记（符号 / class 后缀 / 提示用词）。 */
const VERDICT_MARK = {
  buff: { mod: 'buff', glyph: '↑', word: '增强' },
  nerf: { mod: 'nerf', glyph: '↓', word: '削弱' },
  tweak: { mod: 'tweak', glyph: '—', word: '调整' },
};

/**
 * 把改动文本里的 `[[…]]` 标记切成片段（纯函数，防脏输入；不用正则）。
 * - `[[…]]` 内的片段 → `{ hl: true }`（渲染成绿色加粗）
 * - 没有闭合 `]]`、或 `[[ ]]` 为空 → 原样当普通文本（逐字前进，不会吞字也不会死循环）
 * - 非字符串 / 空串 → `[]`；换行 → `{ br: true }`
 * @param {any} src
 * @returns {Array<{ text: string, hl: boolean, br: boolean }>}
 */
export function splitChangeMarks(src) {
  if (typeof src !== 'string' || !src) return [];
  const out = [];
  let buf = '';
  const flush = () => { if (buf) { out.push({ text: buf, hl: false, br: false }); buf = ''; } };
  let i = 0;
  while (i < src.length) {
    const ch = src[i];
    if (ch === '\n') { flush(); out.push({ text: '', hl: false, br: true }); i += 1; continue; }
    if (ch === '[' && src[i + 1] === '[') {
      const end = src.indexOf(']]', i + 2);
      const inner = end === -1 ? '' : src.slice(i + 2, end);
      if (inner) { // 有闭合标记且非空 —— 才算一段高亮
        flush();
        out.push({ text: inner, hl: true, br: false });
        i = end + 2;
        continue;
      }
      // 未闭合 / 空 `[[…]]`：落回普通文本
    }
    buf += ch;
    i += 1;
  }
  flush();
  return out;
}

/** 渲染一段带 `[[…]]` 的改动文本：高亮片段用绿色加粗（`.hexcodex__was`），其余交给父级暗色。 */
function ChangeText({ text, class: cls }) {
  const segs = splitChangeMarks(text);
  return html`<span class=${cls}>${segs.map((s, i) => (s.br
    ? html`<br key=${i} />`
    : s.hl
      ? html`<span key=${i} class="hexcodex__was">${s.text}</span>`
      : s.text))}</span>`;
}

/** One grade's section: its header (the 等级 chip + count) and the hex rows. `picking` = 图鉴选择模式（自选海克斯）。 */
function CodexGroup({ grade, hexes, assets, picking, picked, pickMax, onToggle }) {
  const color = HEX_GRADE_COLOR[grade];
  return html`<section class="hexcodex__group" aria-label=${t(HEX_GRADE_NAME[grade])}>
    <header class="hexcodex__ghead">
      <span class="hexcodex__grade" style=${color ? `--grade-c:${color}` : null}>${t(HEX_GRADE_NAME[grade] || grade)}</span>
      <span class="hexcodex__gcount num">${t('{n} 条', { n: hexes.length })}</span>
    </header>
    <div class="hexcodex__cards">
      ${hexes.map((c) => {
        const tags = Array.isArray(c.tags) ? c.tags : (c.tag ? [c.tag] : []);
        const on = picking && Array.isArray(picked) && picked.includes(c.id);
        const full = picking && Array.isArray(picked) && picked.length >= pickMax && !on;
        const change = hexChangeOf(c.id);
        const mark = change ? VERDICT_MARK[change.verdict] : null;
        // 品质发光轮廓 (v0.03.2)：卡片按品质上色（白银/黄金/炫彩），不再是通体白边
        const gc = HEX_GRADE_COLOR[c.grade] || null;
        const frame = gc ? `--grade-line:${withAlpha(gc, 0.5)};--grade-glow:${withAlpha(gc, 0.32)}` : null;
        const deltaTitle = mark ? t('本次更新：{v}{label}', { v: mark.word, label: change.label ? ` · ${t(change.label)}` : '' }) : null;
        return html`<div key=${c.id} class=${cx('hexcodex__card', picking && 'is-pickable', on && 'is-picked', full && 'is-full')} style=${frame}
            onClick=${picking ? () => onToggle(c.id) : null}
            role=${picking ? 'button' : null} aria-pressed=${picking ? (on ? 'true' : 'false') : null}
            title=${picking ? (on ? t('点击取消选择') : full ? t('已选满，先取消一条') : t('点击选择')) : null}>
          <span class="hexcodex__icon">
            <${HexGlyphIcon} card=${c} cls="hexcodex__glyph" assets=${assets} />
          </span>
          <span class="hexcodex__text">
            <b class="hexcodex__name">${t(c.name)}${mark
              ? html`<span class=${cx('hexcodex__delta', `hexcodex__delta--${mark.mod}`)} title=${deltaTitle}>${mark.glyph}</span>`
              : null}${on ? html`<span class="hexcodex__picked num">${picked.indexOf(c.id) + 1}</span>` : null}</b>
            <span class="hexcodex__tags">
              ${tags.map((tag) => html`<span key=${tag} class="hexcodex__tag">${t(tag)}</span>`)}
              ${c.requires?.mode === 'coop' ? html`<span class="hexcodex__tag">${t('仅联合模式')}</span>` : null}
              ${c.firstDraftOnly ? html`<span class="hexcodex__tag">${t('首轮限定')}</span>` : null}
            </span>
            <${RichText} text=${t(c.desc)} class="hexcodex__desc" />
            ${change ? html`<div class="hexcodex__cmp">
              <span class="hexcodex__cmplabel">${t('改动前')}</span>
              ${change.before ? html`<${ChangeText} text=${change.before} class="hexcodex__cmpwas" />` : null}
              ${change.added ? html`<span class="hexcodex__addrow"><i class="hexcodex__addtag">＋ ${t('新增：')}</i><${ChangeText} text=${change.added} class="hexcodex__cmpadded" /></span>` : null}
            </div>` : null}
          </span>
        </div>`;
      })}
    </div>
  </section>`;
}

/**
 * 海克斯图鉴 overlay：fixed 全屏、面板内部滚动，Esc / 遮罩 / 关闭键关闭。
 * 选择模式 (this fork)：传 `onPickDone(selectedIds)` + `picked`（已选队列）+ `pickMax`（上限）后，
 * 每张卡可点击勾选（带顺序角标），底部出现「确认」——供房间选项的「自选海克斯」使用。
 */
export function HexCodex({ onClose = () => {}, onPickDone = null, picked: pickedProp = null, pickMax = 3 }) {
  const picking = typeof onPickDone === 'function';
  const [picked, setPicked] = useState(() => (Array.isArray(pickedProp) ? pickedProp.slice() : []));
  useEffect(() => {
    const onKey = (e) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);
  const toggle = (id) => {
    if (!picking) return;
    setPicked((cur) => {
      if (cur.includes(id)) return cur.filter((x) => x !== id);
      if (cur.length >= pickMax) return cur;
      return [...cur, id];
    });
  };
  const assets = data.get('assets');
  const groups = [HEX_GRADE.SILVER, HEX_GRADE.GOLD, HEX_GRADE.PRISMATIC]
    .map((g) => [g, HEXES.filter((h) => h.grade === g)])
    .filter(([, list]) => list.length);
  return html`<div class="hexcodex" role="dialog" aria-modal="true" aria-label=${t('海克斯图鉴')}>
    <div class="hexcodex__veil" onClick=${onClose} aria-hidden="true"></div>
    <div class="hexcodex__panel">
      <header class="hexcodex__head">
        <div class="hexcodex__titles">
          <${MicroLabel} tone="mint">${picking ? t('HEX // 自选海克斯') : t('HEX // 海克斯图鉴')}</${MicroLabel}>
          <h2 class="hexcodex__title">${picking ? t('自选海克斯') : t('海克斯图鉴')}</h2>
          <p class="hexcodex__sub">${picking
            ? t('点击卡片按顺序选择 {max} 条 —— 对局的每次海克斯草案将按此顺序自动发放', { max: pickMax })
            : t('全部 {n} 条 · 按等级分类 · 每次对局从所选等级的池子里抽三选一', { n: HEXES.length })}</p>
          <p class="hexcodex__note">${t('带 ↑ / ↓ / — 标记的卡片代表本次版本改过，悬停可看改动内容')}</p>
        </div>
        <button type="button" class="hexcodex__close" onClick=${onClose} aria-label=${t('关闭')}>${t('关闭')} ✕</button>
      </header>
      <div class="hexcodex__body">
        ${groups.map(([g, list]) => html`<${CodexGroup} key=${g} grade=${g} hexes=${list} assets=${assets}
          picking=${picking} picked=${picked} pickMax=${pickMax} onToggle=${toggle} />`)}
      </div>
      ${picking ? html`<footer class="hexcodex__foot">
        <span class="num">${t('已选 {n}/{max}', { n: picked.length, max: pickMax })}</span>
        <button type="button" class="btn btn--amber" disabled=${!picked.length}
          onClick=${() => { onPickDone(picked.slice()); onClose(); }}>
          ${picked.length ? t('确认选择') : t('尚未选择')}
        </button>
      </footer>` : null}
    </div>
  </div>`;
}
