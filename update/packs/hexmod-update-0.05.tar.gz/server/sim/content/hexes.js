// server/sim/content/hexes.js — 通用海克斯的战斗侧 (this fork)。
//
// 目前只有「飞升」系列（shared/hexes.js 的 `delayedOps: { delay, allStats }`）：
//   战斗开始 `delay` 秒后，己方**全体干员**（含之后部署的）四维 ×(1 + allStats)，直到战斗结束。
//   · 到点时在场的干员：复制 matchMul 乘上去（matchMul 可能与对局选项增益共享对象，绝不能原地改）；
//   · 之后部署的干员：spawn 时读 battle 玩家对象的 `ascensionMul`（battle/players.js）；
//   · 召唤物 / 装置（kind !== 'op'）不吃 —— 与宝宝学院（opsAcademy）同口径。
// 同名海克斯不会重复（一局一条）；自选多条件外时按条数叠乘（每条独立注册一次延迟）。

import { HEXES } from '../../../shared/hexes.js';

const num = (v) => (typeof v === 'number' && Number.isFinite(v) ? v : (typeof v === 'string' && v !== '' && Number.isFinite(+v) ? +v : undefined));

export function install(battle) {
  // 全能穿透 · input.pierce (v0.05)：联防 spec（我来兜底++ 等）下发的穿透 —— 干员出场后再挂，
  // 出生瞬间 u.s 还没初始化，addBuff 会被丢掉。
  {
    const attach = (unit) => {
      if (!unit || unit.kind !== 'op' || !unit.ownerId) return;
      const owner = (battle.players || []).find((x) => x && x.playerId === unit.ownerId);
      const pct = Number(owner && owner.input && owner.input.pierce);
      if (!(Number.isFinite(pct) && pct > 0)) return;
      const v = Math.min(1, pct / 100);
      battle.addBuff(unit, { key: 'input:pierce', persist: true, mods: { defIgnorePct: v, resIgnorePct: v } });
    };
    battle.on('spawn', ({ unit }) => attach(unit));
    battle.on('deploy', ({ unit }) => attach(unit));
  }
  for (const p of battle.players || []) {
    if (!p || !p.playerId) continue;
    const ids = Array.isArray(p.input?.hexes) ? p.input.hexes : [];
    if (!ids.length) continue;
    const specs = HEXES.filter((h) => h && h.delayedOps && ids.includes(h.id));
    for (const spec of specs) {
      const delay = Math.max(0, num(spec.delayedOps.delay, 12));
      const pct = Math.max(0, num(spec.delayedOps.allStats, 0));
      if (!(pct > 0)) continue;
      // 平衡调整 (v0.05)：同一条海克斯可能还带 pierce（全属性 25% 折算成全能穿透）——
  // 与全属性同一个时间点生效，之后部署的干员同样吃到（p.hexPierce 供 spawn 读）。
  const pierce = Math.max(0, num(spec.pierce, 0)) / 100;
  const addPierce = (u) => {
    if (!(pierce > 0) || !u) return;
    battle.addBuff(u, { key: 'hex:pierce:' + spec.id, persist: true, mods: { defIgnorePct: pierce, resIgnorePct: pierce } });
  };
  if (pierce > 0) {
    battle.on('spawn', ({ unit }) => {
      if (!unit || unit.ownerId !== p.playerId || unit.kind !== 'op') return;
      if (!(Number(p.hexPierce) > 0)) return;      // 还没到点
      addPierce(unit);
    });
  }
      battle.on('battleStart', () => {
        battle.after(delay, () => {
          if (battle.finished) return;
          const mul = 1 + pct;
          // 之后部署的干员也吃到（spawn 时乘；players.js 读）
          p.ascensionMul = (Number(p.ascensionMul) || 1) * mul;
          // 已在场的干员：matchMul 复制后乘（永不原地改共享对象）
          let n = 0;
          for (const u of battle.allyUnits || []) {
            if (!u || u.ownerId !== p.playerId || u.kind !== 'op' || !u.alive) continue;
            const b = u.matchMul || {};
            u.matchMul = {
              hpMul: (Number(b.hpMul) || 1) * mul,
              atkMul: (Number(b.atkMul) || 1) * mul,
              defMul: (Number(b.defMul) || 1) * mul,
              resMul: (Number(b.resMul) || 1) * mul,
              aspdFlat: Number(b.aspdFlat) || 0,
            };
            u.markDirty();
            n++;
          }
          if (pierce > 0) {
            p.hexPierce = pierce;
            for (const u of battle.allyUnits || []) {
              if (!u || u.ownerId !== p.playerId || u.kind !== 'op' || !u.alive) continue;
              addPierce(u);
            }
          }
          battle.log(`[hex] ${spec.name}：玩家 ${p.playerId} 的 ${n} 名在场干员全属性 +${Math.round(pct * 100)}%${pierce > 0 ? `、全能穿透 +${Math.round(pierce * 1000) / 10}%` : ''}（战斗结束前一直生效）`);
        });
      }, { priority: 50 });
    }
  }
}
