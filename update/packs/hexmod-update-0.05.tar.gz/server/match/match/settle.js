// server/match/match/settle.js — Match methods: SETTLE (the LP loss — a leaker's 联防 survivors —, stats, bounty coins,
// the IN_BATTLE layer gains clamped by layerGainRoom, CHAR_DAMAGE tickers, eliminations, the 联防 outcome the SETTLE
// view carries) and RESULT (finish: m.result to every human still here, onEnd).
// Installed on Match.prototype by server/match/Match.js (a method container: never instantiated; `this` is the match).

import { PHASE, layerGainRoom } from '../../../shared/constants.js';
import { uniteSurvivors } from '../unite.js';
import { buildResult } from '../results.js';
import { FLOW_TICKER_PRIORITY, DELAYS } from './common.js';
import { msg } from '../../../shared/i18n.js';
import { onSettle, resetRoundCounters } from '../botEmotes.js';

export class MatchSettle {
  /**
   * 名刀·司命 (v0.05)：生命值**将低于 1** 时由 settle 调用。
   * 规则：触发后进入 deathSave.cooldown 回合冷却（`ps.famedReadyRound`）；冷却期内返回 null（不保命）；
   * 冷却结束后可再次触发，且**每次都再叠加一次** `hpBonus`（`ps.famedHpBonus` 累加，battleInput 的 buffs 读它）。
   * @returns {{ lp:number, name:string, cooldown:number, procs:number }|null}
   */
  famedBladeTry(ps) {
    if (!ps) return null;
    for (const h of this.hexAllOf(ps)) {
      const ds = h && h.deathSave;
      if (!ds) continue;
      const readyAt = Math.max(0, Math.trunc(Number(ps.famedReadyRound) || 0));
      if (readyAt > 0 && this.round < readyAt) continue;     // 冷却中
      const cd = Math.max(1, Math.trunc(Number(ds.cooldown) || 5));
      ps.famedReadyRound = this.round + cd;
      ps.famedProcs = Math.max(0, Math.trunc(Number(ps.famedProcs) || 0)) + 1;
      ps.famedHpBonus = (Number(ps.famedHpBonus) || 0) + (Number(ds.hpBonus) || 0);
      return {
        lp: Math.max(1, Math.trunc(Number(ds.lp) || 1)),
        name: h.name,
        cooldown: cd,
        procs: ps.famedProcs,
      };
    }
    return null;
  }

  settle(plan, uniteResult) {
    this.phase = PHASE.SETTLE;
    this.runner = null;
    this._stopClientCombat();
    // the pending in-battle gains the views showed become persistent below (alive players) or lapse (DESIGN §20.15)
    for (const ps of this.order) if (ps.pendingLayerGains) { ps.pendingLayerGains = null; ps.dirty(); }
    const cap = this.gd.lpCapPerRound;
    // a 联防 battle that could not run at all (synthetic result) must not wipe the leakers' losses: charge their own leaks
    const uniteRan = !!(plan && uniteResult && !uniteResult.synthetic);
    const survivors = uniteRan ? uniteSurvivors(plan, uniteResult) : null;
    // The 联防's outcome as data for the SETTLE view (m.public.uniteResult, views.js; GitHub #235, PR #112 by @Convey123):
    // each client pops the official result box from it (ui/gameLogic/phases.js uniteResultBox) — `through` = the leakers'
    // enemies that still got through (uncapped; only decides whether 「全员无伤！」 is true), `losses` = every alive
    // player's own LP charge of this round, the same `loss` deducted below, so the box and the LP bar never disagree. A
    // leaker's own battle leaks are not its charge in a 联防 round, which is why the client cannot work the number out
    // itself. No ticker line: the official reports the outcome in the one dialog. null when no 联防 resolved.
    this.uniteResultView = uniteRan && plan.leakers.length ? {
      through: plan.leakers.reduce((n, lk) => n + Math.max(0, survivors.get(lk.playerId) || 0), 0),
      helpers: plan.helpers.map((p) => p.playerId),
      leakers: plan.leakers.map((p) => p.playerId),
      losses: {},
    } : null;
    const alive = this.alivePlayers();
    for (const ps of alive) {
      const r = this.lastResults.get(ps.playerId) || { leaked: [], perfect: true, coins: 0, layerGains: {}, killed: 0, damageDealt: 0 };
      const counted = (r.leaked || []).filter((l) => l && l.counted !== false).length;
      const loss = uniteRan && plan.leakers.includes(ps) ? Math.min(cap, survivors.get(ps.playerId) || 0) : Math.min(cap, counted);
      if (this.uniteResultView) this.uniteResultView.losses[ps.playerId] = loss;
      // 海克斯 名刀·司命 (this fork): 生命值首次将低于 1 时保命 —— 回复 saveLp 点（本回合不再减少：本回合的扣减
      // 就只有这一次，钳到 saveLp 即是），之后整局干员 +hpBonus 生命（battleInput 的 buffs 里乘上）。首领战的
      // 团队共享池（bossRounds）不走这里，名刀不生效。
      let savedBy = null;
      if (ps.lp - loss < 1) savedBy = this.famedBladeTry(ps);
      ps.lp = savedBy ? savedBy.lp : ps.lp - loss;
      if (savedBy) {
        this.toast(ps, 'info',
          `${savedBy.name} · 生命值回复至 ${ps.lp}（干员生命加成已叠加，第 ${savedBy.procs} 次触发；${savedBy.cooldown} 回合后可再次触发）`);
      }
      ps.stats.lpLost += loss;
      ps.stats.leaks += counted;
      ps.stats.kills += Number(r.killed) || 0;
      ps.stats.dmgDealt += Number(r.damageDealt) || 0;
      // 海克斯自身伤害 (v0.03.3)：本场 sim 回传的 hexDamage 并进台账（「本局海克斯详情」里显示累计伤害）
      if (r.hexDamage && typeof r.hexDamage === 'object' && typeof this.hexStatAdd === 'function') {
        for (const [hid, dmg] of Object.entries(r.hexDamage)) {
          if (typeof hid === 'string' && Number(dmg) > 0) this.hexStatAdd(ps, hid, { damage: Number(dmg) });
        }
      }
      ps.stats.healing += Number(r.healingDone) || 0;
      // Per-unit totals for the settlement's MVP (results.js mvpOf; owner's rule 2026-10-06: the result screen speaks
      // with each player's OWN team MVP). The verified battle report (fields.js `unitStats`) is the only place per-unit
      // damage/kills exist, so they are summed per defId here — and never leave the server except as the chosen MVP.
      const mergeUnits = (list) => {
        for (const u of Array.isArray(list) ? list : []) {
          if (!u || typeof u.defId !== 'string') continue;
          const cur = ps.stats.unitStats.get(u.defId) || { dmg: 0, kills: 0, heal: 0 };
          cur.dmg += Math.max(0, Number(u.dmg) || 0);
          cur.kills += Math.max(0, Math.trunc(Number(u.kills) || 0));
          cur.heal += Math.max(0, Number(u.heal) || 0);
          ps.stats.unitStats.set(u.defId, cur);
        }
      };
      mergeUnits(r.unitStats);
      if (r.perfect !== false && counted === 0) ps.stats.perfectRounds++;
      // bounty coins (own battle + unite kills) are credited to the next prep
      let coins = Math.max(0, Math.trunc(Number(r.coins) || 0));
      const up = uniteResult && uniteResult.perPlayer && uniteResult.perPlayer[ps.playerId];
      if (up) {
        coins += Math.max(0, Math.trunc(Number(up.coins) || 0));
        ps.stats.dmgDealt += Number(up.damageDealt) || 0;
        ps.stats.kills += Number(up.killed) || 0;
        mergeUnits(up.unitStats);   // 联防 kills count for the MVP too
      }
      // perfect-payout bounties (战术特训): own phase perfect
      for (const b of ps.bounties) if (b.card.payout === 'perfect' && counted === 0 && r.perfect !== false) coins += b.card.coin;
      if (coins > 0) { ps.pendingFunds += coins; ps.stats.fundsGained += coins; }
      for (const b of ps.bounties) b.roundsLeft--;
      ps.bounties = ps.bounties.filter((b) => b.roundsLeft > 0);
      // IN_BATTLE layer gains (normal battles only), at most the room left under the match's layer cap (999, or unbounded
      // with the room flag 对局选项·层数上限解除 — as the battle's live copy: Battle.addLayers); a bond at the cap gains
      // nothing and dispatches nothing. 海克斯 核心盟约 (this fork): 层数最多的激活盟约 50% 概率再 +1
      for (const [bondId, n] of Object.entries(r.layerGains || {})) {
        if (!this.gd.bond(bondId) || !(n > 0)) continue;
        const before = ps.layers[bondId] || 0;
        const bonus = this.hexCoreBondExtra(ps, bondId, before);
        const add = layerGainRoom(before, Math.floor(n) + (bonus > 0 ? bonus : 0), this.layerCap());
        if (!(add > 0)) continue;
        ps.layers[bondId] = before + add;
        if (bonus > 0) this.toast(ps, 'info', `核心盟约 · ${this.gd.bond(bondId)?.name || bondId} 额外获得 1 层`);
        this.dispatch(ps, 'onLayers', { bondId, from: before, to: ps.layers[bondId], reason: 'battle' });
      }
      this._charDamageTickers(ps, r);
      this.dispatch(ps, 'onBattleResult', { result: r, lpLoss: loss, perfect: counted === 0 && r.perfect !== false, unite: uniteResult || null });
      ps.recompute();
    }
    for (const ps of alive) {
      if (ps.lp <= 0) {
        ps.lp = 0;
        ps.eliminate(this.round);
        this.toast(ps, 'error', '你的目标生命值耗尽，已被淘汰');
        this.tickerText(msg('{name}博士的目标生命值已耗尽', { name: ps.name }), FLOW_TICKER_PRIORITY);
      }
    }
    this.fields = [];
    this.watchers.clear();
    this.markPublic();
    onSettle(this); // one emote per alive AI per round (enabled by default; SP_BOT_EMOTES=0 silences it)
    this.setDeadline(DELAYS.SETTLE / 1000, () => this.afterSettle(), { silent: this.soloUntimed });
  }

  /**
   * CHAR_DAMAGE tickers: one per board unit of the battle (its highest threshold); units created in battle (summons,
   * no board uid) count once per unit type (the highest of them) — a result can never announce more units than the
   * lineup has kinds of.
   */
  _charDamageTickers(ps, r) {
    const steps = (Array.isArray(this.gd.config.broadcasts) ? this.gd.config.broadcasts : []).filter((b) => b.type === 'CHAR_DAMAGE' && Array.isArray(b.params)).map((b) => Number(b.params[0])).filter((n) => n > 0).sort((a, b) => b - a);
    if (!steps.length) return;
    const board = new Set();
    for (const p of ps.board.values()) board.add(p.uid);
    const best = new Map();
    for (const u of r.unitStats || []) {
      if (!u) continue;
      const key = Number.isInteger(u.uid) && board.has(u.uid) ? `uid:${u.uid}` : `def:${u.defId}`;
      const cur = best.get(key);
      if (!cur || (Number(u.dmg) || 0) > (Number(cur.dmg) || 0)) best.set(key, u);
    }
    for (const u of best.values()) {
      const hit = steps.find((s) => (u.dmg || 0) >= s);
      if (hit) this.tickerFor('CHAR_DAMAGE', [ps.name, u.name || u.defId, String(hit)], { playerId: ps.playerId, param: String(hit) });
    }
  }

  afterSettle() {
    if (!this.alivePlayers().length) { this.finish({ victory: false, reason: 'eliminated' }); return; }
    resetRoundCounters(this); // AI bot merge-counter resets each round (server/match/botEmotes.js)
    this.startRound(this.round + 1);
  }

  finish({ victory, hiddenCleared = false, reason = 'defeat' }) {
    if (this.ended || this.disposed) return;
    this.ended = true;
    if (this.runner) { try { this.runner.stop(); } catch { /* ignore */ } this.runner = null; }
    this._stopClientCombat();
    this.cancel(this._phaseTimer);
    this.cancel(this._turnTimer);
    for (const h of this._timers) { try { this.sched.clearTimeout(h); } catch { /* ignore */ } }
    this._timers.clear();
    this.phase = PHASE.RESULT;
    this.deadline = 0;
    for (const f of this.fields) f.live = false;
    this.outcome = { victory: !!victory, hiddenReached: this.hiddenReached, hiddenCleared: !!hiddenCleared, reason };
    let result;
    try {
      result = buildResult(this, this.outcome);
    } catch (e) {
      this.reportError('buildResult', e);
      result = { t: 'm.result', victory: !!victory, roundsPassed: 0, reason, modeId: this.modeId, difficulty: this.difficulty, players: [] };
    }
    this.lastResultMsg = result;
    // the match's LAST m.public is sent in full: the lobby keeps that frame and replays it to a resume / reload that
    // comes back to the result screen without a baseline to merge into (a delta there could not be applied — DESIGN
    // §8.2, incremental frame)
    this.markPublicFull();
    this.markPublic();
    try { this.flush(true); } catch (e) { this.reportError('flush', e); }
    // every human still here gets the settlement — the spectator seats the same public rows (none of them their own)
    for (const ps of this._viewers()) this.sendTo(ps.playerId, { ...result, playerId: ps.playerId });
    const { t, ...summary } = result;
    void t;
    summary.errors = this.errorCount;
    // 走的是哪条路径，不许静默 (业主裁令 2026-10-12): 参与人数决定超容变体（每人独立池 / 分小队联防），
    // 所以结算日志里必须看得到人数与闸门状态。
    this.log?.info?.(`[match] ${this.roomCode} settled (${summary.reason}) participants=${this.participants} variant=${this.variant === true}`);
    try { this.onEndFn(summary); } catch (e) { this.reportError('onEnd', e); }
  }
}
