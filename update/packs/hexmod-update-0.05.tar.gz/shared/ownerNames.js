// shared/ownerNames.js — 作者/服主身份名（v0.04.3，用户要求）。
//
// 两个名字（大小写不敏感、忽略首尾空白）：
//   · 在界面上带**金色 OP 角标**（public/js/ui/ownerName.js 渲染，CSS .sp-owner-name）；
//   · 只有**本地网络（同一个 Wi-Fi / 局域网）**的客户端能用 —— 公网（含内网穿透进来的玩家）说自己是这两个名字
//     会被 server/net.js 的 hello 直接拒绝（"name is reserved"）。
//
// 为什么门禁放在服务端：名字是客户端自己报的；没有服务端这一层，任何人改个名字就能冒充作者并拿到 OP 角标。

/** @type {readonly string[]} 作者名（规范化后比较：小写 + 去空白） */
export const OWNER_NAMES = Object.freeze(['zwl', 'Eternal千溟兮']);

const norm = (name) => String(name ?? '').trim().toLowerCase();

/** @param {string} name @returns {boolean} 这个昵称是否受保护（用来决定要不要检查来源地址） */
export function isOwnerName(name) {
  const n = norm(name);
  return !!n && OWNER_NAMES.some((x) => norm(x) === n);
}

/**
 * 这个地址是不是「本地网络」：回环 / 局域网私有段 / 链路本地 / IPv6 ULA。
 * 内网穿透（cloudflared 等）在 `trustProxy: 'auto'` 下会解析成真实公网来源，因此远程玩家拿到的是公网地址。
 * @param {string} addr 形如 `127.0.0.1`、`192.168.43.12`、`::1`、`fe80::1`、`2001:db8::1`
 * @returns {boolean}
 */
export function isPrivateAddress(addr) {
  const a = String(addr ?? '').trim().toLowerCase().replace(/^\[|\]$/g, '');
  if (!a) return false;
  const v4 = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(a.split('%')[0]);
  if (v4) {
    const [o1, o2] = [Number(v4[1]), Number(v4[2])];
    if (o1 === 127) return true;                       // 回环
    if (o1 === 10) return true;                        // 10/8
    if (o1 === 192 && o2 === 168) return true;         // 192.168/16（家用 Wi-Fi / 热点）
    if (o1 === 172 && o2 >= 16 && o2 <= 31) return true; // 172.16/12
    if (o1 === 169 && o2 === 254) return true;         // 169.254/16 链路本地
    return false;
  }
  const v6 = a.split('%')[0];
  if (v6 === '::1') return true;
  if (/^f[cd]/.test(v6)) return true;                  // fc00::/7 ULA
  if (/^fe[89ab]/.test(v6)) return true;               // fe80::/10 链路本地
  return false;
}
