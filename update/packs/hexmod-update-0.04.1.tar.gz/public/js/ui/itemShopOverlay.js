// public/js/ui/itemShopOverlay.js — 道具商店 (this fork, v0.04.1)。
//
// 准备阶段花「数据价 ×5」直接购买任意普通装备的浮层（server/match/player/economy.js itemShopBuy）：
//   · 视觉与海克斯选取界面同源（.hxd 的蓝金白配色；样式在 hex.css 末尾的 .itsh* 段）；
//   · 顶栏：标题 + 实时资金（m.private.funds，买完服务端推送自动刷新）+ 关闭商店；
//   · 只能买 等阶 ≤ 商店等级 的装备（priv.shop.level；高阶整行锁死只展示）；
//   · 「解除牌库全部装备数量限制」——服务端 acquireItem({ ignorePool: true })，货源无限（UI 不显示库存）。
// 数据全部来自客户端已有的 data（items.json + assets.json），不需要新通道。

import { html, Icon } from './components.js';
import { Img, CoinGlyph } from './gameComponents.js';
import { itemIconUrl } from '../assets.js';
import { data } from '../data.js';
import { t } from '../../../shared/i18n.js';

const TIER_NAME = { 1: '一阶', 2: '二阶', 3: '三阶', 4: '四阶', 5: '五阶', 6: '六阶' };
const TIER_COLOR = { 1: '#a8a8a8', 2: '#f2f2f2', 3: '#34e6b2', 4: '#34b8d8', 5: '#f8bf00', 6: '#f88000' };

const cx = (...p) => p.flat().filter(Boolean).join(' ');

/** 普通装备全量（金色合成版 _b 不卖 —— 它只能由 2 件同名合成）。 */
export function itemShopStock() {
  const items = data.get('items') || {};
  return Object.values(items)
    .filter((r) => r && Number.isFinite(r.tier) && r.tier >= 1 && !r.isGolden && !r.unavailable)
    .sort((a, b) => a.tier - b.tier || (a.id < b.id ? -1 : 1));
}

function ItemCard({ rec, level, funds, onBuy }) {
  const price = (Number.isFinite(rec.price) && rec.price >= 0 ? rec.price : 2) * 5;
  const locked = rec.tier > level;
  const afford = funds >= price;
  return html`<div class=${cx('itsh__card', locked && 'is-locked')}>
    <div class="itsh__top">
      <span class="itsh__icon"><${Img} src=${itemIconUrl(data.get('assets'), rec)} fallback=${html`<${Icon} name="flag" />`} /></span>
      <span class="itsh__main">
        <b class="itsh__name">${t(rec.name || rec.id)}</b>
        <span class="itsh__tier" style=${`--tc:${TIER_COLOR[rec.tier] || '#a8a8a8'}`}>${t(TIER_NAME[rec.tier] || rec.tier)} · T${rec.tier}</span>
      </span>
    </div>
    <p class="itsh__desc">${t(rec.desc || '')}</p>
    <div class="itsh__row">
      <span class="itsh__price"><${CoinGlyph} /><b class="num">${price}</b><s>×5</s></span>
      ${locked
        ? html`<span class="itsh__lock"><${Icon} name="lock" />${t('等阶锁定')}</span>`
        : html`<button type="button" class="itsh__buy" disabled=${!afford}
            title=${afford ? t('购买「{name}」', { name: rec.name || rec.id }) : t('资金不足')}
            onClick=${() => onBuy(rec)}>${afford ? t('购买') : t('资金不足')}</button>`}
    </div>
  </div>`;
}

/**
 * 道具商店浮层。`onBuy(rec)` 由调用方发 g.itemShopBuy；资金与商店等级来自 m.private。
 * @param {{ open: boolean, onClose: Function, onBuy: Function, priv: any }} props
 */
export function ItemShopOverlay({ open, onClose, onBuy, priv }) {
  if (!open) return null;
  const funds = Number(priv?.funds) || 0;
  const level = Number(priv?.shop?.level) || 1;
  const stock = itemShopStock();
  const tiers = [...new Set(stock.map((r) => r.tier))].sort((a, b) => a - b);
  return html`<div class="itsh" role="dialog" aria-modal="true" aria-label=${t('道具商店')} onClick=${(e) => { if (e.target === e.currentTarget) onClose(); }}>
    <div class="itsh__panel">
      <div class="itsh__head">
        <div class="itsh__title">
          <span class="itsh__micro">ITEM SHOP // EQUIPMENT</span>
          <b>${t('道具商店')}</b>
        </div>
        <div class="itsh__funds"><${CoinGlyph} /><b class="num">${funds}</b><span>${t('当前资金')}</span></div>
        <button type="button" class="itsh__close" onClick=${onClose}><${Icon} name="close" />${t('关闭商店')}</button>
      </div>
      <div class="itsh__rules">
        <span>${t('商店等级')}<b class="num">Lv.${level}</b></span>
        <i>${t('价格 = 原价 ×5')}</i>
        <i>${t('限购等阶 ≤ 商店等级')}</i>
        <i>${t('牌库装备数量限制已解除')}</i>
      </div>
      <div class="itsh__body">
        ${tiers.map((tr) => html`<div class="itsh__tierrow" key=${tr}>
          <div class="itsh__tiercap"><b>${t(TIER_NAME[tr] || tr)}装备</b><span class="num">TIER ${tr}</span>
            ${tr > level ? html`<span class="itsh__tierlock">${t('商店等级不足 · 解锁需 Lv.{lv}', { lv: tr })}</span>` : null}
          </div>
          <div class="itsh__grid">
            ${stock.filter((r) => r.tier === tr).map((r) => html`<${ItemCard} key=${r.id} rec=${r} level=${level} funds=${funds} onBuy=${onBuy} />`)}
          </div>
        </div>`)}
      </div>
    </div>
  </div>`;
}
