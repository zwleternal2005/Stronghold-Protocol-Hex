/**
 * 策略双路线分流（Band Routes）—— 数据与接口定义 · 未实装
 * ============================================================================
 * 状态：DESIGN ONLY。本模块**目前没有被任何文件 import**，import 它不会产生任何
 * 运行时副作用；它是《docs/design/band-routes.md》§3 的唯一权威数据源。
 *
 * 交互原型（可点击，视觉规格来源）：public/dev/band-split-picker.html
 * 设计文档（UI 规格 / 协议改动点 / 施工清单）：docs/design/band-routes.md
 *
 * 将来谁消费本模块：
 *   - 客户端 UI  public/js/screens/bandDraft.js   —— 详情栏路线卡的文案/标签/参数
 *                  （经 public/js/data.js 预载，或直接 `import { BAND_ROUTES } from ...`）
 *   - 服务器结算  server/match/**                  —— ROUTE_PARAMS 供对局效果计算
 *   - 校验       server/match/match/phases.js      —— pickBand(ps, bandId, route) 里 isValidRoute
 *
 * ⚠ 实装时禁止把「占位路线」渲染进正式 UI：BAND_ROUTES 里没有条目的策略 =
 *   「该策略尚未设计双路线」，UI 必须回退为单栏原效果（bandRoutesOf 返回 null）。
 * ============================================================================
 */

/** 路线 ID 的合法取值（g.band 意图 payload.route 与落账 d.routes[playerId] 的域）。 */
export const BAND_ROUTE_IDS = /** @type {const} */ ({
  BATTLE: 'battle', // A · 战斗类（黑红卡）
  ECON: 'econ',     // B · 经济类（黄白卡）
});

/**
 * 每条路线的展示定义。
 * @typedef {Object} RouteDef
 * @property {string} name  中文名（走 i18n 时保留 key 语义，首版直接中文）
 * @property {string} en    右上角英文小标（BATTLE / ECONOMY）
 * @property {string} icon  单字图标（原型用 ⚔ / ⛁；实装若接 GIcon 请换 shared 的 iconBond 管线）
 * @property {string} desc  效果文案，**富文本片段**：数字用 <b> 包裹，经现有 RichText 管线渲染
 * @property {string[]} tags 卡底小标签（0~2 个为宜，过窄容器会换行错位）
 */

/**
 * 双路线文案表。键 = bandId（data/bands.json）。
 * 当前只有华法琳（band_bldsk）有作者定稿文案；其余策略补文案时**只改这一个表**。
 *
 * @type {Readonly<Record<string, { battle: RouteDef, econ: RouteDef }>>}
 */
export const BAND_ROUTES = Object.freeze({
  // 华法琳 · 重点监护 —— 作者 2026-10-19 口径（原效果：开局按等阶给随机干员盟约层数+2）
  band_bldsk: Object.freeze({
    battle: Object.freeze({
      name: '战斗路线',
      en: 'BATTLE',
      icon: '⚔',
      desc: '每通过该策略获得 <b>14</b> 层，全体干员获得 <b>+5%</b> 全属性提升',
      tags: ['全体强化', '叠层成长'],
    }),
    econ: Object.freeze({
      name: '经济路线',
      en: 'ECONOMY',
      icon: '⛁',
      desc: '策略效果触发时有 <b>20%</b> 的概率获得等量的资金',
      tags: ['资金收益', '概率触发'],
    }),
  }),
  // ↓ 其余策略逐个定稿后照上面的形状追加；追加前 UI 一律回退单栏。
});

/**
 * 路线数值参数（对局结算用 —— 本版**不接**，仅定义契约防止实装时文案与数值搅在一起）。
 * 语义待定项见设计文档 §5：叠加规则 / 「等量资金」基准。
 *
 * @type {Readonly<Record<string, { battle: { layerStep: number, statPct: number }, econ: { chance: number } }>>}
 */
export const ROUTE_PARAMS = Object.freeze({
  band_bldsk: Object.freeze({
    // A：通过该策略每累计 14 层 → 全体干员全属性 +5%（叠加性=待定，默认按可叠加实现前的占位）
    battle: Object.freeze({ layerStep: 14, statPct: 5 }),
    // B：策略效果触发时 20% 概率获得等量资金（等量基准=待定）
    econ: Object.freeze({ chance: 0.20 }),
  }),
});

/** 某策略是否有双路线（false ⇒ UI 回退单栏原效果；不要为缺条目策略硬造占位卡）。 */
export function bandRoutesOf(bandId) {
  return Object.prototype.hasOwnProperty.call(BAND_ROUTES, bandId) ? BAND_ROUTES[bandId] : null;
}

/** 路线值合法性（服务器 pickBand 落账前的唯一校验入口；null/undefined 视为「未选」放行）。 */
export function isValidRoute(route) {
  if (route == null) return true; // 未选（旧客户端 / 超时接管 / AI 代选）—— 落 null
  return route === BAND_ROUTE_IDS.BATTLE || route === BAND_ROUTE_IDS.ECON;
}

/** 归一化：非法值一律折成 null（与 §3.2 兼容性约定一致：永不因 route 报错）。 */
export function normalizeRoute(route) {
  return isValidRoute(route) ? (route ?? null) : null;
}

/** 诊断用：还有多少策略没配双路线（实装进度一目了然）。 */
export function routelessCount(allBandIds) {
  return (allBandIds || []).filter((id) => !bandRoutesOf(id)).length;
}
