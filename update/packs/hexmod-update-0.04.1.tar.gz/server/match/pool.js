// server/match/pool.js — the SHARED chess pool (copies per base chess, across all players), per-match bans,
// copy-weighted shop rolls (research 00-INDEX §3, §6; DESIGN §6.2).
//
// Model:
//   * Every visible (non-hidden, non-DIY) base chess that is not banned this match has `cap` copies
//     (config.economy.poolCopies[tier], measured identity overrides; co-op shared stock doubled). `left` is the
//     signed capacity minus occupation; the public left() and shop sampling clamp a deficit to zero.
//   * Owning a piece takes copies: a normal piece holds 1, an elite holds 3 (merge of 3 normals). Shop displays
//     do NOT reserve copies. An item buy fails (SOLD_OUT) when left = 0; an operator card already shown in the shop or a
//     reward can still be taken and overdraws (a negative raw left, the debt — GitHub #498, the owner's decision).
//   * Pieces remember how many copies they hold (`piece.poolCopies`), so selling / elimination / temp wipes return
//     exactly what was taken — chess granted by effects while the pool is empty (or hidden/banned chess) hold 0.
//   * Invariant: raw left ≤ cap and raw left + Σ held copies == cap. Mimic can exceed stock, but its copies still occupy it.
//
// Rolls: each chess slot draws ONE copy uniformly from all remaining copies of eligible chess with tier ≤ shop level
// ("copy-weighted"; duplicates within a roll allowed). The item slot picks a tier with the same tier shares, then a
// uniform shop-eligible item of that tier (falling back to lower tiers). A roll may add entries outside the pool
// (`extra`, after its own): one player's 自选 stock — the ordinary shop passes diyRollEntries (the shopLevel gate);
// the promotion reward and random grants pass diyStockEntries (the roll's own tier, DESIGN §32.23). Weighted by its
// copies like any chess, drawn by that player only.

/**
 * Per-match disabled bond set D and banned chess (research 01 A2): D = uniform sample of `core` core bonds and `addon`
 * add-on bonds among weight > 0 bonds that are active in the mode. A visible chess is banned iff every one of its
 * bonds is in D ∪ mode.inactiveBondIds.
 * @param {import('./gamedata.js').GameData} gd
 * @param {Function} rng seeded rng (createRng)
 * @returns {{ drawn: string[], staticOff: string[], banned: string[] }}
 */
export function drawDisabledBonds(gd, rng) {
  const { core: nCore, addon: nAddon } = gd.bans(gd.difficulty);
  const staticOff = [...gd.modeInactiveBonds].filter((b) => gd.bond(b)).sort();
  const eligible = gd.bondIds.filter((b) => {
    const bond = gd.bond(b);
    return bond && Number(bond.weight) > 0 && !gd.modeInactiveBonds.has(b);
  });
  const core = eligible.filter((b) => gd.bond(b).isCore);
  const addon = eligible.filter((b) => !gd.bond(b).isCore);
  const drawn = [...sample(core, nCore, rng), ...sample(addon, nAddon, rng)].sort();
  const off = new Set([...drawn, ...staticOff]);
  const banned = [];
  for (const id of gd.visibleChess) {
    const c = gd.chess(id);
    const bonds = Array.isArray(c.bonds) ? c.bonds : [];
    if (bonds.length > 0 && bonds.every((b) => off.has(b))) banned.push(id);
  }
  return { drawn, staticOff, banned };
}

function sample(arr, n, rng) {
  const a = arr.slice();
  rng.shuffle(a);
  return a.slice(0, Math.max(0, Math.min(n, a.length)));
}

export class SharedPool {
  /**
   * @param {import('./gamedata.js').GameData} gd
   * @param {{ banned?: Iterable<string>, support?: Iterable<string> }} [opts] `support` = the operators the players
   *   brought as 助战 (shared/support.js): each one gets ONE extra copy for this match, and is added even when the
   *   match's random bans took it out of the pool — a brought operator must be purchasable, which is the whole point of
   *   borrowing it. The extra copy belongs to the MATCH, not to the player who brought it (the pool is shared; in co-op
   *   a teammate may buy it too). `cap` and `left` both grow, so the pool invariant (`left + Σ held == cap`) holds.
   */
  constructor(gd, { banned = [], support = [] } = {}) {
    this.gd = gd;
    const ban = new Set(banned);
    /** @type {Map<string, { cap: number, left: number, tier: number, support?: boolean }>} */
    this.entries = new Map();
    for (const id of gd.visibleChess) {
      if (ban.has(id)) continue;
      const cap = gd.poolCopies(id);
      if (cap <= 0) continue;
      this.entries.set(id, { cap, left: cap, tier: gd.tierOf(id) });
    }
    /** 本局带进来的助战干员（去重、排序；只留真的能当助战的那些）。 */
    this.support = [];
    for (const id of [...new Set(support)].sort()) {
      if (typeof id !== 'string' || !id || !gd.chess(id)) continue;
      this.support.push(id);
      const e = this.entries.get(id);
      if (e) { e.cap += 1; e.left += 1; e.support = true; }
      else this.entries.set(id, { cap: 1, left: 1, tier: gd.tierOf(id), support: true });
    }
    this.banned = [...ban].sort();
  }

  /** Whether a base chess is part of this match's pool (visible, not banned — or brought as 助战). */
  has(baseId) { return this.entries.has(baseId); }
  /** Whether this chess is in the pool because somebody brought it as 助战. */
  isSupport(baseId) { return this.entries.get(baseId)?.support === true; }
  cap(baseId) { return this.entries.get(baseId)?.cap ?? 0; }
  left(baseId) { return Math.max(0, this.entries.get(baseId)?.left ?? 0); }

  /** Take up to n copies; returns the number actually taken (0 when not in the pool / empty). */
  take(baseId, n = 1, { overdraw = false } = {}) {
    const e = this.entries.get(baseId);
    if (!e || !(n > 0)) return 0;
    const k = overdraw ? Math.floor(n) : Math.min(Math.max(0, e.left), Math.floor(n));
    e.left -= k;
    return k;
  }

  /** Return n copies (clamped at the cap). Returns the number actually returned. */
  give(baseId, n = 1) {
    const e = this.entries.get(baseId);
    if (!e || !(n > 0)) return 0;
    const k = Math.min(e.cap - e.left, Math.floor(n));
    e.left += k;
    return k;
  }

  /**
   * Remaining copies of eligible chess (tier ≤ maxTier, or exactly `tier`): the pool's entries, then `extra` ([id, entry]
   * pairs of the same shape — a player's 自选 stock) under the same filters.
   */
  _eligible({ maxTier = 6, tier = null, filter = null, extra = null, ignoreCounts = false } = {}) {
    const out = [];
    const scan = (list) => {
      for (const [id, e] of list) {
        if (!ignoreCounts && e.left <= 0) continue;
        if (tier != null ? e.tier !== tier : e.tier > maxTier) continue;
        if (filter && !filter(id, e)) continue;
        out.push([id, ignoreCounts ? 1 : e.left]);
      }
    };
    scan(this.entries);
    if (extra) scan(extra);
    return out;
  }

  /**
   * Copy-weighted roll: one copy uniformly among remaining copies of eligible chess. Returns a base id or null.
   * @param {Function} rng
   * @param {{ maxTier?: number, tier?: number|null, filter?: (id: string, e: object) => boolean,
   *   extra?: Iterable<[string, { left: number, tier: number }]>|null }} [opts]
   */
  roll(rng, opts = {}) {
    const el = this._eligible(opts);
    let total = 0;
    for (const [, n] of el) total += n;
    if (total <= 0) return null;
    let r = rng() * total;
    for (const [id, n] of el) { r -= n; if (r < 0) return id; }
    return el[el.length - 1][0];
  }

  /** Tier shares of a copy-weighted roll at shop level `maxTier` (current remaining copies). */
  tierShares(maxTier) {
    const t = {};
    let total = 0;
    for (const [, e] of this.entries) {
      if (e.tier > maxTier || e.left <= 0) continue;
      t[e.tier] = (t[e.tier] || 0) + e.left;
      total += e.left;
    }
    const out = {};
    for (const k of Object.keys(t)) out[k] = total > 0 ? t[k] / total : 0;
    return out;
  }

  /**
   * Item roll for the shop's item slot: tier by the chess tier shares at this level, uniform item within the tier,
   * falling back to lower tiers when a tier has no item. Returns an item id or null.
   *
   * `restrict`（可选，行为开关 `shopBias: "bondBias"`）：`(id, stock) => boolean`，**只缩小候选集、不加权**。抽到
   * 的阶级照旧由棋子份额决定（那一半一字不动）；三类扫描（本阶级 → 更低阶级 → 更高阶级）里，先在这一级的
   * **官方候选**（≥1 件）上挑一件**合偏向且库存拿得动**的；挑不出来就照旧用这一级的官方名单 —— 于是「偏向」
   * 永远不会把商店的装备槽变成空的，也不会改变候选阶级（`shopBias` 的 `effect` 逐字这么写）。
   * 不给谓词 ⇒ `restrict` 为 null，每一步都走官方名单，与从前同一份结果。
   *
   * @param {() => number} rng @param {number} maxTier
   * @param {{ canGain: (id: string) => boolean, pick: (rng: () => number, list: string[]) => string }|null} [stock]
   * @param {((id: string, stock: any) => boolean)|null} [restrict]
   */
  rollItem(rng, maxTier, stock = null, restrict = null) {
    const shares = this.tierShares(maxTier);
    const tiers = Object.keys(shares).map(Number).sort((a, b) => a - b);
    let tier = null;
    if (tiers.length) {
      let r = rng();
      for (const t of tiers) { r -= shares[t]; if (r < 0) { tier = t; break; } }
      if (tier == null) tier = tiers[tiers.length - 1];
    } else {
      tier = 1 + Math.floor(rng() * Math.max(1, maxTier));
    }
    for (let t = tier; t >= 1; t--) {
      const id = this._pickItemTier(rng, t, stock, restrict);
      if (id) return id;
    }
    for (let t = tier + 1; t <= 6; t++) {
      const id = this._pickItemTier(rng, t, stock, restrict);
      if (id) return id;
    }
    return null;
  }

  /**
   * One tier of `rollItem`: the official candidate list of that tier (`stock.canGain`), then — when a 偏向 is
   * declared — the same list narrowed to it. `pick` is asked FIRST on the narrowed list and only then on the official
   * one, so a tier whose entire stock is held still falls through to the next tier exactly as it does today.
   */
  _pickItemTier(rng, t, stock, restrict) {
    const all = (this.gd.shopItemsByTier[t] || []).filter(id => !stock || stock.canGain(id));
    if (!all.length) return null;
    const draw = (list) => (stock ? stock.pick(rng, list) : list[Math.floor(rng() * list.length)]);
    if (restrict) {
      const narrowed = all.filter(id => restrict(id, stock));
      if (narrowed.length) {
        const hit = draw(narrowed);
        if (hit) return hit;
      }
    }
    return draw(all);
  }

  /** { baseId: left } snapshot (tests / diagnostics). */
  snapshot() {
    const o = {};
    for (const [id, e] of this.entries) o[id] = Math.max(0, e.left);
    return o;
  }

  totalLeft() {
    let n = 0;
    for (const e of this.entries.values()) n += Math.max(0, e.left);
    return n;
  }
}

/** Shared equipment stock, derived from actual ownership. Merges, equips and returns cannot lose a reservation:
 * normal equipment occupies one, upgraded equipment two. Shop/choice displays reserve nothing. Source: the original
 * experiment BV1eLXXBqEgF, 1:30 and 2:30. [ASSUMED] An item that is consumed/destroyed or removed by elimination no
 * longer occupies stock, consistently with the video's ownership model; this is not a per-match purchase limit. */
export class SharedItemPool {
  constructor(gd, players) { this.gd = gd; this.players = players; }
  cap(id) { return this.gd.itemPoolCopies(id); }
  need(id) { return this.gd.isGolden(id) ? 2 : 1; }
  held(id) {
    const base = this.gd.baseIdOf(id);
    let count = 0;
    const see = p => {
      if (!p) return;
      // 道具商店 (v0.04.1)：ignorePool 买来的装备带 exemptPool 标记 —— 「解除牌库数量限制」的超出部分
      // 不占库存（否则 canGain 对所有其他来源永久关闭）。合成金版不带标记，照常计数。
      if (p.kind === 'item' && this.gd.baseIdOf(p.id) === base) count += p.exemptPool ? 0 : this.need(p.id);
      for (const item of p.items || []) if (this.gd.baseIdOf(item.id) === base) count += item.exemptPool ? 0 : this.need(item.id);
    };
    for (const ps of this.players()) {
      for (const p of ps.hand) see(p);
      for (const p of ps.temp) see(p);
      for (const p of ps.board.values()) see(p);
    }
    return count;
  }
  left(id) { const cap = this.cap(id); return cap == null ? Infinity : Math.max(0, cap - this.held(id)); }
  /**
   * v0.04.1（用户 2026-10-19）：**装备库存上限全局解除** —— 不只道具商店，所有来源（商店抽取 / 特殊刷新 /
   * SP 草案 / 授予）都不再受「cap − held」的库存闸门约束。cap / held 保留为纯统计（invariants 不再判 held > cap）；
   * 工坊 `shopBias` 等注入的自定义 stock 谓词不受影响（那是调用方自己的过滤器）。
   */
  canGain(id) { return true; }
  /** Stock gates eligibility, not probability: retain the existing uniform item draw or explicit data weights.
   * The measured stock table alone does not establish shop probabilities. */
  pick(rng, ids, weights = null) {
    const list = [...new Set(ids)].filter(id => this.canGain(id));
    const pairs = list.map(id => [id, weights ? Math.max(0, Number(weights.get(id)) || 0) : 1]);
    const total = pairs.reduce((n, p) => n + Math.max(0, p[1]), 0);
    if (!(total > 0)) return null;
    let r = rng() * total;
    for (const [id, weight] of pairs) if ((r -= Math.max(0, weight)) < 0) return id;
    return pairs.at(-1)?.[0] || null;
  }
}

/**
 * 行为开关 `shopBias: "bondBias"` 的谓词：这件装备是不是「偏向」的那一类 —— 它的 `giveBondId` 落在
 * `bonds`（这个玩家**已激活**盟约的 id 集合）里。**只读，不授予**：授予盟约是 `giveBondId` 本来的语义，
 * 由装备自己的规则（`server/match/bondsMeta.js` 的 `pieceBonds`）管，这一层一个字节都不碰它。
 *
 * 与 `SharedPool.rollItem` 的 `restrict` 同一个签名（`(id, stock) => boolean`）。把盟约集合单独传进来，
 * 是因为这条谓词要能被**纯**地测（不需要造一局对局）。
 *
 * @param {import('./gamedata.js').GameData} gd
 * @param {Iterable<string>} bonds 这个玩家已激活盟约的 id
 * @returns {(id: string, stock?: any) => boolean}
 */
export function bondBiasPreference(gd, bonds) {
  const wanted = bonds instanceof Set ? bonds : new Set(bonds || []);
  return (id) => {
    if (!wanted.size) return false;
    const rec = gd.item(id);
    return !!(rec && typeof rec.giveBondId === 'string' && wanted.has(rec.giveBondId));
  };
}
