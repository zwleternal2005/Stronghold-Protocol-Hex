// shared/hexMod.js — 海克斯模组 (this fork) 的版本号与「检查更新」纯逻辑（服务端与客户端共用）。
//
// 版本口径：HEX_MOD_VERSION 是**模组自己的**版本（标题屏「版本号 v.X」、更新公告、更新检查都用它），
// 与引擎 APP_VERSION（Forge 的 0.18.6）无关。发新版：改这里一处 + hexAnnouncement.js 的公告版本 +
// update/update.json（放到发布渠道上的那份），三处同值。
//
// 「检查更新」的形状：服务器启动时（及每 30 分钟）从 HEX_UPDATE_URL 拉一份 manifest
//   { "version": "0.021", "notes": "…", "downloadUrl": "https://…" }
// 与本地 HEX_MOD_VERSION 比对，结果经 `GET /update-check`（同源、无 CORS）给浏览器，
// 标题屏据此弹「发现新版本」条（public/js/ui/hexUpdate.js）。纯函数都在这里，钉在 test/hexUpdate.test.js。

/** 模组当前版本。**发新版只改这一处**（公告版本与 update.json 随发布改）。 */
export const HEX_MOD_VERSION = '0.06.1';

/**
 * 更新清单的默认地址：**夸克网盘分享**（玩家拿包的同一个地址）。检查器识别出夸克链接后
 * 匿名走分享接口列目录，从文件名里的版本号（如 `… v0.021.zip`）取最新版 —— 发版 = 把新 zip
 * 按同样命名传进这个分享（任意一层，子目录也会扫，旧版不用删），分享页本身即「前往更新」的落地页。
 * 换渠道：改这里，或启动时给环境变量 `SP_HEX_UPDATE_URL`（优先级更高，不用改代码）；
 * 非夸克地址一律按普通 JSON 清单 `{ "version": "…", "notes": "…", "downloadUrl": "https://…" }` 处理。
 * 地址不可达 / 格式不对时**静默降级**为「没检查出来」，绝不影响进游戏。
 */
export const HEX_UPDATE_URL_DEFAULT = 'https://pan.quark.cn/s/eb95218b2bab';

/** 点「前往更新」的兜底落地页（清单/分享里拿不到更具体的地址时用）。 */
export const HEX_UPDATE_FALLBACK_URL = 'https://pan.quark.cn/s/eb95218b2bab';

/**
 * 版本号规范化：把**三段以上**的写法折成与小数口径等价的两段式 —— `0.03.1` ⇒ `0.031`。
 * 本 fork 的版本一直是小数口径（`0.021` 就是「0.02 的补丁 1」），所以 `0.03.1` 必须落在同一条数轴上；
 * 否则它会被逐段比较（第三段 1 与 0.021 的第二段 21 相比）判成**比 0.021 还旧** —— 发版时网盘里的
 * 最新版就会被算成 0.021，所有 0.03 玩家都收不到更新提示。非纯数字形状原样返回（走逐段比较）。
 * @param {string} v @returns {string}
 */
export function canonicalHexVersion(v) {
  const s = String(v ?? '').trim();
  if (!/^\d+(\.\d+)*$/.test(s)) return s;
  const segs = s.split('.');
  if (segs.length <= 2) return s;
  return `${segs[0]}.${segs.slice(1).join('')}`;
}

/**
 * 比较两个版本号：>0 表示 a 更新。模组的版本是**小数口径**（0.02 < 0.021 < 0.03 < 0.031 < 0.1），
 * 先按 `canonicalHexVersion` 规范化（`0.03.1` ⇒ `0.031`），形如 `\d+(\.\d+)?` 的按十进制数比 ——
 * 逐段比会把 0.03 误判为小于 0.021；非常规形状（带字母等）退回逐段数字比较，任何非数字段按 0 处理，
 * 脏输入不会把比较炸成 NaN。
 * @param {string} a @param {string} b @returns {number}
 */
export function compareHexVersions(a, b) {
  return compareCanonical(canonicalHexVersion(a), canonicalHexVersion(b));
}

/** `compareHexVersions` 的主体：两个都已经过 `canonicalHexVersion`。 */
function compareCanonical(sa, sb) {
  const dec = (v) => (/^\d+(\.\d+)?$/.test(v) ? Number(v) : null);
  const da = dec(sa);
  const db = dec(sb);
  if (da !== null && db !== null) return da > db ? 1 : da < db ? -1 : 0;
  const pa = sa.split('.');
  const pb = sb.split('.');
  const n = Math.max(pa.length, pb.length);
  for (let i = 0; i < n; i++) {
    const x = Number(pa[i]) || 0;
    const y = Number(pb[i]) || 0;
    if (x !== y) return x > y ? 1 : -1;
  }
  return 0;
}

const cut = (v, max) => (typeof v === 'string' ? v.replace(/\s+/g, ' ').trim().slice(0, max) : '');
const httpsUrl = (v) => (/^https:\/\/\S+$/.test(typeof v === 'string' ? v.trim() : '') ? v.trim() : '');

/**
 * 校验远端 manifest：认不出的整体丢掉（返回 null），字段逐个收窄 —— version 必填（≤32 字符），
 * notes ≤ 400 字符，downloadUrl 只认 https（和 server/notices.js 的公告链接同一条安全线）。
 * @param {any} raw @returns {{ version: string, notes: string, downloadUrl: string } | null}
 */
export function parseUpdateManifest(raw) {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return null;
  const version = cut(raw.version, 32);
  if (!version || /[<>]/.test(version)) return null;
  return { version, notes: cut(raw.notes, 400), downloadUrl: httpsUrl(raw.downloadUrl) };
}

/**
 * 检查结果 → 浏览器要画的视图（纯函数）。
 * @param {string} current @param {{ version: string, notes: string, downloadUrl: string } | null} manifest
 * @returns {{ checked: boolean, outdated: boolean, current: string, latest: string, notes: string, downloadUrl: string }}
 */
export function updateCheckView(current, manifest) {
  if (!manifest) return { checked: false, outdated: false, current: String(current ?? ''), latest: '', notes: '', downloadUrl: '' };
  const outdated = compareHexVersions(manifest.version, current) > 0;
  return {
    checked: true,
    outdated,
    current: String(current ?? ''),
    latest: manifest.version,
    notes: outdated ? manifest.notes : '',
    downloadUrl: outdated ? (manifest.downloadUrl || HEX_UPDATE_FALLBACK_URL) : '',
  };
}
