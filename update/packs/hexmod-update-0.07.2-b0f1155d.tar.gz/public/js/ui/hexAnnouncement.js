// public/js/ui/hexAnnouncement.js — 海克斯模组更新公告弹窗（this fork）。
//
// 三个入口：
//   1) 大厅（lobby.js）挂载时 `hexAnnouncementPending()` 为真（本版本没看过）→ 自动弹出；
//      标题页点「开始」进入大厅后即弹出，关闭时 `markHexAnnouncementSeen()` 写入 localStorage —— 看过一遍后不再自动弹。
//   2) 大厅顶栏工具排的公告按钮（HexAnnouncementButton）随时可再打开。
//   3) 发新版：改 HEX_ANNOUNCE_VERSION + 下面的正文；历史版本的公告保留在「往期公告」折叠区（滚轮下查）。
//
// V0.03.1 正文：无尽 Boss 关修复 + 购买上阵栏位 + 回合结束保留资金 + 无尽标记 BETA 0.1；
// 更新弹窗改版；顶部有醒目的 Beta 反馈提醒。V0.021 的公告原文整体保留在底部折叠区，不替换。

import { html, MicroLabel, Modal } from './components.js';
import { GIcon, Img, RichText } from './gameComponents.js';
import { bondIconUrl } from './assetUrls.js';
import { data } from '../data.js';
import { HEXES, HEX_GRADE_NAME, HEX_GRADE_COLOR, hexById } from '../../../shared/hexes.js';
import { HEX_CHANGES, hexChangeOf } from '../../../shared/hexChanges.js';
import { t } from '../../../shared/i18n.js';

/** 当前公告对应的模组版本 —— 发新版时改这里（旧版本视为「看过」，新版重新弹出）。 */
export const HEX_ANNOUNCE_VERSION = 'v0.07.2';
const SEEN_KEY = 'sp-hexmod-announce-seen';

/** 本版本的公告是否还没看过（localStorage 不可用时按「没看过」处理，宁可多弹一次）。 */
export function hexAnnouncementPending() {
  try { return localStorage.getItem(SEEN_KEY) !== HEX_ANNOUNCE_VERSION; } catch { return true; }
}

/** 关闭公告时调用 —— 之后本版本不再自动弹出（顶栏按钮仍可手动打开）。 */
export function markHexAnnouncementSeen() {
  try { localStorage.setItem(SEEN_KEY, HEX_ANNOUNCE_VERSION); } catch { /* ignore */ }
}


/** 改动对照：`[[…]]` 包起来的片段高亮（改动前），`added` 另起一行「＋ 新增」。 */
function ChangeNote({ hex }) {
  const c = hexChangeOf(hex && hex.id);
  if (!c) return null;
  const mark = (text) => String(text || '').split(/\[\[|\]\]/).map((seg, i) => (i % 2
    ? html`<b class="hexann__hi">${t(seg)}</b>`
    : seg));
  return html`<div class="hexann__note">
    ${c.before ? html`<p class="hexann__was"><span class="hexann__was-k">${t('改动前')}</span>${mark(c.before)}</p>` : null}
    ${c.added ? html`<p class="hexann__new"><span class="hexann__new-k">＋ ${t('新增')}</span>${mark(c.added)}</p>` : null}
  </div>`;
}

/** 可折叠分组：标题（含条数）→ 组内每条海克斯一张卡（卡片自己还能再折叠）。 */
function HexGroup({ title, tone = 'gold', ids = [], open = false }) {
  if (!ids.length) return null;
  return html`<details class="hexann__group hexann__group--${tone}" open=${open}>
    <summary class="hexann__group-sum">
      <span class="hexann__group-arrow">▶</span>
      <b>${t(title)}</b>
      <span class="hexann__group-n num">${ids.length}</span>
    </summary>
    <div class="hexann__group-body">
      ${ids.map((id) => html`<div key=${id} class="hexann__sec">
        <${HexAnnCard} hex=${hexById(id)} />
        <${ChangeNote} hex=${hexById(id)} />
      </div>`)}
    </div>
  </details>`;
}

/** 普通折叠段（只有文案，不含海克斯卡）。 */
function FoldGroup({ title, tone = 'mint', open = false, children }) {
  return html`<details class="hexann__group hexann__group--${tone}" open=${open}>
    <summary class="hexann__group-sum">
      <span class="hexann__group-arrow">▶</span>
      <b>${t(title)}</b>
    </summary>
    <div class="hexann__group-body">${children}</div>
  </details>`;
}

/** 单条海克斯卡（可展开）：盟约纹章 + 名称 + 等级（按 grade 着色）/ tag 徽章 + 描述。 */
function HexAnnCard({ hex }) {
  const iconUrl = hex.iconBond ? bondIconUrl(data.get('assets'), hex.iconBond) : null;
  const tags = Array.isArray(hex.tags) ? hex.tags : [];
  const gradeName = t(HEX_GRADE_NAME[hex.grade] || hex.grade);
  const gradeColor = HEX_GRADE_COLOR[hex.grade] || null;
  return html`<details key=${hex.id} class="hexann__hex">
    <summary>
      <span class="hexann__hicon">
        ${iconUrl
          ? html`<${Img} src=${iconUrl} fallback=${html`<${GIcon} name=${hex.icon || 'flag'} />`} />`
          : html`<${GIcon} name=${hex.icon || 'flag'} />`}
      </span>
      <span class="hexann__hmain">
        <span class="hexann__hname-row">
          <b class="hexann__hname">${t(hex.name)}</b>
          <span class="hexann__chip" style=${gradeColor ? `--grade-c:${gradeColor}` : null}>${gradeName}</span>
          ${tags.map((tag) => html`<span key=${tag} class="hexann__chip">${t(tag)}</span>`)}
          ${hex.pendingHook ? html`<span class="hexann__chip hexann__chip--dim" title=${t('效果钩子将在后续版本实装，当前先入册展示')}>${t('即将实装')}</span>` : null}
        </span>
      </span>
      <span class="hexann__open">▾</span>
    </summary>
    <div class="hexann__hexbody">
      <${RichText} text=${t(hex.desc)} class="hexann__hdesc" />
    </div>
  </details>`;
}

/**
 * 更新公告弹窗。`onClose` 由调用方负责标记「已看过」（自动弹出关闭时写 localStorage；从按钮打开的重复查看无需再写）。
 * @param {{ open?: boolean, onClose?: Function }} props
 */
export function HexAnnouncementModal({ open = false, onClose = () => {} }) {
  const idsOf = (pred) => Object.keys(HEX_CHANGES).filter((id) => HEXES.some((h) => h && h.id === id) && pred(HEX_CHANGES[id]));
  const NEW_IDS = idsOf((c) => !c.before);
  const BUFF_IDS = idsOf((c) => c.before && c.verdict === 'buff');
  const TUNE_IDS = idsOf((c) => c.verdict === 'tweak');
  const bondEx = HEXES.filter((h) => h.bondExclusive);
  const bondLive = bondEx.filter((h) => !h.pendingHook);
  const chaosLive = HEXES.filter((h) => h.chaosRoll);
  const ascensionLive = HEXES.filter((h) => h.delayedOps);
  return html`<${Modal} open=${open} title=${t('更新公告')} micro=${`HEX MOD // ${HEX_ANNOUNCE_VERSION.toUpperCase()}`}
    tone="gold" width="min(8.8rem, 96vw)" class="hexann-modal" onClose=${onClose}>

    <div class="hexann__alert hexann__pin" role="alert">
      <b>【重要】连续 1 小时没有任何操作、阵容也没有任何变化时，服务器会清除该连接（座位与房间一并释放）。</b>
      <span>${t('挂机不动的标签页会被自动回收；重新进入游戏即可继续，不影响你的进度与存档。')}</span>
    </div>

    <div class="hexann__alert" role="alert">
      <b>⚠ ${t('本次更新内容较多，或许会有较多 bug —— 请及时进群反馈！')}</b>
      <span>${t('遇到任何异常（卡死 / 报错 / 数值不对），截图 + 群里描述即可，反馈越快修得越快。')}</span>
    </div>

    <p class="hexann__intro">${t('海克斯模组 V0.07.2：本版为干员版，无新增海克斯。四名干员入队（塔露拉 / 国度 / 冻河 / 奥尔佳），阿米娅（医疗）数据重录；新干员全部自带技能特效与音效。')}</p>

    <div class="hexann__alert hexann__v052">
      <b>${t('V0.07.2 本版改动')}</b>
      <span>${t('新增 · 塔露拉（6★ 近卫 · 本源近卫）：能够阻挡两个敌人、造成元素伤害。S1「照霎白夜」对目标地块上的所有地面敌人造成法术伤害并恐惧；S2「阂断骤雪」受击后自动反击 —— 获得庇护、对攻击来源范围法术伤害并按伤害量吸血；S3「日冕重烈」停止攻击引导簇火 —— 每 2.67 秒朝部署方向放出会爆炸的自走热浪，持续过半后进入过载（更密更宽）。')}</span>
      <span>${t('新增 · 国度（6★ 特种 · 伏击客）：大范围法术炮台，自带 50% 双闪避且不易被选为目标。技能在地面铺开领域「国度」：S1 踏上停顿、S2 禁止闪避且二段后无限持续、S3 同时轰击领域上所有敌人、被地面敌人攻击时在伤害来源四格扩散爆炸。')}</span>
      <span>${t('新增 · 冻河（6★ 辅助 · 游击手）：触发型辅助 —— 给干员挂上「受击获得屏障」「技能可开启时自动开启并加速」等触发型效果；S3 转为输出，攻击附带范围物理伤害与晕眩。')}</span>
      <span>${t('新增 · 奥尔佳（5★ 近卫 · 教官）：可攻击较远敌人、攻击未被自己阻挡的敌人时攻击力提升至 120%；S1「交叉施压」连续追加两次攻击、S2「只为我的答案」延长攻击距离并让目标易伤 + 停顿。')}</span>
      <span>${t('重制 · 阿米娅（医疗）：面板与技能数值按 PRTS 官方数据重录（咒愈师攻击治疗、团队生命光环、哀恸共情 / 慈悲愿景与模组加成）。')}</span>
      <span>${t('演出 · 新干员全部自带专属技能特效与音效，塔露拉另有日配语音；四人与阿米娅均已进入普通商店池，按普通抽卡规则出现。')}</span>
      <span>${t('说明：本版无新增 / 调整海克斯；V0.07.1 及更早版本的摘要见下方折叠区。')}</span>
    </div>

    <details class="hexann__fold">
      <summary><span class="hexann__arrow">▶</span>${t('V0.07.1 公告（领袖限伤 10 兆 / 特质叠层上限解除开关）')}</summary>
      <div class="hexann__fold-body hexann__history">
        <p class="hexann__intro">${t('海克斯模组 V0.07.1：本版为调整版，无新增海克斯。领袖限伤上调至 10 兆；全局设置新增「特质叠层上限解除」开关。')}</p>
        <ul class="hexann__changes">
          <li>${t('调整 · 领袖限伤上调至 10 兆：最终攻势与隐秘核心里「单次伤害达到上限就整次作废」的限伤线，从官方的 30 万提升到 10 兆（10000000000000）。正常对局的伤害远达不到该线，领袖不再被限伤挡住极端爆发；`SP_BOSS_HIT_LIMIT` 仍可按部署覆盖。')}</li>
          <li>${t('新增 · 全局设置「特质叠层上限解除」：对局选项 · 全局设置里新增开关（默认关）。开启后，干员特质里「每场作战至多 N 层」的叠层上限全部解除，特质的盟约层数加成可以一直叠。')}</li>
        </ul>
      </div>
    </details>

    <p class="hexann__hint">${t('下面的分组都可以点开 / 收起；组里的每条海克斯也能单独展开看详情与「改动前」对照。')}</p>

    <${HexGroup} tone="gold" title=${'NEW · 新增海克斯'} ids=${NEW_IDS} open=${true} />
    <${HexGroup} tone="gold" title=${'BUFF · 增强'} ids=${BUFF_IDS} open=${true} />
    <${HexGroup} tone="mint" title=${'TUNE · 调整（全属性 → 全能穿透 / 其它）'} ids=${TUNE_IDS} />

    <${FoldGroup} tone="mint" title=${'NEW · 词条：全能穿透（怎么读、值多少）'}>
      <ul class="hexann__changes">
        <li>${t('全能穿透 X% = 同时无视目标 X% 的护甲与 X% 的法术抗性（两者等值）。')}</li>
        <li>${t('换算效率：面对护甲 D、攻击 A 的敌人，1% 穿透 ≈ D/(A−D) 的攻击力提升；面对法抗 R 的敌人，1% 穿透 ≈ R/(100−R) 的攻击力提升。50 法抗时 1% 穿透正好等于 1% 攻击，80 法抗时 1% 穿透 ≈ 4% 攻击。')}</li>
        <li>${t('注意 5% 保底：穿透把伤害压到保底之后就没有额外收益；护甲高于攻击的敌人，少量穿透几乎无效，越过阈值才突然起效。')}</li>
      </ul>
    <//>

    <${FoldGroup} tone="mint" title=${'TUNE · 全属性 → 全能穿透的换算规则'}>
      <ul class="hexann__changes">
        <li>${t('规则：所有「直接给全属性提升」的效果（含「同时增加相同攻击力与生命值」这种写法），取出其中 25%，按 50 法抗的等价（1:1）折成全能穿透；换算结果保留一位小数，以 .5 为界（小于取 .5、大于进位）。单独的攻击力 / 生命值加成不受影响。')}</li>
        <li>${t('飞升 25% → 18.75% + 穿透 6.5%；飞升+ 50% → 37.5% + 12.5%；飞升++ 100% → 75% + 25%。')}</li>
        <li>${t('我来兜底++ 35% → 26.25% + 穿透 9%（仅联合防守时生效）。')}</li>
        <li>${t('维多利亚宝箱每份 3% → 2.25% 全属性 + 1% 穿透（队伍级、整局常驻）；混沌投掷小吉 2% → 1.5% + 0.5%、散牌 1% → 0.75% + 0.5%。')}</li>
        <li>${t('协防协议 3% / 5% / 10% → 2.25% / 3.75% / 7.5% 全属性 + 1% / 1.5% / 2.5% 穿透（每个激活盟约）；宝宝学院 5% / 10% → 3.75% / 7.5% 全属性 + 1.5% / 2.5% 穿透。')}</li>
      </ul>
    <//>

    <${FoldGroup} tone="mint" title=${'FIX · 修复与澄清'}>
      <ul class="hexann__changes">
        <li>${t('新增（v0.05.2）：对局选项 · 全局设置里的「变形同构体强化」开关（默认开）—— 变形同构体不再占装备栏、每名干员最多一件、只与装备栏最左侧的道具构成转职；进阶（升星）干员因此多出一格装备位。关掉即回到引擎原版。')}</li>
        <li>${t('修复（v0.05.2）：本地端更新完成后会卡在「已更新到 vX」界面 —— 没被 launch.mjs 守护的进程退出后没人拉起服务端；现在会自行拉起，且页面会等到新进程就绪才刷新。')}</li>
        <li>${t('修复（v0.05.1）：拉特兰炫彩「战争天梯」的阶梯奖励一直不发 —— 发奖检查只在选下海克斯那一刻跑过一次，之后弹药再涨也没人查。现在每次战斗结算（含 Boss 关）都会按累计弹药补发所有已达成档位。')}</li>
        <li>${t('新增（v0.05.1）：僵尸连接回收 —— 连续 1 小时没有任何操作、阵容也没有任何变化时，服务器会断开该连接并释放座位（空房同时回收）。挂机不再永久占位。')}</li>
        <li>${t('修复：真实对局（浏览器跑战斗）里战争阶梯的弹药一直是 0 —— 原来的统计只认服务端自己跑的战斗，且客户端回传的结果被字段白名单裁掉了。现在弹药随结果与进度帧回传，顶栏战斗中实时增长。')}</li>
        <li>${t('统计口径：只有【拉特兰】成员（含召唤物按持有者）算；装备「拉特兰桥夹 + 变形同构体」转职成对后的干员同样计入；干员调配 / 借调进来的干员按自身盟约判断。')}</li>
        <li>${t('修复：自选海克斯里指定「战争天梯」在标准模拟下会被静默跳过（该盟约在本局不激活）。现在自选点名的盟约专属海克斯一律投放，不可用时也会弹出提示而不是悄悄消失。')}</li>
        <li>${t('修复（v0.05.1）：Boss 关共享血池的 Boss 可能被「非伤害」方式移除（换体失败 / 杂散击杀），结果场上没有 Boss、血条却还有血，战斗只能干等到超时结算。现在拒绝非伤害击杀血池未空的 Boss，换体失败也不再杀旧本体。')}</li>
        <li>${t('图鉴 & 公告新增强度标记：增强 ↑（绿）/ 削弱 ↓（红）/ 调整 —（黄），并给出「改动前」对照。')}</li>
        <li>${t('澄清：王室宝库只把维多利亚「每 25 层的装备里程碑」换成宝箱 —— 维多利亚只是不再从层数里拿装备，盟约本身「每件装备提供的攻击力」与按层数的伤害加成照常生效。')}</li>
      </ul>
    <//>

    <details class="hexann__fold">
      <summary><span class="hexann__arrow">▶</span>${t('V0.07 公告（道具商店价格倍率 / 阿米娅光环叠层 / 模型素材）')}</summary>
      <div class="hexann__fold-body hexann__history">
        <p class="hexann__intro">${t('V0.07：本版为修复版，无新增海克斯。')}</p>
        <ul class="hexann__changes">
          <li>${t('修复 · 道具商店价格倍率：房间选项里的倍率（1–10 倍，默认 5 倍）改了没反应、局内独立道具商店显示价恒为 ×5。根因是房间状态没有下发这个倍率，且「没设置」被当成了 ×1。现在倍率正确回传，显示价与实扣一致，普通商店道具价格不受影响。')}</li>
          <li>${t('修复 · 阿米娅（医疗）光环叠层：范围内干员开技能本应让己方已激活盟约加层，但之前每名干员整场只加 1 层，之后开多少次技能都不再加。现在每次开启技能都会正常计数加层，战斗结算时生效。')}</li>
          <li>${t('修复 · 阿米娅模型与头像：部分服务器缺少她的美术文件，导致模型、头像、立绘加载不出来；文件已补齐，现在可正常显示。')}</li>
        </ul>
      </div>
    </details>

    <details class="hexann__fold">
      <summary><span class="hexann__arrow">▶</span>${t('V0.06.1 公告（道具商店开关 / 阿米娅天赋一）')}</summary>
      <div class="hexann__fold-body hexann__history">
      <ul class="hexann__changes">
        <li>${t('修复 · 道具商店开关：全局设置里的「道具商店」开关之前错误地关联到普通商店的道具位与道具价格，开关一开全局道具全跟着变。现在该开关与价格倍率只作用于独立的道具商店入口，普通商店道具恢复原价、不受影响。')}</li>
        <li>${t('修复 · 阿米娅（医疗）天赋一：技能实际命中范围内目标时「盟约层数增加」的效果在真实对局（浏览器跑战斗）里不生效 —— 战斗结果回传时被字段白名单裁掉了。现在正常计数与结算。')}</li>
      </ul>
      </div>
    </details>

    <details class="hexann__fold">
      <summary><span class="hexann__arrow">▶</span>${t('V0.06 公告（阿米娅（医疗） / 道具商店与多人牌池 / 修复）')}</summary>
      <div class="hexann__fold-body hexann__history">
      <ul class="hexann__changes">
        <li>${t('新增阿米娅（医疗）：咒愈师攻击治疗、团队生命光环、范围属性与技能治疗/攻击效果；技能实际命中双目标并施加寒冷；累计伤害或治疗达到 500 万后获得对应里程碑效果，满足条件时按普通干员升星规则由 _a 进阶为 _b。')}</li>
        <li>${t('道具商店：可在房间选项关闭；装备价格倍率可设为 1–10 倍，默认 5 倍；新增等阶筛选，并移除画卷、教鞭与神秘顾客。多人牌池在超过 4 人时按人数比例扩充。')}</li>
        <li>${t('修复：联防重入不再重复套用波次模板属性倍率；盟约专属海克斯在盟约被 ban、模式关闭或无可用干员时不再进入候选或持续发放；高攻速攻击保留时间余数并合并同帧欠下的攻击（最多 8 段）；装备展示支持最多 4 件并按数量居中。')}</li>
        <li>${t('限制说明：普通联防“重复打两轮怪”尚未在测试中复现，未宣称修复；百人变体的第二阶段 relay 保持原设计。')}</li>
      </ul>
      </div>
    </details>

    <details class="hexann__fold">
      <summary><span class="hexann__arrow">▶</span>${t('V0.04.3 公告（焚荒之冰 / 大厅聊天 / 无尽修复）')}</summary>
      <div class="hexann__fold-body hexann__history">
    <${MicroLabel} tone="gold">${t('NEW // 双盟约海克斯')}<//>
    <div class="hexann__sec">
      <${HexAnnCard} hex=${hexById('bx_frostfire')} />
    </div>

    <${MicroLabel} tone="gold">${t('NEW // 大厅：服务器聊天 · 缺人同盟 · 自选海克斯')}<//>
    <div class="hexann__sec">
      <ul class="hexann__changes">
        <li>${t('大厅左下角新增服务器聊天：所有在线博士都能发言，发言前显示自己的代号，右上角可一键收起。')}</li>
        <li>${t('缺人同盟面板接入真实房间列表（房主 / 难度 / 缺几人），一键加入；在线人数改为真实在线的博士数量。')}</li>
        <li>${t('房间行与房间简报新增类型标签：开启无尽显示「无尽」，开启三海克斯显示「三海克斯」，有人指定自选显示「自选」。')}</li>
        <li>${t('自选海克斯对所有成员开放：房主开启后，每位博士都能从图鉴选自己的队列（上限随三海克斯 2 / 3 条）。')}</li>
      </ul>
    </div>

    <${MicroLabel} tone="mint">${t('FIX // 无尽第 15 回合 · 熔毁 · 回合数 · 界面自适应')}<//>
    <div class="hexann__sec">
      <ul class="hexann__changes">
        <li>${t('修复：无尽模式的第 15 回合（官方隐秘核心）之前被当成普通关 —— 打的是普通地图、也不是 Boss 轮次。现在它照常是隐秘 Boss 关：进隐秘核心、加载 h08 隐秘地图、打完开熔毁商店。')}</li>
        <li>${t('修复：熔毁商店此前只在连打时开启一次（后续隐秘 Boss 打完不开店）。现在每个隐秘 Boss 都会开启，报价按波次重新抽取。')}</li>
        <li>${t('修复：顶部回合面板在无尽模式里显示真实回合数（此前只要超过 14 就显示「??」）。')}</li>
        <li>${t('界面按浏览器分辨率等比例缩放（不改动任何布局）：小窗口 / 手机竖屏下整屏等比缩小，熔毁、道具商店、海克斯三选一不再超出屏幕，排版与桌面一致。')}</li>
      </ul>
    </div>
      </div>
    </details>

    <details class="hexann__fold">
      <summary><span class="hexann__arrow">▶</span>${t('V0.04.1 公告（道具商店 / 库存解除 / 3 项修复）')}</summary>
      <div class="hexann__fold-body hexann__history">
    <p class="hexann__intro">${t('海克斯模组 V0.04.1：新增「道具商店」+ 装备库存上限全局解除 + 盟约定向刷新改为 20%；另修复 3 个问题 —— 无尽模式海克斯熔毁商店不出现、先购买上阵栏位再装备「人事部文档」无效、干员攻速上限放宽到 3000。')}</p>

    <${MicroLabel} tone="gold">${t('NEW // 道具商店')}<//>
    <div class="hexann__sec">
      <ul class="hexann__changes">
        <li>${t('调度中心的「冻结」按钮旁新增道具商店入口：打开后以原价 ×5 直接购买任意装备，界面与海克斯选择同风格（蓝金白），顶栏有实时资金与关闭商店按钮。')}</li>
        <li>${t('只能购买等阶 ≤ 商店等级的装备，高阶锁定展示。')}</li>
        <li>${t('装备库存上限全局解除：所有来源（商店 / 特殊刷新 / 道具商店 / 授予）都不再受牌库数量限制。')}</li>
      </ul>
    </div>

    <${MicroLabel} tone="gold">${t('TUNE // 盟约定向刷新')}<//>
    <div class="hexann__sec">
      <ul class="hexann__changes">
        <li>${t('定向触发概率由 50% 改为 20%（开启「盟约定向刷新」房间选项后，每次抽干员位改为从已激活盟约定向抽取的概率）。')}</li>
      </ul>
    </div>

    <${MicroLabel} tone="mint">${t('FIX // 无尽模式 · 海克斯熔毁协议')}<//>
    <div class="hexann__sec">
      <ul class="hexann__changes">
        <li>${t('修复：无尽模式里排班抽到的「隐秘 Boss」此前按普通决战结算 —— 打赢后直接进下一关，海克斯熔毁商店永远不会出现。现在隐秘 Boss 正常走隐秘核心流程，打赢后开启熔毁协议商店。')}</li>
      </ul>
    </div>

    <${MicroLabel} tone="mint">${t('FIX // 人事部文档 · 效果变更')}<//>
    <div class="hexann__sec">
      <ul class="hexann__changes">
        <li>${t('效果由「最大可部署人数变为 9」改为「最大可部署人数 +1」：先花资金购买上阵栏位再装备它，之前会毫无效果；现在与购买叠加，多张可叠加，上限仍为 12。')}</li>
      </ul>
    </div>

    <${MicroLabel} tone="mint">${t('FIX // 干员数值上限放宽')}<//>
    <div class="hexann__sec">
      <ul class="hexann__changes">
        <li>${t('攻击速度上限由 600 放宽到 3000（实际意义上的无上限 —— 再高会被战斗模拟的帧率天花板截住）；减速下限 20 保持不变。')}</li>
      </ul>
    </div>
      </div>
    </details>

    <details class="hexann__fold">
      <summary><span class="hexann__arrow">▶</span>${t('V0.04 公告（混沌投掷 / 飞升 / 熔毁协议 / 选择画面改版）')}</summary>
      <div class="hexann__fold-body hexann__history">
    <p class="hexann__intro">${t('海克斯模组 V0.04：新增「混沌投掷」赌局系列海克斯（赌神 / 赌王 / 赌徒，掷出三颗骰子按点数获得奖励，另有隐藏彩蛋点数）；新增「飞升」系列（战斗开始 12 秒后全体干员全属性提升）；「海克斯熔毁协议」无尽商店上线；海克斯选择画面全面改版（蓝金白新视觉）。')}</p>

    <${MicroLabel} tone="gold">${t('NEW // 混沌投掷（赌局系列）')}<//>
    <div class="hexann__sec">
      <ul class="hexann__changes">
        <li>${t('掷出三颗骰子，按点数获得不同的奖励 —— 掷骰会在屏幕正中央实时演算，骰子落定后公布结果与奖励。')}</li>
        <li>${t('赌徒！（白银）：立即进行一次混沌投掷。')}</li>
        <li>${t('赌王！（黄金）：立即进行两次混沌投掷。')}</li>
        <li>${t('赌神！（炫彩）：立即投掷一次，此后每两个回合的部署阶段开始时再投一次。')}</li>
        <li>${t('混沌类海克斯在随机三选一里整局只会出现一条（自选海克斯不受此限）。')}</li>
      </ul>
      <details class="hexann__fold" open>
        <summary><span class="hexann__arrow">▶</span>${t('展开查看：赌局系列 3 条（点击单条展开）')}</summary>
        <div class="hexann__fold-body">
          <div class="hexann__hexlist">
            ${chaosLive.map((h) => html`<${HexAnnCard} key=${h.id} hex=${h} />`)}
          </div>
        </div>
      </details>
    </div>

    <${MicroLabel} tone="gold">${t('NEW // 飞升系列')}<//>
    <div class="hexann__sec">
      <ul class="hexann__changes">
        <li>${t('战斗开始 12 秒后，你的所有干员全属性提升，直到战斗结束；之后部署的干员同样生效。')}</li>
        <li>${t('飞升（白银）+25% · 飞升+（黄金）+50% · 飞升++（炫彩）+100%。')}</li>
      </ul>
      <details class="hexann__fold" open>
        <summary><span class="hexann__arrow">▶</span>${t('展开查看：飞升系列 3 条（点击单条展开）')}</summary>
        <div class="hexann__fold-body">
          <div class="hexann__hexlist">
            ${ascensionLive.map((h) => html`<${HexAnnCard} key=${h.id} hex=${h} />`)}
          </div>
        </div>
      </details>
    </div>

    <${MicroLabel} tone="gold">${t('NEW // 海克斯熔毁协议（无尽模式）')}<//>
    <div class="hexann__sec">
      <ul class="hexann__changes">
        <li>${t('无尽模式每打完一个隐秘 Boss，会开启「海克斯熔毁协议」商店：4 个栏位（主盟约专属 6 阶装备 + 炫彩 / 黄金 / 白银海克斯），每栏限购 1 件，可以一件不买直接关店。')}</li>
        <li>${t('代价永久叠加：购买后敌方属性按档位增强（装备 → 敌方全属性 +10%；海克斯 → 每波敌方减伤 / 每回合全属性 / 部署费用回复按品阶 10/3/10、7/2/7、4/1/4 洗牌分配）。')}</li>
        <li>${t('每波池子独立抽取，抽空的栏位显示「海克斯等阶达到极限」。')}</li>
      </ul>
    </div>

    <${MicroLabel} tone="mint">${t('UI // 海克斯选择画面改版')}<//>
    <div class="hexann__sec">
      <ul class="hexann__changes">
        <li>${t('三选一画面换成蓝金白新视觉（与熔毁协议同版式）：卡面图标改为单色剪影 —— 盟约专属显示对应盟约的形象。')}</li>
        <li>${t('顶部显示本局已获得的海克斯、底部显示选择倒计时与草案序号；「换」按钮移到卡片底部。')}</li>
      </ul>
    </div>
      </div>
    </details>

    <details class="hexann__fold">
      <summary><span class="hexann__arrow">▶</span>${t('V0.03.4 公告（自动更新 / 4 项修复）')}</summary>
      <div class="hexann__fold-body hexann__history">
    <p class="hexann__intro">${t('海克斯模组 V0.03.4：新增「自动更新」—— 检测到新版本时只下载变化的文件，校验后自动重启，不必再手动下载整包；另修复 4 个问题（上阵栏位与人事部文档重叠、萨满战鼓攻速掉层、王室铸币重复发钱、军需官描述）。')}</p>

    <${MicroLabel} tone="gold">${t('NEW // 自动更新')}<//>
    <div class="hexann__sec">
      <ul class="hexann__changes">
        <li>${t('标题页检测到新版本会先问一次：**立即更新 / 暂不更新**。')}</li>
        <li>${t('只下载变化的文件（通常几 MB）；进度条上方显示百分比与实时速度，可随时取消。')}</li>
        <li>${t('每个文件都校验 SHA-256，失败自动回滚到旧版本；默认源连不上会自动换镜像。')}</li>
        <li>${t('更新完成后服务端自动重启、页面自动刷新 —— 不需要重新下载安装包。')}</li>
        <li>${t('若所有源都不可用，会给出**夸克网盘**与**加群 189434216** 两个入口。')}</li>
        <li>${t('范围：代码 / 数据 / 界面。**素材大版本仍需整包**（会照旧在群里通知）。')}</li>
      </ul>
    </div>

    <${MicroLabel} tone="mint">${t('FIX // 修复')}<//>
    <div class="hexann__sec">
      <ul class="hexann__changes">
        <li>${t('**额外上阵栏位**：已装备「人事部文档」时，25 资金买到的第 1 个栏位会被 9 人上限吃掉（钱花了、栏位没变）—— 现在会把上限从 9 提到 10。')}</li>
        <li>${t('**萨尔贡「萨满战鼓」**：任意萨尔贡开技能都会刷新 15 秒共享窗口，并把已有层一起续期，不再出现「开了技能攻速还在掉」；两名萨尔贡玩家的计时器互不干扰。')}</li>
        <li>${t('**维多利亚「王室铸币」**：选择后只发 10 资金 + 1 件维式重锤（此前重复结算成 20 资金）。')}</li>
        <li>${t('**维多利亚「军需官」**：描述改为「维多利亚盟约 6 人效果：每件装备提供的攻击力由 50% 提高至 65%，进阶装备由 80% 提高至 100%」。')}</li>
      </ul>
    </div>

      </div>
    </details>

    <details class="hexann__fold">
      <summary><span class="hexann__arrow">▶</span>${t('V0.03.3 公告（无尽 Boss / 等级四选一 / 稀有度不重复 / DPS 查看）')}</summary>
      <div class="hexann__fold-body hexann__history">
    <p class="hexann__intro">${t('海克斯模组 V0.03.3：无尽模式的 Boss 会换人了（随机 + 隐秘 Boss + 逐个增强）；海克斯等级选择改成一组四按钮、自选海克斯改为占三选一第一格并高亮；新增「稀有度不重复」开关与「本局海克斯详情」标签页；新增「DPS 查看」（BETA）伤害排行；战斗费用移到生命值旁。')}</p>

    <${MicroLabel} tone="gold">${t('ENDLESS // 无尽模式 Boss')}<//>
    <div class="hexann__sec">
      <ul class="hexann__changes">
        <li>${t('每个无尽 Boss 关**单独随机**抽出首领（相邻两个不会重复）—— 之前整局只抽一次，循环时永远同一个 Boss。')}</li>
        <li>${t('**每打完两个 Boss**，下一个 Boss 换成**隐秘 Boss**（第 3 / 6 / 9… 个，用隐秘核心的首领池与专属波次）。')}</li>
        <li>${t('第 N 个 Boss 的敌人额外 ×(1 + 0.1 × N)：第 1 个 +10%、第 2 个 +20%……（与每关 +20% 累进相乘）。')}</li>
      </ul>
    </div>

    <${MicroLabel} tone="mint">${t('ROOM // 对局选项')}<//>
    <div class="hexann__sec">
      <ul class="hexann__changes">
        <li>${t('海克斯等级改为**一组四个按钮**（随机 / 白银 / 黄金 / 炫彩）：依次点击把等阶排给第 1 / 2 / 3 次海克斯，按钮上的数字就是「第几次」，旁边可一键重置。')}</li>
        <li>${t('三海克斯局的**第 3 次**草案也能钉死等阶了（以前只能随机）。')}</li>
        <li>${t('**稀有度不重复**（新开关）：只在上面的等阶全部为「随机」时可用；开启后每次海克斯的稀有度都与上一次不同（银→金→彩顺延）。不开启 = 按权重随机。')}</li>
        <li>${t('随机时的三档稀有度改为**等概率**（白银 / 黄金 / 炫彩 各约 1/3）—— 之前炫彩只有 10%，很多局见不到。')}</li>
        <li>${t('**自选海克斯**改为占三选一的**第一格**，卡面带金色「自选」高亮，仍然可以三选一（不再直接自动发放、无视等阶）。')}</li>
      </ul>
    </div>

    <${MicroLabel} tone="mint">${t('INFO // 本局海克斯详情')}<//>
    <div class="hexann__sec">
      <ul class="hexann__changes">
        <li>${t('「本局信息」弹窗新增「**海克斯详情**」标签页：列出本局已获得的海克斯，并统计各自的实际收益 —— 累计获得资金、触发次数、海克斯造成的**累计伤害**（焚尽八荒 9 炎、碎片大厦等）、王室宝库的全属性累计等。')}</li>
        <li>${t('右侧海克斯栏的徽章**悬停**也能看到同一份统计。')}</li>
      </ul>
    </div>

    <${MicroLabel} tone="gold">${t('DPS // 伤害排行（BETA）')}<//>
    <div class="hexann__sec">
      <ul class="hexann__changes">
        <li>${t('海克斯栏顶部新增「**DPS**」按钮：点开在左侧显示 **本场实时 DPS**（每 0.5 秒刷新，DPS = 累计伤害 ÷ 战斗时长）以及**本局累计**的干员 / 盟约伤害排行。')}</li>
        <li>${t('召唤物（炎佑等）与装置也计入排行，名字后会标「（召唤物）/（装置）」；数值以 k 为单位（1k = 1000）。')}</li>
        <li>${t('该功能标记为 BETA，遇到异常请及时反馈。')}</li>
      </ul>
    </div>

    <${MicroLabel} tone="mint">${t('FIX // 修复与调整')}<//>
    <div class="hexann__sec">
      <ul class="hexann__changes">
        <li>${t('修复王室宝库「全属性提升」在效果栏显示成 [object Object] 的问题。')}</li>
        <li>${t('修复更新公告弹层无法滚动、往期公告折叠点不开的问题（长内容被压扁成细条）。')}</li>
        <li>${t('王室宝箱给的维多利亚干员：阶数不再固定 3 阶，上限为**当前调度中心等级**。')}</li>
        <li>${t('战斗费用（COST）计数从画面右缘移到**生命值旁边**的顶栏。')}</li>
        <li>${t('图鉴撤下上一版（v0.03.2）的「改动前」对照与 ↑↓— 标记（那些改动本身仍然生效，只是不再展示对照）。')}</li>
      </ul>
    </div>
      </div>
    </details>

    <details class="hexann__fold">
      <summary><span class="hexann__arrow">▶</span>${t('V0.03.2 公告（13 处海克斯平衡调整 · 图鉴改动对照）')}</summary>
      <div class="hexann__fold-body hexann__history">
        <p>${t('海克斯模组 V0.03.2：13 处海克斯平衡调整（炎 / 萨尔贡 / 维多利亚 / 阿戈尔 / 叙拉古 / 卡西米尔 / 经济与通用各线）。图鉴里改过的海克斯已标注 ↑ 增强 / ↓ 削弱 / — 调整，并保留「改动前」原文做对照，改动处用绿色高亮。')}</p>

    <${MicroLabel} tone="gold">${t('BALANCE // 海克斯平衡（13 处）')}<//>
    <div class="hexann__sec">
      <ul class="hexann__changes">
        <li>${t('焚尽八荒（炫彩 · 炎）↑ 新增 9 炎效果：每隔 8 秒对全场敌人造成一次炎干员攻击力 15% 的灼燃损伤；本局所有敌人的灼燃逼爆冷却时长缩短 50%。')}</li>
        <li>${t('萨满战鼓（炫彩 · 萨尔贡）↑ 叠加上限 40 → 100 层。')}</li>
        <li>${t('沙暴（炫彩 · 萨尔贡）↑ 敌人攻击力降低 20%（原 10%）、攻速降低 30%（原 15%）。')}</li>
        <li>${t('王室宝库（炫彩 · 维多利亚）↑ 宝箱奖励加强：可产出不限阶数的维多利亚干员、全体干员 3% 全属性永久提升（可叠加，效果栏展示累计值）；维多利亚原本的「装备提供属性」效果保留。')}</li>
        <li>${t('深海猎场（炫彩 · 阿戈尔）↑ 取消「对同一目标只计一次」，每次吞噬或击倒都计入成长。')}</li>
        <li>${t('黑手帝国（炫彩 · 叙拉古）↑ 附加真实伤害取消上限；击杀计数由每 20 名改为每 15 名。')}</li>
        <li>${t('骑士铁律（炫彩 · 卡西米尔）↑ 眩晕时长 0.1 → 0.3 秒。')}</li>
        <li>${t('奸商本色（炫彩 · 经济）↑ 利息上限 5 → 10（坎诺特仍无上限）。')}</li>
        <li>${t('碎片大厦的回忆（炫彩）↑ 伤害改为「当前激活的最高盟约层数 × 1000」。')}</li>
        <li>${t('我来兜底++（炫彩）↑ 改为全体数值（攻击 / 生命 / 防御 / 法抗）+35%。')}</li>
        <li>${t('协防协议++（炫彩）↑ 每个激活盟约的加成 7% → 10%。')}</li>
        <li>${t('宝宝学院++（炫彩）↑ 加成 7% → 10%。')}</li>
        <li>${t('天选系列 ×8（炫彩）↑ 第 7 回合额外发放 1 名 6 阶对应盟约干员（在第 7 回合或之后选中该海克斯时立即补发）。')}</li>
      </ul>
    </div>

    <${MicroLabel} tone="mint">${t('CODEX // 图鉴怎么看改动')}<//>
    <div class="hexann__sec">
      <ul class="hexann__changes">
        <li>${t('图鉴卡片：↑ 绿色 = 增强，↓ 红色 = 削弱，— 黄色 = 调整（悬停看一句话说明）。')}</li>
        <li>${t('改过的卡片下方保留「改动前」原文，被改动的片段用绿色加粗标出；本次对照会一直保留到下一次海克斯更新。')}</li>
      </ul>
    </div>

    <details class="hexann__fold">
      <summary><span class="hexann__arrow">▶</span>${t('V0.03.1 公告（无尽 Boss 关修复 / 购买上阵栏位 / 回合结束保留资金 / BETA 0.1）')}</summary>
      <div class="hexann__fold-body hexann__history">
        <p>${t('海克斯模组 V0.03.1：修复无尽模式 Boss 关不生成 Boss 的问题；新增「购买上阵栏位」与「回合结束保留资金（存钱）」两个功能；无尽模式标记更新为 BETA 0.1。')}</p>

    <${MicroLabel} tone="mint">${t('FIX // 修复')}<//>
    <div class="hexann__sec">
      <ul class="hexann__changes">
        <li>${t('修复无尽模式 Boss 关不生成 Boss：第 19 / 24 / 29… 关（Boss 关）此前只有 Boss 血条、场上却没有任何敌人，白掉一轮生命值。现在 Boss 与随行敌人都会正常出现。')}</li>
      </ul>
    </div>

    <${MicroLabel} tone="gold">${t('NEW // 新功能（对局选项 · 全局设置）')}<//>
    <div class="hexann__sec">
      <ul class="hexann__changes">
        <li>${t('购买上阵栏位：开启后，局内生命值右侧出现购买按钮，可花 25 / 50 / 75 资金购买 3 个额外上阵栏位（只可在准备阶段购买；部署位达到系统上限时不再开放）。')}</li>
        <li>${t('回合结束保留资金（存钱）：开启后休整期结束不再清空剩余资金，可以存钱到后面的回合用；开启无尽模式时会自动开启（仍可手动关闭）。')}</li>
      </ul>
    </div>

    <${MicroLabel} tone="mint">${t('NOTE // 模式标记')}<//>
    <div class="hexann__sec">
      <ul class="hexann__changes">
        <li>${t('无尽模式标记由 BETA 更新为 BETA 0.1 —— 该模式仍在测试中，欢迎继续反馈。')}</li>
      </ul>
    </div>
      </div>
    </details>
      </div>
    </details>

    <${MicroLabel} tone="mint">${t('HISTORY // 往期公告（滚轮向下查看）')}<//>
    <details class="hexann__fold">
      <summary><span class="hexann__arrow">▶</span>${t('V0.03 公告（盟约专属海克斯 / 三海克斯局 / 自选海克斯 / 无尽模式 / 房间时长）')}</summary>
      <div class="hexann__fold-body hexann__history">
        <p>${t('海克斯模组 V0.03：新增「盟约专属」海克斯系列（第六轮征集 18 条）、三海克斯局、自选海克斯、无尽模式与房间时长设置；修复 5 人以上联防兜底 bug；更新弹窗改到网页内自选。')}</p>

        <${MicroLabel} tone="gold">${t('BOND EXCLUSIVE // 盟约专属海克斯（18 条）')}<//>
        <div class="hexann__sec">
          <p>${t('主盟约战斗机制线：炎 / 萨尔贡 / 维多利亚 / 谢拉格 / 阿戈尔 / 叙拉古 / 卡西米尔 × 各 2–3 条。全局规则：')}</p>
          <ul class="hexann__changes">
            <li>${t('每局只能选择一条盟约专属 —— 首次选择后，后续所有发放回合都不再出现盟约类海克斯（同一批三选一里也最多一条）。')}</li>
            <li>${t('所有炫彩盟约海克斯附加效果：选择后立即随机获得 1 名 3 阶对应盟约干员。')}</li>
            <li>${t('第一回合之后，盟约系海克斯更倾向于你当前已激活的盟约 —— 激活层数越多，出现权重越高。')}</li>
            <li>${t('18 条效果全部实装。')}</li>
          </ul>
          <details class="hexann__fold" open>
            <summary><span class="hexann__arrow">▶</span>${t('展开查看：盟约专属海克斯 18 条（点击单条展开）')}</summary>
            <div class="hexann__fold-body">
              <div class="hexann__hexlist">
                ${bondLive.map((h) => html`<${HexAnnCard} key=${h.id} hex=${h} />`)}
              </div>
            </div>
          </details>
        </div>

        <${MicroLabel} tone="mint">${t('MODES // 模式与房间设置')}<//>
        <div class="hexann__sec">
          <ul class="hexann__changes">
            <li>${t('三海克斯局：海克斯草案改在第 1 / 5 / 9 回合共发放三次（默认 1 / 7 两次）。')}</li>
            <li>${t('自选海克斯：从图鉴里指定本局海克斯（普通双海克斯局可选 2 条，三海克斯局 3 条），对局的每次草案按指定顺序自动发放。')}</li>
            <li>${t('无尽模式：原层数打完后每 5 关进行一次 Boss，期间每关敌人所有属性 +20% 累进（无上限）；所有盟约层数解锁无上限。')}</li>
            <li>${t('房间时长设置（仅联合模式）：房主可设定海克斯选择时长与准备回合时长；独立模拟不可设定。')}</li>
          </ul>
        </div>

        <${MicroLabel} tone="mint">${t('FIX // 修复与体验')}<//>
        <div class="hexann__sec">
          <ul class="hexann__changes">
            <li>${t('修复 5 人以上房间联防兜底失效：按座位分队后尾队可能只剩 1 人，该玩家被识别成「无队友」—— 漏怪时没人救、满状态时救不了别人。现在孤队自动并入最近的互补小队。')}</li>
            <li>${t('3D 棋盘韧性：画布偶发丢失不再整局卡死在残缺画面 —— 自动以最长间隔无限重试恢复，连续失败时自动降低画质保住 3D，恢复成功自动还原画质；2D 兼容时战场顶部与左上角会出现可见提示。')}</li>
            <li>${t('崩溃诊断工具（上一版热修）：启动器目录的崩溃诊断脚本，一键生成桌面报告定位启动问题。')}</li>
            <li>${t('更新提示改版：发现新版本时改为游戏内弹窗询问「是否更新」，选择更新才跳转网盘链接，不再打断启动。')}</li>
          </ul>
        </div>
      </div>
    </details>

    <details class="hexann__fold">
      <summary><span class="hexann__arrow">▶</span>${t('V0.021 公告（修复我方干员增益 bug）')}</summary>
      <div class="hexann__fold-body hexann__history">
        <${MicroLabel} tone="gold">${t('HOTFIX // V0.021 修复')}<//>
        <div class="hexann__sec">
          <p>${t('修复「对我方干员的增益只有攻速生效、其余反而降低干员属性」的 bug：原因是增益写入与读取的属性键名不一致，增益不生效的同时还会把干员已有的练度与局内百分比加成一并抹掉。现在对局选项的四维增益滑条与协防协议、宝宝学院、名刀等所有干员增益全部正常生效。')}</p>
        </div>
        <${MicroLabel} tone="mint">${t('FRAMEWORK // 框架升级（V0.02）')}<//>
        <div class="hexann__sec">
          <p>${t('本版本接入了其他大佬开发的 < Forge 模组管理器 >，统一了模组管理能力：支持装载工坊模组包，并兼容了账号系统、匹配队列、聊天面板、名片座位卡、主池百人局、助战计价等更多功能。')}</p>
          <p class="hexann__link"><a href="https://github.com/XiaMo233M/Stronghold-Protocol-Forge-Mods/blob/main/SKILL.md" target="_blank" rel="noopener noreferrer">github.com/XiaMo233M/Stronghold-Protocol-Forge-Mods · SKILL.md</a></p>
          <ul class="hexann__changes">
            <li>${t('Forge 0.18.6 引擎合并：三方合并 1799 个文件 —— 采纳 Forge 版修改 129 个、引入新增文件 1187 个（编辑器 / 工坊 / 账号 / 匹配队列 / 聊天 / 皮肤 / 资源分发等）。')}</li>
            <li>${t('双方都改的 28 个文件完成合流：21 个自动合并；7 个文件 18 处冲突手工解决（Match / views / phases / economy / protocol / lobby / room）。')}</li>
            <li>${t('对局选项面板紧凑化：默认收成一条细栏，非默认设置压成摘要徽章，展开后为竖排窄卡，不再横铺整行。')}</li>
            <li>${t('修复每次启动误判缺件并尝试联网下载、卡顿约 6 分钟的问题 —— 现在启动约 2 秒、零下载。')}</li>
            <li>${t('工坊系统接入：服务器可装载工坊模组包；带模组的服务器在创建 / 加入房间时校验模组集一致性。')}</li>
            <li>${t('网络协议适配：对齐 Forge 的协议变化（新增 BATTLE_CHECK 阶段、公共视野字段调整等）。')}</li>
            <li>${t('海克斯相关：局内商店对大多数装备归总所属盟约 tag；新增「凭证」转职类海克斯 8 条（全部黄金）；海克斯总数 42 → 50（黄金 16 → 24）。')}</li>
          </ul>
        </div>
      </div>
    </details>
  <//>`;
}

/** 大厅顶栏工具排的公告按钮（方块图标钮，与设置 / 玩法说明同排同款）。 */
export function HexAnnouncementButton({ onClick }) {
  return html`<button type="button" class="btn btn--secondary btn--sm btn--square hub-ann-btn tapx"
    onClick=${onClick} title=${t('更新公告')} aria-label=${t('更新公告')}>
    <${GIcon} name="flag" />
  </button>`;
}
