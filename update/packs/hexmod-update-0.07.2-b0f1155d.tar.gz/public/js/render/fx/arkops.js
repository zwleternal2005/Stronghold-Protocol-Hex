// public/js/render/fx/arkops.js — FxSystem placement of `arkOperatorFx` sim events (2026-11-01 operator pack).
// Installed on FxSystem.prototype by ./system.js (a method container: never instantiated; `this` is the effect system).
//
// The operator kits (chess_char_6_30/31/32 — 冻河/国度/塔露拉) emit `b.fx('arkOperatorFx', extra)` where `extra`:
//   nativeKey   the official effect the event stands for (oxi_* / tocka_* / dminon_*);
//   effectId    a persistent instance's key — the sim re-addresses it later;
//   id          the owner unit (anchor when the event has no own spot);
//   target      a unit the effect hangs on (an ally's buff mark);
//   loop        a persistent effect (one-shots omit it);
//   dur         an optional finite life (game s / timeScale applied by the caller);
//   fixed       anchored to the field position, never the owner;
//   dc, dr, speed, surviveOwnerExit   a travelling shot (oxi S3's heat wave): the client advances it itself;
//   action      'stop' (end the effectId) | 'clearOwner' (end every effect of the owner; travelling shots
//               `surviveOwnerExit` outlive their owner's exit).
//
// The official prefabs are Unity particle graphs this client does not play (see the pack README) — each nativeKey gets
// a procedural stand-in in this client's particle vocabulary, palette lifted from the prefab's start colours:
//   oxi (塔露拉) fire wave / footprint fields — orange-red; tocka (冻河) shield & buff marks — gold;
//   dminon (国度) realm marks & talent procs — deep red.

import { NO_OPTS } from './limits.js';

void NO_OPTS;

/** A persistent instance that lives longer than this (real s) is presumed leaked and freed (the sim always stops its own). */
const MAX_LIFE_S = 30;
/** Registry cap: beyond it the oldest instance is freed (the sim keeps well under this: two waves' lanes + fields + marks). */
const MAX_INSTANCES = 96;

const num = (v, d) => { const n = typeof v === 'number' ? v : typeof v === 'string' && v.trim() !== '' ? Number(v) : NaN; return Number.isFinite(n) ? n : d; };

/** Tint per nativeKey family (prefab start colours / kit semantics). */
const TINTS = {
  fire: 0xff8c3a,      // oxi S3 heat wave & hits
  ember: 0xff5a22,     // oxi footprint fields
  gold: 0xf2d259,      // tocka marks & shields
  goldSoft: 0xfff3c4,
  realm: 0xe8503a,     // dminon realm marks
  realmHit: 0xd93a30,  // dminon talent procs
};

export class FxArkOps {
  /** Lazy registry of persistent instances (keyed by effectId). */
  _ark() { return this.arkFxs ?? (this.arkFxs = new Map()); }

  /**
   * `b.ev ['fx', 'arkOperatorFx', x, y, extra]` (server/sim/content/kits/ops/chess_char_6_3*.js).
   * One-shots draw right here; persistent instances enter the registry and _updateArkFx drives them per frame.
   */
  arkOperatorFx(x, y, ex) {
    const extra = ex && typeof ex === 'object' ? ex : {};
    const ts = this.ctx.timeScale ? Math.max(0.25, this.ctx.timeScale()) : 2;
    if (extra.action === 'stop') {
      const M = this._ark();
      const f = M.get(extra.effectId);
      if (f) { this._endArkFx(f); M.delete(extra.effectId); }
      return;
    }
    if (extra.action === 'clearOwner') {
      const M = this._ark();
      for (const [k, f] of M) if (f.owner === extra.id && !f.survive) { this._endArkFx(f); M.delete(k); }
      return;
    }
    const kind = String(extra.nativeKey || '');
    const at = extra.fixed ? this._point(Number(x), Number(y)) : this._where(Number(x), Number(y), extra);
    if (!Number.isFinite(at.x) || !Number.isFinite(at.y)) return;
    switch (kind) {
      case 'oxi_skill_03_hit_01':   // the heat wave's contact explosion (after the same effectId's 'stop')
        this.explosion(at.x, at.y, at.z, 0.9, TINTS.fire, { small: true });
        break;
      case 'dminon_talent_hit_01':  // 国度 talent proc on its owner: a deep-red burst
        this.explosion(at.x, at.y, at.z, 0.75, TINTS.realmHit, { small: true });
        break;
      case 'tocka_skill_01_buff_02_start_01':  // 冻河 S1 trigger on the struck ally: a gold ward flashes on
        this._goldWard(at.x, at.y, at.z);
        break;
      default: {
        // persistent families; unknown keys keep the generic route below only when they claim no persistence
        if (!extra.loop) { this._genericMark(at.x, at.y, at.z); break; }
        const f = {
          id: String(extra.effectId ?? `anon:${Math.random()}`), key: kind, owner: extra.id ?? null,
          target: extra.target ?? null, x: at.x, y: at.y, z: at.z,
          dc: num(extra.dc, 0), dr: num(extra.dr, 0), speed: num(extra.speed, 0),
          dur: num(extra.dur, Infinity) / ts, survive: !!extra.surviveOwnerExit, t: 0, emit: 0,
        };
        const M = this._ark();
        if (!M.has(f.id)) {
          M.set(f.id, f);
          if (M.size > MAX_INSTANCES) { const oldest = M.keys().next().value; this._endArkFx(M.get(oldest)); M.delete(oldest); }
        } else { Object.assign(M.get(f.id), { x: at.x, y: at.y, z: at.z, dur: f.dur }); }
        // ground families park a zone disc under themselves (the zone's own key keeps it single-layer); it fades on _endArkFx
        if (kind === 'oxi_buff_01' || kind === 'dminon_talent_range_01') {
          const col = kind === 'oxi_buff_01' ? TINTS.ember : TINTS.realm;
          this.zone(at.x, at.y, at.z, 0.55, col, Number.isFinite(f.dur) ? Math.min(f.dur, MAX_LIFE_S) : MAX_LIFE_S, 'soft', false, `ark:${f.id}`);
        }
      }
    }
  }

  /** One-shot gold ward (冻河 S1's trigger): flash + ring + sparks, the prefab's gold palette. */
  _goldWard(x, y, z) {
    const cam = this.ctx.cam();
    const g = cam.project(x, y, z + 0.3, this._g);
    this.particle('glow', g.x, g.y, { tint: TINTS.gold, life: 0.4, s0: g.s / 128 * 1.1, s1: g.s / 128 * 1.9, a0: 0.95, a1: 0 });
    this.particle('flare', g.x, g.y, { tint: TINTS.goldSoft, life: 0.22, s0: g.s / 128 * 1.2, s1: g.s / 128 * 0.4, a0: 1, a1: 0, rot: Math.random() * 3 });
    this.ring(x, y, z, 0.12, 0.85, TINTS.gold, 0.4);
    this.burst(g.x, g.y, g.s, 7, TINTS.gold, { speed: 2.2, life: 0.4, up: 0.5 });
  }

  /** A persistent nativeKey this build has no recipe for: a brief neutral shimmer so the event still reads. */
  _genericMark(x, y, z) {
    const cam = this.ctx.cam();
    const g = cam.project(x, y, z + 0.3, this._g);
    this.particle('glow', g.x, g.y, { tint: 0xcfd6e4, life: 0.3, s0: g.s / 128 * 0.6, s1: g.s / 128 * 1.1, a0: 0.6, a1: 0 });
  }

  /** End a persistent instance: its zone (if any) fades now, a travelling wave leaves nothing behind. */
  _endArkFx(f) {
    if (f.key === 'oxi_buff_01' || f.key === 'dminon_talent_range_01') {
      const zn = this.zones.find((q) => q.key === `ark:${f.id}`);
      if (zn) zn.dur = Math.min(zn.dur, zn.t + 0.25);
    }
  }

  _updateArkFx(dt) {
    const M = this.arkFxs;
    if (!M || !M.size) return;
    const cam = this.ctx.cam();
    const ts = this.ctx.timeScale ? Math.max(0.25, this.ctx.timeScale()) : 2;
    const dts = dt * ts;
    for (const [k, f] of M) {
      f.t += dt;
      // `dur` arrived in game seconds and was converted at creation; a leaked instance (no stop ever came) dies here too
      if (f.t >= Math.min(f.dur, MAX_LIFE_S)) { this._endArkFx(f); M.delete(k); continue; }
      // the heat wave advances itself (the sim moved on; the client reproduces the flight)
      if (f.speed > 0) {
        f.x += f.dc * f.speed * dts;
        f.y += f.dr * f.speed * dts;
      } else if (f.target != null) {
        const v = this._viewOf(f.target);
        if (v && Number.isFinite(v.x) && Number.isFinite(v.y)) { f.x = v.x; f.y = v.y; f.z = (v.z || 0) + (v.hover || 0); }
      }
      this._arkEmit(f, cam);
    }
  }

  /** Per-frame visuals of a persistent instance (particle emission at its current spot). */
  _arkEmit(f, cam) {
    const low = this.quality === 'low';
    f.emit -= 1;
    if (f.emit > 0) return;
    const g = cam.project(f.x, f.y, f.z + 0.3, this._g);
    switch (f.key) {
      case 'oxi_skill_03_trail_01': {
        // heat wave: a hot core, embers dragging behind and a glow — dense enough that consecutive frames join into a wave
        const rot = Math.atan2(f.dr, f.dc);
        this.particle('glow', g.x, g.y, { tint: TINTS.fire, life: 0.3, s0: g.s / 128 * 0.9, s1: g.s / 128 * 1.5, a0: 0.85, a1: 0 });
        this.particle('dot', g.x, g.y, { tint: TINTS.goldSoft, life: 0.22, s0: g.s / 64 * 0.35, s1: g.s / 64 * 0.1, a0: 1, a1: 0 });
        if (!low) for (let i = 0; i < 2; i++) {
          const spread = (Math.random() - 0.5) * g.s * 0.5;
          this.particle('dot', g.x + spread, g.y - g.s * Math.random() * 0.3, { tint: TINTS.ember, vy: -g.s * (0.5 + Math.random() * 0.7), life: 0.45 + Math.random() * 0.3, s0: g.s / 64 * 0.22, s1: g.s / 64 * 0.06, a0: 0.9, a1: 0, rot });
        }
        f.emit = low ? 2 : 1;
        break;
      }
      case 'oxi_buff_01': {
        // footprint fire field: rising embers off the parked zone
        const ox = (Math.random() - 0.5) * g.s * 0.8;
        this.particle('dot', g.x + ox, g.y, { tint: TINTS.ember, vy: -g.s * (0.7 + Math.random() * 0.6), life: 0.5 + Math.random() * 0.3, s0: g.s / 64 * 0.16, s1: g.s / 64 * 0.04, a0: 0.85, a1: 0 });
        this.particle('glow', g.x, g.y, { tint: TINTS.ember, life: 0.35, s0: g.s / 128 * 0.5, s1: g.s / 128 * 0.8, a0: 0.3, a1: 0 });
        f.emit = low ? 14 : 7;
        break;
      }
      case 'dminon_talent_range_01': {
        // 国度 realm mark: a slow deep-red pulse on the tile
        this.particle('glow', g.x, g.y, { tint: TINTS.realm, life: 0.5, s0: g.s / 128 * 0.6, s1: g.s / 128 * 1.0, a0: 0.35, a1: 0 });
        if (!low && Math.random() < 0.4) {
          const ox = (Math.random() - 0.5) * g.s * 0.7;
          this.particle('dot', g.x + ox, g.y, { tint: TINTS.realmHit, vy: -g.s * 0.5, life: 0.6, s0: g.s / 64 * 0.12, s1: 0, a0: 0.7, a1: 0 });
        }
        f.emit = low ? 16 : 9;
        break;
      }
      case 'tocka_skill_01_buff_01':
      case 'tocka_skill_01_buff_02':
      case 'tocka_skill_02_buff_02': {
        // 冻河's ally marks: a gold shimmer rising off the shielded operator
        this.particle('chevron', g.x + (Math.random() - 0.5) * g.s * 0.6, g.y - g.s * (0.1 + Math.random() * 0.4), { tint: TINTS.gold, vy: -g.s * (0.8 + Math.random() * 0.5), life: 0.55, s0: g.s / 64 * 0.18, s1: g.s / 64 * 0.08, a0: 0.9, a1: 0, rot: -Math.PI / 2, fadeIn: 0.06 });
        this.particle('glow', g.x, g.y - g.s * 0.2, { tint: TINTS.goldSoft, life: 0.3, s0: g.s / 128 * 0.5, s1: g.s / 128 * 0.9, a0: 0.35, a1: 0 });
        f.emit = low ? 10 : 6;
        break;
      }
      default: f.emit = 12;
    }
  }
}

/** Re-exported for system.js's method table (NO_OPTS keeps the container import honest). */
const _ = NO_OPTS; void _;
