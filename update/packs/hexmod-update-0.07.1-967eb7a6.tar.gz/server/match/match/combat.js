// server/match/match/combat.js — Match methods: the battles of a normal round — Battle construction (newBattle, the
// spawn list sanitised, a player's normal field after the onBattleStart handlers), the COMBAT phase in both modes
// (server-run streaming, client-side combat), the per-field results and the sim-error log, then 联防 or SETTLE.
// Installed on Match.prototype by server/match/Match.js (a method container: never instantiated; `this` is the match).

import { PHASE, GEO, tuningMods } from '../../../shared/constants.js';
import { deriveSeed } from '../../sim/rng.js';
import { withBounties } from '../waves.js';
import { planUnite } from '../unite.js';
import { FieldRunner, DeadBattle } from '../fields.js';
import { DELAYS } from './common.js';
import { battleOptsFromMatch } from './battleOpts.js';

export class MatchCombat {
  /** Construct a battle; a constructor failure yields a finished stand-in (clean result) and is logged. */
  newBattle(opts) {
    // The assembly both Battle paths share (server/match/match/battleOpts.js): `this.ds` / `this.battleContent` /
    // `this.log` under the caller's own options, then the match's kit tables (`kits`, `tokenKits` — docs/WORKSHOP.md
    // §4 / §4.7, the room-trimmed `roomAssets.forRoom(room.modSet)` maps), the pack's battle installers
    // (DESIGN §28.17) and the 限伤 override. An explicit opts.<key> always wins; a match without packs sets no key, so
    // a plain install builds byte-for-byte the battle it built before each feature landed. `_specBattle` (复算) calls
    // the same helper, so a sixth key cannot reach one path and stop at the other.
    const full = battleOptsFromMatch(this, opts);
    try {
      return new this.BattleClass(full);
    } catch (e) {
      this.reportError(`battle ${opts.fieldId} construct`, e);
      return new DeadBattle(full, 'forced');
    }
  }

  /**
   * Spawn list of a field after the onBattleStart handlers (which may edit `ev.spawns`): malformed entries are dropped
   * and a kill bounty is copied into `mods.bountyCoins`, so a leaked bounty enemy keeps paying its killer in 联防.
   *
   * 局内难度微调 (this fork): the room host's sliders (Match.tuning) are multiplied into **every** spawn's mods here —
   * the single choke point all three field kinds pass through (normal `_normalOpts`, boss `bossRounds.js`, 联防
   * `unitePhase.js`), so the setting raises the enemies of the whole match, leaders included. The sim reads
   * hpMul / atkMul / defMul / resMul when it instantiates a spawn (server/sim/battle/spawns.js).
   */
  _sanitizeSpawns(list, ownerPlayerId = null) {
    const tune = tuningMods(this.tuning);
    const out = [];
    for (const s of Array.isArray(list) ? list : []) {
      if (!s || typeof s !== 'object' || typeof s.enemyKey !== 'string' || !this.gd.enemy(s.enemyKey)) continue;
      const spec = { ...s, mods: s.mods && typeof s.mods === 'object' ? { ...s.mods } : {} };
      if (ownerPlayerId && spec.ownerPlayerId == null) spec.ownerPlayerId = ownerPlayerId;
      const coins = spec.bounty && typeof spec.bounty === 'object' ? Math.trunc(Number(spec.bounty.coins) || 0) : 0;
      if (coins > 0 && spec.mods.bountyId == null && spec.mods.bountyCoins == null) spec.mods.bountyCoins = coins;
      for (const [key, mul] of Object.entries(tune)) {
        spec.mods[key] = (Number.isFinite(spec.mods[key]) ? spec.mods[key] : 1) * mul;
      }
      // 无尽模式 (this fork)：bossRound 之后的回合，敌人四维按 1.2^(r − bossRound) 累进（Match.endlessMul，
      // 无上限）—— 这是所有战场共用的咽喉，普通关 / Boss 关 / 领袖都在这里吃到倍率。
      const emul = (this.endlessMul ? this.endlessMul(this.round) : 1) * (this.meltMul ? this.meltMul() : 1);
      if (emul !== 1) {
        for (const k of ['hpMul', 'atkMul', 'defMul', 'resMul']) {
          spec.mods[k] = (Number.isFinite(spec.mods[k]) ? spec.mods[k] : 1) * emul;
        }
      }
      // 熔毁协议的「敌方受伤减免」折算成等效生命（1/(1-r)），只作用在 hp 上
      const meltHp = this.meltHpMul ? this.meltHpMul() : 1;
      if (meltHp !== 1) spec.mods.hpMul = (Number.isFinite(spec.mods.hpMul) ? spec.mods.hpMul : 1) * meltHp;
      out.push(spec);
    }
    return out;
  }

  _normalBattle(ps) { return this.newBattle(this._normalOpts(ps)); }

  /** Battle options of a player's normal field (after the onBattleStart handlers). */
  _normalOpts(ps) {
    const wave = this.wave;
    const input = ps.battleInput({ side: 'L', colOffset: 0 });
    // the client's list: bounty units inserted among their host action's own units, which are re-timed around them
    const spawns = withBounties(this.gd, this.round, wave, ps.bounties, ps.playerId).map((s) => ({ ...s, ownerPlayerId: ps.playerId }));
    const ev = { input, kind: 'normal', round: this.round, spawns };
    this.dispatch(ps, 'onBattleStart', ev);
    const list = this._sanitizeSpawns(Array.isArray(ev.spawns) ? ev.spawns : spawns, ps.playerId);
    // 海克斯 (TFT-style augment, this fork — MatchHexDraft.hexSpawnModsOf): the player's own enemy stat multipliers,
    // folded into every spawn's mods so they travel to the browser inside the battle spec (the browser runs the same
    // sim: server/sim/battle/spawns.js reads mods.* — no sim change needed).
    const hexMods = this.hexSpawnModsOf(ps);
    if (hexMods) {
      for (const s of list) {
        const mods = { ...s.mods };
        for (const [k, v] of Object.entries(hexMods)) mods[k] = (Number.isFinite(mods[k]) ? mods[k] : 1) * v;
        s.mods = mods;
      }
    }
    return {
      seed: deriveSeed(this.seed, `n:${this.round}:${ps.seat}`),
      kind: 'normal',
      modeId: this.modeId,
      round: this.round,
      stageId: this.stageId,
      rect: { ...this.layout.battle.normal },
      timeLimit: wave.timeLimit,
      players: [ev.input && typeof ev.input === 'object' ? ev.input : input],
      spawns: list,
      routes: wave.routes,
      sharedBoss: null,
      flags: {
        layerGainsEnabled: true,
        // 对局选项 · 全局设置 (this fork): 层数上限解除 — the sim's live copy clamps with the same lifted cap
        layerUncap: this.flags.bondLayerUncap === true,
        // 对局选项 · 全局设置 (v0.07.1): 特质叠层上限解除 — 干员特质「每场作战至多 N 层」的 per-battle cap 全部失效
        // （sim 侧 support/gainLayers 的 caps 表与 garrison 的 bond_actived_maxstack 整层帽都读这把旗）
        traitLayerUncap: this.flags.traitLayerUncap === true,
        // 海克斯 碎片大厦的回忆 (this fork): 怪物进核心时全场怪物吃 1000 伤害 + 沉默 0.5s（sim 的 leak 路径读；
        // 只写在普通战场的 flags 上 —— 联防 / 首领战 spec 不带它，自然不触发）
        ...(this.hexLeakNukeOf(ps) ? { leakNuke: this.hexLeakNukeOf(ps) } : {}),
        // 海克斯 焚尽八荒 (this fork, v0.03.2): 敌方灼燃逼爆冷却时长倍率（sim/damage.js 的 burn 爆发读）
        ...(this.hexBurnCdMulOf(ps) != null ? { burnBurstCdMul: this.hexBurnCdMulOf(ps) } : {}),
        ...this.gd.dp,
      },
      fieldId: `n:${ps.playerId}`,
      enemyOverrides: wave.overrides,
      waveId: wave.templateId,
      // 限伤 override for the CLIENT-run spec (shared/constants.js bossHitLimitFrom): only present when a deployment
      // set it, so an unconfigured server sends byte-for-byte the old spec (and server/sim/spec.js is left untouched
      // by the key's absence).
      ...(this.bossHitLimit === undefined ? {} : { bossHitLimit: this.bossHitLimit }),
    };
  }

  startCombat() {
    if (this.clientCombat) { this._startCombatClient(); return; }
    this.phase = PHASE.COMBAT;
    const alive = this.alivePlayers();
    this.lastResults = new Map();
    this.fields = alive.map((ps) => ({ fieldId: `n:${ps.playerId}`, kind: 'normal', players: [ps.playerId], battle: this._normalBattle(ps), live: true }));
    const limit = this.wave ? this.wave.timeLimit : 60;
    this.deadline = this.sched.instant ? 0 : this.sched.now() + Math.round((limit / this.gameSpeed) * 1000);
    this._defaultWatch();
    this.markPublic();
    this.runner = new FieldRunner(this, this.fields, { onDone: (runner) => this.combatDone(runner) });
    this.runner.start();
  }

  _startCombatClient() {
    this.phase = PHASE.COMBAT;
    const alive = this.alivePlayers();
    this.lastResults = new Map();
    this.watchers.clear();
    const fields = alive.map((ps) => this._ccField({ fieldId: `n:${ps.playerId}`, kind: 'normal', players: [ps.playerId], opts: this._normalOpts(ps) }));
    const limit = this.wave ? this.wave.timeLimit : 60;
    this.deadline = this.sched.instant ? 0 : this.sched.now() + Math.round((limit / this.gameSpeed) * 1000);
    this._launch(fields);
    // every fighting human runs its own field; eliminated humans (and spectator seats) keep watching (research 09 §3.1
    // "Keep-watching auto-observes the first available field", switching freely with 前往查看): a replica of the field
    // of the player they follow — the one they last watched, else the first player still in (item 56) — else the first
    for (const f of fields) for (const pid of f.players) {
      const ps = this.players.get(pid);
      if (!ps || ps.isBot || ps.left) continue;
      this.watchers.set(pid, f.fieldId);
      this._sendStart(pid, f);
    }
    const first = fields.find((f) => f.mode === 'client') || fields[0] || null;
    if (first) {
      for (const ps of this._viewers()) {
        if (ps.alive || this.watchers.has(ps.playerId)) continue;
        const f = this._watchTargetField(ps, fields) || first;
        this.watchers.set(ps.playerId, f.fieldId);
        this._sendStart(ps.playerId, f, { watch: true });
      }
    }
    this.markPublic();
  }

  /** Aggregate a finished field's content/engine errors (battle.errors: unique records) for diagnostics. */
  _collectSimErrors(f, res) {
    this.simErrors += Number(res && res.errors) || 0;
    const list = f && f.battle && Array.isArray(f.battle.errors) ? f.battle.errors : [];
    for (const e of list) {
      if (!e || typeof e !== 'object') continue;
      const key = `${e.label}|${e.who || ''}|${e.message}`;
      let rec = this.simErrorLog.get(key);
      if (!rec) {
        if (this.simErrorLog.size >= 500) continue;
        rec = { label: String(e.label), who: String(e.who || ''), message: String(e.message), stack: e.stack ? String(e.stack) : null, battles: 0, count: 0 };
        this.simErrorLog.set(key, rec);
      }
      rec.battles++;
      rec.count++;
    }
  }

  combatDone(runner) { this._finishCombat((f) => runner.resultOf(f)); }

  /** Every normal field has its result: record them, then 联防 or SETTLE. */
  _finishCombat(resultOf) {
    if (this.phase !== PHASE.COMBAT) return;
    this._stopClientCombat();
    for (const f of this.fields) {
      const res = resultOf(f);
      this._collectSimErrors(f, res);
      for (const pid of f.players) {
        const pp = res.perPlayer && res.perPlayer[pid];
        this.lastResults.set(pid, pp || { killed: 0, total: 0, leaked: [], perfect: true, layerGains: {}, coins: 0, damageDealt: 0, unitsEnd: [], unitStats: [] });
        // the views show the layers the battle reached until settle() makes them persistent (DESIGN §20.15)
        const ps = this.players.get(pid);
        // 阿米娅光环 (v0.05.3)：范围内干员开技能 → 己方**已激活**盟约各 +N 层；上限遵循房间 bondLayerUncap 开关。
        if (ps && pp && Number(pp.amiyaBondGain) > 0 && typeof ps.addLayers === "function") {
          const n = Math.max(0, Math.trunc(Number(pp.amiyaBondGain)));
          for (const bid of Object.keys(ps.bonds || {})) {
            const b = ps.bonds[bid];
            if (!b || !b.active) continue;
            ps.addLayers(bid, n, { requireActive: false, reason: "amiya" });
          }
          this.toast(ps, "info", "阿米娅：范围内干员开技能 —— 已激活盟约各 +" + n + " 层");
        }
        // 专属干员统计钩子 (v0.05.3)：把【阿米娅(医疗)】在本场的伤害/治疗累加进本局总量。
        // 数据源是 BattleResult.perPlayer[].unitStats（客户端战斗也带得回来），按 defId 前缀认人。
        if (ps && pp && Array.isArray(pp.unitStats)) {
          let aDmg = 0; let aHeal = 0;
          for (const u of pp.unitStats) {
            if (!u || !String(u.defId || '').startsWith('chess_char_5_99')) continue;
            aDmg += Number(u.dmg) || 0;
            aHeal += Number(u.heal) || 0;
          }
          if (aDmg || aHeal) {
            if (!ps.amiyaStats || typeof ps.amiyaStats !== 'object') ps.amiyaStats = { dmg: 0, heal: 0 };
            ps.amiyaStats.dmg += aDmg;
            ps.amiyaStats.heal += aHeal;
            // ── 里程碑 (v0.05.3) ──
            // ① 累计伤害 500 万 ⇒ 进阶 + 本局伤害 25% 转真实
            if (!ps.amiyaTrue && ps.amiyaStats.dmg >= 5000000) {
              ps.amiyaTrue = true;
              ps.amiyaAdvanced = true;
              const baseId = 'chess_char_5_99_a';
              const amiya = ps.allChess().find((piece) => piece.id === baseId);
              if (amiya && typeof ps.promote === 'function') ps.promote(amiya);
              this.toast(ps, "info", "阿米娅：累计伤害达 500 万 —— 进阶，此后 25% 伤害转为真实伤害");
            }
            // ② 累计治疗 500 万 ⇒ 范围内单次受伤 ≤10% 最大生命
            if (!ps.amiyaMaxHit && ps.amiyaStats.heal >= 5000000) {
              ps.amiyaMaxHit = true;
              this.toast(ps, "info", "阿米娅：累计治疗达 500 万 —— 范围内单次受到的伤害不超过 10% 最大生命");
            }
          }
        }
        // v0.05：本场弹药累计 —— 优先读 BattleResult.perPlayer（**客户端战斗**时服务端没有 Battle 对象），
        // 服务端自己跑的战斗退回 Battle 实例上的计数器。
        const bt = f && f.battle;
        const latFromResult = Number(pp && pp.lateranoAmmo);
        const allFromResult = Number(pp && pp.ammo);
        if (ps && Number.isFinite(latFromResult) && latFromResult > 0) {
          ps.lateranoAmmo = (Number(ps.lateranoAmmo) || 0) + Math.trunc(latFromResult);
        } else if (ps && bt) {
          const meter = bt.lateranoAmmo instanceof Map ? bt.lateranoAmmo.get(pid) : null;
          if (meter) ps.lateranoAmmo = (Number(ps.lateranoAmmo) || 0) + meter.total;
        }
        // 实时值清零：最终数字已经并入上面的累计值（否则会重复计算）
        if (ps) { ps.lateranoAmmoLive = 0; ps.ammoLive = 0; }
        if (ps && Number.isFinite(allFromResult) && allFromResult > 0) {
          ps.ammoUsed = (Number(ps.ammoUsed) || 0) + Math.trunc(allFromResult);
        } else if (ps && bt) {
          const all = bt.ammoSpent && Number(bt.ammoSpent.ally);
          if (all > 0) ps.ammoUsed = (Number(ps.ammoUsed) || 0) + all;
        }
        const gains = pp && pp.layerGains && typeof pp.layerGains === 'object' ? pp.layerGains : null;
        if (ps && gains && Object.keys(gains).length) { ps.pendingLayerGains = { ...gains }; ps.dirty(); }
      }
    }
    for (const f of this.fields) f.live = false;
    this.deadline = 0;
    this.markPublic();
    this.later(this.scaled(DELAYS.COMBAT_END), () => this._afterCombat());
  }

  /**
   * After the COMBAT_END pause: 联防 or SETTLE. The plan is made now, from the players still in — a player who quit
   * during the last field or the pause (中途退出 = eliminated, board cleared) is neither a helper nor a leaker whose
   * enemies re-enter.
   */
  _afterCombat() {
    if (this.phase !== PHASE.COMBAT) return;
    const plan = planUnite(this, this.lastResults);
    if (plan) this.startUnite(plan);
    else this.settle(null, null);
  }
}
