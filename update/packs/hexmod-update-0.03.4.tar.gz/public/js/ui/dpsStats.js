// dpsStats — 「DPS 查看」面板的数据仓库（this fork, v0.03.3, 用户要求）。
//
// 战斗结果（b.result）里已经带了每个单位的输出账：`perPlayer[pid].unitStats = [{ uid, defId, kind, dmg, kills, heal, taken, attacks }]`
// （server/sim/spec.js compactResult）。这里按「干员」「盟约」两个维度把**本局每一场**的结果累加起来，
// 面板只读这份快照 —— 战斗进程零改动，也不需要服务端多传字段。
//
// 盟约归属：干员的 defId → 客户端棋库记录的 bonds（同一位干员的多个盟约各自计一份，和游戏里盟约层数的算法同源）。

/** @type {{ rounds: number, ops: Map<string, {key:string,name:string,dmg:number,kills:number}>, bonds: Map<string, {key:string,name:string,dmg:number}> }} */
const store = { rounds: 0, ops: new Map(), bonds: new Map() };

/** 开新的一局时清空（房间开局 / 回到大厅由调用方触发）。 */
export function resetDps() {
  store.rounds = 0;
  store.ops.clear();
  store.bonds.clear();
}

/**
 * 吃一场战斗的结果。`unitStats` 来自 `result.perPlayer[myPid].unitStats`（可能为空/缺字段，全部容错）。
 * @param {any[]|null|undefined} unitStats
 * @param {(defId: string) => any} chessOf 取干员记录（名称/盟约）
 * @param {(bondId: string) => any} bondOf 取盟约记录（名称）
 */
export function addBattleResult(unitStats, chessOf = () => null, bondOf = () => null) {
  if (!Array.isArray(unitStats) || !unitStats.length) return;
  store.rounds += 1;
  for (const u of unitStats) {
    const dmg = Math.max(0, Number(u && u.dmg) || 0);
    const kills = Math.max(0, Number(u && u.kills) || 0);
    if (!dmg && !kills) continue;
    const defId = u && typeof u.defId === 'string' ? u.defId : null;
    if (!defId) continue;                    // 没有记录 id 的单位无法命名/归属，跳过
    // v0.03.3 用户要求：召唤物（炎佑等）也要统计 —— 只按 kind 给名字加个后缀，其余口径一致
    const isSummon = !!(u.kind && u.kind !== 'op');
    const rec = chessOf(defId) || {};
    const name = rec.name || defId;
    const showName = isSummon ? `${name}（召唤物）` : name;
    const cur = store.ops.get(defId) || { key: defId, name: showName, dmg: 0, kills: 0 };
    cur.dmg += dmg;
    cur.kills += kills;
    cur.name = showName;
    store.ops.set(defId, cur);
    const bonds = Array.isArray(rec.bonds) ? rec.bonds : (Array.isArray(rec.bondIds) ? rec.bondIds : []);
    for (const bid of bonds) {
      if (typeof bid !== 'string' || !bid) continue;
      const b = store.bonds.get(bid) || { key: bid, name: bondOf(bid)?.name || bid, dmg: 0 };
      b.dmg += dmg;                          // 多个盟约共享同一份伤害（与盟约计层口径一致）
      store.bonds.set(bid, b);
    }
  }
}

/** 当前快照（按伤害降序）。面板每次打开/每场结束重新取一次即可。 */
export function dpsSnapshot() {
  const byDmg = (a, b) => b.dmg - a.dmg;
  return {
    rounds: store.rounds,
    ops: [...store.ops.values()].sort(byDmg),
    bonds: [...store.bonds.values()].sort(byDmg),
  };
}
