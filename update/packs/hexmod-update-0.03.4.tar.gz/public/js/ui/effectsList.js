// Active effects list (m.private.effects: band / 机变 / team / item / garrison effects with counters):
// compact icon column at the right edge, rich-text tooltip per effect. `counterText` (a 悬赏's "还剩 N 场作战", user
// playtest #6 item 4) replaces the bare counter in the tooltip's kind line.

import { html, Tooltip, MicroLabel } from './components.js';
import { useEffect, useState } from '../../vendor/hooks.module.js';
import { dpsSnapshot } from './dpsStats.js';
import { Img, RichText, GIcon } from './gameComponents.js';
import { effectIconUrl } from './assetUrls.js';
import { data } from '../data.js';
import { t, tName, N_ } from '../../../shared/i18n.js';
import { sentText } from './lang.js';

const KIND = { band: N_('策略'), choice: N_('机变'), team: N_('团队增益'), item: N_('道具'), garrison: N_('特质'), hex: N_('海克斯') };

/**
 * A 悬赏's counter line in the current language: the battles its enemies still come for (server/match/player/views.js
 * sends the same Chinese text as `counterText` beside the count; a multi-round card has no count).
 * @param {{ counter?: number|null }} e
 */
export const bountyCounterText = (e) => (e.counter == null ? t('之后的每场作战') : t('还剩 {left} 场作战', { left: e.counter }));

/** Data files whose records an effect entry copies its name / description from (by its id or icon id). */
const SOURCES = ['effects', 'bands', 'items', 'garrisons'];

/**
 * An effect entry's description in the current language (the server copies a record's Chinese text: an effect's, a
 * strategy's, an item's, a 特质's — sentText; a reworded one, such as a multi-round 悬赏's, stays as sent).
 * @param {{ id?: string, iconId?: string, desc?: string }} e
 */
export function effectDesc(e) {
  const desc = e.desc || '';
  if (!desc) return desc;
  for (const file of SOURCES) {
    for (const id of [e.id, e.iconId]) {
      const raw = typeof id === 'string' && id ? data.lookupRaw(file, id) : null;
      if (!raw) continue;
      const loc = data.lookup(file, id) || raw;
      for (const k of ['descRaw', 'desc']) {
        const v = sentText(desc, raw[k], loc[k]);
        if (v !== desc) return v;
      }
    }
  }
  return desc;
}

/** @param {{ effects: any[] }} props */
export function EffectsList({ effects, live = null }) {
  // 「DPS 查看」(this fork, v0.03.3, 用户要求)：海克斯栏顶部的方形按钮，点开在**海克斯栏左侧**列出
  // 干员 / 盟约的伤害排行（数据来自 dpsStats：每场战斗结果的 unitStats 累加）。
  const [dps, setDps] = useState(false);
  // 实时读数 (v0.03.3)：面板打开时每 0.5 秒向战斗运行器取一次「场上单位累计伤害 + 战斗时长」
  const [liveData, setLiveData] = useState(null);
  useEffect(() => {
    if (!dps || typeof live !== 'function') { setLiveData(null); return undefined; }
    let alive = true;
    const tick = () => { if (!alive) return; try { setLiveData(live() || null); } catch { setLiveData(null); } };
    tick();
    const id = setInterval(tick, 500);
    return () => { alive = false; clearInterval(id); };
  }, [dps, live]);
  const snap = dps ? dpsSnapshot() : null;
  // 数值一律用 k 为单位（1k = 1000）：≥1000 显示 x.xk，小于 1000 原样取整
  const fmt = (n) => {
    const v = Number(n) || 0;
    if (v >= 1e6) return `${(v / 1e6).toFixed(2)}m`;
    if (v >= 1e3) return `${(v / 1e3).toFixed(1)}k`;
    return String(Math.round(v));
  };
  const table = (rows, empty) => (rows.length
    ? html`<table class="dpspanel__t"><tbody>${rows.slice(0, 12).map((r, i) => html`<tr key=${r.key}>
        <td class="num">${i + 1}</td><td class="dpspanel__n">${r.name}</td><td class="num">${fmt(r.dmg)}</td></tr>`)}</tbody></table>`
    : html`<p class="dpspanel__empty">${empty}</p>`);
  // 实时排行：DPS = 本场累计伤害 ÷ 战斗时长（gt）；名字按干员记录，召唤物/装置加后缀
  const liveRows = (() => {
    const d = liveData && Array.isArray(liveData.units) ? liveData.units : null;
    if (!d || !d.length) return null;
    const sec = Math.max(0.1, Number(liveData.gt) || 0);
    return d.filter((u) => (Number(u.dmg) || 0) > 0).map((u) => {
      const rec = u.defId ? (data.lookup('chess', u.defId) || {}) : {};
      const suffix = u.kind && u.kind !== 'op' ? (u.kind === 'device' ? '（装置）' : '（召唤物）') : '';
      return { key: `${u.uid ?? u.id ?? u.defId}`, name: `${rec.name || u.defId || t('未知单位')}${suffix}`, dmg: Number(u.dmg) || 0, dps: (Number(u.dmg) || 0) / sec };
    }).sort((a, b) => b.dps - a.dps);
  })();
  const panel = dps ? html`<aside class="dpspanel" role="dialog" aria-label=${t('DPS 查看')}>
    <div class="dpspanel__hd">${t('DPS 查看')}<span class="dpspanel__rounds num">${liveData ? t('本场已进行 {s} 秒', { s: Math.round(Number(liveData.gt) || 0) }) : t('已统计 {n} 场', { n: snap.rounds })}</span></div>
    <p class="dpspanel__warn">${t('测试版出现BUG，及时反馈')}</p>
    <h5>${t('本场实时 DPS')}</h5>
    ${liveRows && liveRows.length
      ? html`<table class="dpspanel__t"><tbody>${liveRows.slice(0, 12).map((r, i) => html`<tr key=${r.key}>
          <td class="num">${i + 1}</td><td class="dpspanel__n">${r.name}</td>
          <td class="num dpspanel__dps">${fmt(r.dps)}</td>
          <td class="num">${fmt(r.dmg)}</td></tr>`)}</tbody></table>
        <p class="dpspanel__legend">${t('DPS · 累计伤害')}</p>`
      : html`<p class="dpspanel__empty">${t('当前没有进行中的战斗（打完一场后会出现在下面的排行）')}</p>`}
    <h5>${t('本局累计 · 干员')}</h5>
    ${table(snap.ops, t('暂无数据（打一场后出现）'))}
    <h5>${t('本局累计 · 盟约')}</h5>
    ${table(snap.bonds, t('暂无数据（打一场后出现）'))}
  </aside>` : null;

  const list = (Array.isArray(effects) ? effects : []).filter((e) => e && (e.name || e.desc));
  if (!list.length) return null;
  const m = data.get('assets');
  return html`<div class="effects" aria-label=${t('生效中的效果')}>
    <${MicroLabel}>EFFECTS</${MicroLabel}>
    <div class="dpshead">
      <button type="button" class=${`speedbtn dpsbtn tapx${dps ? ' is-on' : ''}`} data-testid="dps"
        aria-pressed=${dps ? 'true' : 'false'} title=${t('DPS 查看：干员 / 盟约伤害排行')}
        onClick=${() => setDps(!dps)}><span class="dpsbtn__txt">DPS</span><i class="dpsbtn__beta num">BETA</i></button>
    </div>
    ${panel}
    ${list.slice(0, 10).map((e, i) => html`<${Tooltip} key=${e.id ?? i} placement="bottom" text=${html`<div class="efftip">
        <b>${tName(e.name) || t('效果')}</b><span class="efftip__kind">${t(KIND[e.iconKind] || '')}${e.counterText ? ` · ${bountyCounterText(e)}` : e.counter != null ? ` · ${e.counter}` : ''}</span>
        <${RichText} as="p" text=${effectDesc(e)} />
      </div>`}>
      <span class=${`effect effect--${e.iconKind || 'x'}`}>
        <${Img} src=${effectIconUrl(m, e)} fallback=${html`<${GIcon} name="bolt" />`} />
        ${e.counter != null && e.counter !== '' ? html`<b class="effect__n num">${e.counter}</b>` : null}
      </span>
    <//>`)}
  </div>`;
}
