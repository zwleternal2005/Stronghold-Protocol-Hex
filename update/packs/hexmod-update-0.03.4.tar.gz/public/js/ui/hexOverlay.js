// public/js/ui/hexOverlay.js — 海克斯 (Hex) draft overlay (this fork): the TFT-style "pick 1 of 3 augments" screen,
// shown twice per match — at the start of round 1 and again at round 7 (m.private.hexOfferDraft).
//
// The server decides everything (server/match/match/hexDraft.js): it offers the ids in m.private.hexOffer and records the
// confirmed one with `g.hex { hexId }` → m.private.hex / m.private.hexes. This file only draws the shared/hexes.js
// records, so the client never holds a second copy of the rules.
//
// It reuses the 机变 overlay's CSS (spov / spcard, public/css/screens/game-panels.css) so it looks like the rest of the
// game, but picks on a SINGLE tap like TFT's augment screen. The fork-only rules (the per-card 换 chip, the three 等级
// colours, the easter-egg line) live in public/css/screens/hex.css.
//
// 等级 (grade): every card of one draft shares a grade — 白银 / 黄金 / 炫彩 — and the card is tinted with its colour
// (spcard--silver / --gold / --prismatic). The server picks it once (m.private.hexGrade); this file only paints it.
//
// Co-op extras: a Countdown (m.private.hexDeadline — the server then takes the FIRST card) and, on the FIRST draft only,
// a PER-CARD free reroll (m.private.hexRerolls[slot] → `g.hexReroll { slot }`). The round-7 draft sends no reroll
// budget (hexRerolls = null), so this file draws no 换 chip at all. Dispatch needs no new S2C wiring: hexOffer /
// hexOfferDraft / hex / hexes / hexGrade / hexRerolls / hexDeadline all ride in the m.private frame the client already
// patches into the store.
//
// The card is a <div role="button">, not a <button>: a button may not nest the per-card 换 chip.

import { html, MicroLabel, Countdown } from './components.js';
import { GIcon, Img, RichText } from './gameComponents.js';
import { bondIconUrl } from './assetUrls.js';
import { data } from '../data.js';
import { hexById, HEX_CHOICE_SECONDS, HEX_GRADE_NAME } from '../../../shared/hexes.js';
import { t } from '../../../shared/i18n.js';

const cx = (...p) => p.flat().filter(Boolean).join(' ');

/** 等级 → 卡面配色类（public/css/screens/hex.css）。 */
const GRADE_CLASS = Object.freeze({
  silver: 'spcard--silver',
  gold: 'spcard--gold',
  prismatic: 'spcard--prismatic',
});

/**
 * The recipient's open draft (m.private.hexOffer) as renderable cards, else null.
 * @param {any} priv m.private payload
 * @returns {any[] | null}
 */
export function normalizeHexOffer(priv) {
  const ids = priv && Array.isArray(priv.hexOffer) ? priv.hexOffer : null;
  if (!ids || !ids.length) return null;
  const cards = ids.map((id) => hexById(id)).filter(Boolean);
  return cards.length ? cards : null;
}

/**
 * The recipient's confirmed pick (m.private.hex) as a record, else null.
 * @param {any} priv m.private payload
 */
export function myHex(priv) {
  return priv ? hexById(priv.hex) : null;
}

/**
 * The overlay.
 * @param {{ cards: any[], grade?: string|null, bandId?: string|null, deadline?: number, rerolls?: number[]|null,
 *   draft?: 1|2, busyId?: string|null, rerollSlot?: number|null, picked?: string|null,
 *   onPick: (id: string) => void, onReroll?: (slot: number) => void }} props
 */
export function HexOverlay({ cards, grade = null, bandId = null, deadline = 0, rerolls = null, draft = 1, busyId = null, rerollSlot = null, picked = null, onPick = () => {}, onReroll = () => {} }) {
  if (!Array.isArray(cards) || !cards.length) return null;
  const budgets = Array.isArray(rerolls) ? rerolls : null;
  const free = busyId == null && rerollSlot == null;
  const assets = data.get('assets');
  // the offer's grade (server-authoritative); fall back to the first card's own grade if the field is absent
  const offerGrade = grade || cards[0].grade || null;
  // 副标题：第一次草案说明刷新规则；第二次草案（第 7 回合）说明「不可刷新、不与已选重复」
  const timedTail = deadline > 0 ? t('到时间未选择将自动选取第一项') : t('点击卡牌即可选取');
  const sub = draft >= 2
    ? t('第二次海克斯 · 不会与已选的重复 · 每张同样各有 1 次刷新')
    : (budgets ? t('每张可免费刷新一次') : t('点击卡牌即可选取'));
  return html`<div class="spov" role="dialog" aria-modal="true" aria-label=${t('海克斯')}>
    <div class="spov__veil" aria-hidden="true"></div>
    <div class="spov__inner">
      <header class="spov__head">
        <div class="spov__titles">
          <${MicroLabel} tone="mint">${t('HEX // 海克斯')}</${MicroLabel}>
          <h2 class="spov__title">${draft >= 2 ? t('再次选择一个海克斯') : t('选择一个海克斯')}<span class="spov__bar">|</span><span class="spov__desc">${t('全局增益，本局一直生效')}</span></h2>
          <p class="spov__sub">${offerGrade ? html`<span class=${cx('hexgrade', `hexgrade--${offerGrade}`)}>${t(HEX_GRADE_NAME[offerGrade] || offerGrade)}</span>` : null}${sub} · ${timedTail}</p>
        </div>
        <div class="spov__turn">
          <${Countdown} deadline=${deadline} total=${HEX_CHOICE_SECONDS} size="sm" />
        </div>
      </header>
      <div class="spov__grid spov__grid--3">
        ${cards.map((c, slot) => {
          const busy = busyId != null && busyId === c.id;
          const rerolling = rerollSlot === slot;
          const iconUrl = c.iconBond ? bondIconUrl(assets, c.iconBond) : null;
          const left = budgets ? (Number(budgets[slot]) || 0) : 0;
          const tags = Array.isArray(c.tags) ? c.tags : (c.tag ? [c.tag] : []);
          const cardGrade = c.grade || offerGrade;
          // 彩蛋：仅当玩家的策略(角色)正是该海克斯指定的 role 时才显示（坎诺特 × 奸商本色）
          const egg = c.easterEgg && bandId && c.easterEgg.band === bandId ? c.easterEgg.text : null;
          return html`<div key=${c.id} role="button" tabindex=${free ? 0 : -1}
              class=${cx('spcard', 'spcard--tactic', cardGrade && GRADE_CLASS[cardGrade], free && 'is-pickable', busy && 'is-busy', rerolling && 'is-busy',
                !free && 'is-locked', budgets && 'has-reroll', picked && picked === c.id && 'is-selfpick')}
              aria-disabled=${free ? undefined : 'true'}
              aria-label=${`${t(c.name)}，${t(c.desc)}`} title=${`${t(c.name)}\n${t(c.desc)}`}
              onClick=${() => free && onPick(c.id)}
              onKeyDown=${(e) => { if (free && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); onPick(c.id); } }}>
            <span class="spcard__glow" aria-hidden="true"></span>
            <span class="spcard__head">
              <span class="spcard__icon">
                ${iconUrl
                  ? html`<${Img} src=${iconUrl} fallback=${html`<${GIcon} name=${c.icon || 'bolt'} />`} />`
                  : html`<${GIcon} name=${c.icon || 'bolt'} />`}
              </span>
              <span class="spcard__title">
                <b class="spcard__name">${t(c.name)}</b>
                ${picked && picked === c.id ? html`<span class="spcard__selfpick">${t('自选')}</span>` : null}
                <span class="spcard__tags">
                  ${cardGrade ? html`<span class=${cx('spcard__tag', 'spcard__grade', `spcard__grade--${cardGrade}`)}>${t(HEX_GRADE_NAME[cardGrade] || cardGrade)}</span>` : null}
                  ${tags.map((tag) => html`<span key=${tag} class="spcard__tag">${t(tag)}</span>`)}
                </span>
              </span>
            </span>
            <${RichText} text=${t(c.desc)} class="spcard__desc" />
            ${egg ? html`<span class="spcard__egg">${t(egg)}</span>` : null}
            ${budgets ? html`<button type="button" class="spcard__reroll"
                disabled=${!free || left <= 0}
                aria-label=${t('免费刷新「{name}」（剩余 {n} 次）', { name: t(c.name), n: left })}
                title=${t('免费刷新这张（剩余 {n} 次）', { n: left })}
                onClick=${(e) => { e.stopPropagation(); if (free && left > 0) onReroll(slot); }}>${t('换')}</button>` : null}
            ${busy ? html`<span class="spcard__busy" role="status">${t('选择中')}</span>` : null}
          </div>`;
        })}
      </div>
    </div>
  </div>`;
}
