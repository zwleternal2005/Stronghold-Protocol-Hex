// server/match/player/economy.js — PlayerState methods: the economy — funds, spending (onSpend), prep-side bond layer
// gains (clamped by layerGainRoom), the shop (onPrice prices, copy-weighted rolls from the shared pool plus the player's
// own 自选 stock — player/diy.js —, freeze) and its intents: g.buy, g.refresh, g.freeze, g.levelUp, g.sell.
// Installed on PlayerState.prototype by server/match/PlayerState.js (a method container: never instantiated; `this` is
// the player state).

import { ERR, PHASE, layerGainRoom, BOND_SHOP_BIAS_CHANCE, SLOT_BUY_PRICES, DEPLOY_CAP_MAX } from '../../../shared/constants.js';
import { behaviourIsDefault } from '../../../shared/behaviour.js';
import { freeSlot } from '../board.js';
import { bondBiasPreference } from '../pool.js';
import { OK, fail } from './common.js';

/**
 * **行为开关 `shopBias` 的读取点**（DESIGN §28.43.1）：这一局的声明要不要偏向，要偏就给出「偏向哪些盟约」。
 *
 * 返回 `null` = **引擎今天的行为**，也就是两条路：没声明这一格 / 声明成 `official`（缺省档），或声明了
 * `bondBias` 但此刻一个盟约都没激活（空集合 ⇒ 抽出来的商店会变成空的装备槽，那不是「偏向」，是「停发」）。
 * 返回非空 `Set` = 只在「`giveBondId` 落在这个集合里」的装备里抽，**只偏置、不授予**。
 *
 * `behaviourIsDefault` 是这一格唯一的判据来源（`shared/behaviour.js`）：与 `variants` 的 `variantIsDefault`
 * 同一个分工 —— `behaviourActions` 里那条 `{ kind: 'shop.biasActiveBonds', value: true }` 是这一格的**声明**，
 * 读取点问的是「哪一档」。写成模块层的**纯**函数，是为了让它能被单测（`test/shopBias.test.js`）也为了它是
 * `shared/modSurface.js` 里 `behaviour` 那一格可锚的一个导出名（改名 / 挪走 = 打断所有声明这一格的包）。
 *
 * @param {{ m: { behaviour: any }, _activeBondIds: () => Set<string> }} ps
 * @returns {Set<string>|null}
 */
export function bondBiasBonds(ps) {
  if (behaviourIsDefault(ps.m.behaviour, 'shopBias')) return null;
  const active = ps._activeBondIds();
  return active.size ? active : null;
}

export class PlayerEconomy {
  addFunds(n, { reason = '' } = {}) {
    if (!Number.isFinite(n) || n === 0) return 0;
    const v = Math.trunc(n);
    const before = this.funds;
    this.funds = Math.max(0, this.funds + v);
    if (v > 0) this.stats.fundsGained += v;
    this.dirty();
    return this.funds - before;
  }

  spend(n) {
    const v = Number.isFinite(n) ? Math.max(0, Math.trunc(n)) : 0;
    if (v > this.funds) return false;
    this.funds -= v;
    this.stats.gold += v;
    this.round.spent += v;
    this.dirty();
    return true;
  }

  /** onSpend, dispatched once a payment's action is complete (buy / refresh / levelUp / reward / effect). */
  _afterSpend(amount, reason) {
    if (!(amount > 0)) return;
    this.m.dispatch(this, 'onSpend', { amount, reason, total: this.stats.gold });
  }

  /**
   * Bond layer gain (prep-side). `requireActive` = "使已激活的【X】层数+N". Returns layers added: at most the room left
   * under BOND_LAYER_CAP (999, shared/constants.js) — a gain at the cap adds 0 and dispatches nothing.
   */
  addLayers(bondId, n, { requireActive = false, reason = '' } = {}) {
    if (!this.gd.bond(bondId) || !Number.isFinite(n) || n <= 0) return 0;
    if (requireActive && !(this.bonds[bondId] && this.bonds[bondId].active)) return 0;
    const before = this.layers[bondId] || 0;
    // 对局选项 (this fork): bondLayerUncap lifts the official 999 cap for this match (Match.layerCap);
    // 海克斯 核心盟约 (this fork): 层数最多的激活盟约获得层数时 50% 概率再 +1（额外 1 层并进同一次 room 计算）
    const bonus = this.m.hexCoreBondExtra(this, bondId, before);
    const add = layerGainRoom(before, Math.floor(n) + (bonus > 0 ? bonus : 0), this.m.layerCap());
    if (add <= 0) return 0;
    this.layers[bondId] = before + add;
    this.recompute();
    if (bonus > 0) this.m.toast(this, 'info', `核心盟约 · ${this.gd.bond(bondId)?.name || bondId} 额外获得 1 层`);
    // A live prep gain, not a view delta: reconnects and combat-result backfill must not replay the cue.
    if ([PHASE.ROUND_START, PHASE.SP_DRAFT, PHASE.PREP].includes(this.m.phase)) {
      this.m.sendTo(this.playerId, { t: 'm.layer', playerId: this.playerId, bondId, add });
    }
    this.m.dispatch(this, 'onLayers', { bondId, from: before, to: before + add, reason });
    return add;
  }

  /** Effective price of a shop slot after onPrice modifiers (never negative). */
  priceOf(slot) {
    if (!slot) return 0;
    const ev = { slot, kind: slot.kind, id: slot.id, price: slot.basePrice };
    this.m.dispatch(this, 'onPrice', ev, { quiet: true });
    const p = Number(ev.price);
    return Number.isFinite(p) ? Math.max(0, Math.round(p)) : slot.basePrice;
  }

  _rollChessSlot() {
    // 对局选项 · 盟约定向刷新 (this fork): with the room flag on, each chess slot has a BOND_SHOP_BIAS_CHANCE chance to
    // draw straight from the ACTIVE bonds (the bond weighted by its layers, the operator by its remaining copies — tier
    // gate respected). Off (or nothing eligible) → the plain copy-weighted roll, untouched rng consumption.
    if (this.m.flags && this.m.flags.bondShopBias && this.m.rngShop() < BOND_SHOP_BIAS_CHANCE) {
      const id = this._rollBondBias();
      if (id) return { kind: 'chess', id, basePrice: this.gd.chessPrice(id), frozen: false, sold: false };
    }
    // the slotted 自选 pieces join the draw once the 调度中心 reaches their slot's level (player/diy.js diyRollEntries);
    // the DRAW SOURCE is the player's own pool in the 100-seat variant and the shared one today (player/rules.js
    // mainPool — the same object either way when the switch is off, docs/PS100-MIGRATION.md §10-A)
    const id = this.mainPool().roll(this.m.rngShop, { maxTier: this.shop.level, extra: this.diyRollEntries() });
    if (!id) return null;
    // 助战：自己带上场的干员在商店里按 `data/support.json` 的 prices 标价（没配就是它的阶级价），
    // 卖掉仍按普通棋子的 sellPrice —— 它就是普通棋子，只是「我的商店池里一定有它」（连本局禁用也盖过去）。
    // 阶级门照旧：六阶助战仍要商店等级 6 才摇得到。
    const support = this.support.includes(id);
    const price = support ? (this.gd.supportPrice(id) ?? this.gd.chessPrice(id)) : this.gd.chessPrice(id);
    return { kind: 'chess', id, basePrice: price, frozen: false, sold: false, ...(support ? { support: true } : {}) };
  }

  /**
   * 这个玩家**已激活**盟约的 id 集合（`recompute` 算出来的 `this.bonds`）—— `shopBias: "bondBias"` 的唯一输入。
   * 缓存按 `this.bonds` 的**对象身份**失效：每一次 `recompute()` 都换一个新对象（`player/round.js`），于是同一个
   * prep 里的多次刷新只付一次遍历，而变化之后一定重算。
   * @returns {Set<string>}
   */
  _activeBondIds() {
    if (this._biasBondsAt === this.bonds && this._biasBonds) return this._biasBonds;
    const out = new Set();
    for (const [id, state] of Object.entries(this.bonds || {})) if (state && state.active) out.add(id);
    this._biasBondsAt = this.bonds;
    this._biasBonds = out;
    return out;
  }

  /**
   * **执行点（`shopBias`）**：这一局的声明要不要偏向，要偏就给出「偏向哪些盟约」。
   *
   * 判据本体是模块层的 `bondBiasBonds`（纯函数，`shared/modSurface.js` 的 `behaviour` 那一格锚着它）；这里只把
   * 这一格的读取点挂到玩家状态上，`_rollItemSlot` 与本文件以外的调用方都走这一个名字。
   * @returns {Set<string>|null}
   */
  shopBiasBonds() {
    return bondBiasBonds(this);
  }

  /**
   * 对局选项 · 盟约定向刷新 (this fork) 的定向抽卡：按「已激活盟约的当前层数」加权挑一个盟约，再在该盟约的、
   * 调度中心层级内还有副本的干员里按剩余副本数加权抽一个（pool.roll 的 copy 权重原样复用）。
   * 「最高层数」= 层数越高的盟约被抽中的份额越大。没有可抽的（该盟约干员售罄 / 层级不符）→ null，回退普通抽卡。
   * @returns {string|null} base chess id
   */
  _rollBondBias() {
    const weighted = [];
    let total = 0;
    for (const [id, b] of Object.entries(this.bonds || {})) {
      if (!b || !b.active) continue;
      const w = Math.max(0, Math.trunc(Number(this.layers[id] ?? b.layers) || 0));
      if (w <= 0) continue;
      weighted.push([id, w]);
      total += w;
    }
    if (!(total > 0)) return null;
    let r = this.m.rngShop() * total;
    let pick = weighted[weighted.length - 1][0];
    for (const [id, w] of weighted) { r -= w; if (r < 0) { pick = id; break; } }
    return this.m.pool.roll(this.m.rngShop, {
      maxTier: this.shop.level,
      extra: this.diyRollEntries(),
      filter: (cid) => { const rec = this.gd.chess(cid); return !!rec && Array.isArray(rec.bonds) && rec.bonds.includes(pick); },
    }) || null;
  }

  _rollItemSlot() {
    // 行为开关 `shopBias`（DESIGN §28.43.1）：只有这一局的声明把那一格选成 `bondBias` 时，装备槽才拿这条
    // 偏向谓词去缩候选集。`shopBiasBonds()` 在缺省档返回 null ⇒ 这一行与从前**同一份结果**、同一条代码路径。
    const bonds = this.shopBiasBonds();
    const restrict = bonds ? bondBiasPreference(this.gd, bonds) : null;
    const id = this.m.pool.rollItem(this.m.rngShop, this.shop.level, this.m.itemPool, restrict);
    return id ? { kind: 'item', id, basePrice: this.gd.itemPrice(id), frozen: false, sold: false } : null;
  }

  /**
   * Reroll the shop. keepFrozen → frozen unsold slots survive (round start); otherwise everything is rerolled
   * (manual refresh). Slot counts follow the current level.
   */
  rollShop({ keepFrozen = false } = {}) {
    const { chess: nChess, item: nItem } = this.gd.shopSlots(this.shop.level);
    const old = this.shop.slots;
    const layout = this.shop.layout || { chess: old.length, item: 0 };
    const oldChess = old.slice(0, layout.chess);
    const oldItems = old.slice(layout.chess);
    const keep = (s, kind) => (keepFrozen && s && s.kind === kind && !s.sold && s.frozen ? { ...s } : null);
    // frozen slots keep their position; sold / empty / unfrozen positions are rerolled
    const slots = [];
    for (let i = 0; i < nChess; i++) slots.push(keep(oldChess[i], 'chess') ?? this._rollChessSlot());
    for (let i = 0; i < nItem; i++) slots.push(keep(oldItems[i], 'item') ?? this._rollItemSlot());
    this.shop.slots = slots;
    this.shop.layout = { chess: nChess, item: nItem };
    for (const s of slots) if (s) s.frozen = this.shop.frozen;
    // 海克斯 天降盟约 (this fork): 每次刷新牌库（手动 refresh / 回合开始）都会出现一个礼物盟约的干员
    this.m.hexSeedGiftBond(this);
    this.dirty();
  }

  /**
   * The 调度中心's upgrade opens the new level's extra slots — as EMPTY slots.
   *
   * The owner's decision of 2026-10-07, report 「升级2本会刷新干员池和加入新干员，升级商店等级加槽位应该是只多一个空位而不是直接多
   * 一个可购买干员」: an upgrade buys a PLACE for a card, not a card. The extra slots appear empty and the next roll fills
   * them — a manual 刷新 (rollShop) or the round start's own roll (round.js startRound).
   *
   * Upstream 0.2.0 drew a card in at once (§25.19.2, community report item 19 「升级商店获得新的商店位时用新卡补上，而不是空着」,
   * citing the tutorial's 「升级：…升级后将出现更多的商品栏位、可调度干员以及新装备」). That hands the player a free card the
   * shop never rolled — from level 2 on, a NEW operator to buy on the spot — which is exactly what the owner reports as
   * wrong; the tutorial line only promises that more slots appear. 0.2.2 reached the same conclusion on its own: the
   * footage of a 1→2 upgrade (bilibili BV1AXwuzdEys 1:39, GitHub #332 / PR #333 by @2321Robin) shows the new slot appear
   * and stay empty, and the texts only name the slots — the tutorial's 休整期 page 「升级后将出现更多的商品栏位」, PRTS 帮助
   * 「增加刷新栏位」 — never a card that comes with them. The cards already shown stay where they are (chess slots keep
   * their index, the item slot stays after them).
   */
  _openLevelSlots() {
    const { chess: nChess, item: nItem } = this.gd.shopSlots(this.shop.level);
    const old = this.shop.slots;
    const layout = this.shop.layout || { chess: old.length, item: 0 };
    if (nChess <= layout.chess && nItem <= layout.item) return;
    const chess = old.slice(0, layout.chess);
    const items = old.slice(layout.chess);
    while (chess.length < nChess) chess.push(null);   // empty: the next roll draws into it
    while (items.length < nItem) items.push(null);
    this.shop.slots = [...chess, ...items];
    this.shop.layout = { chess: chess.length, item: items.length };
  }

  /** Combat start: unfrozen slots are emptied (research 01 A1). */
  clearUnfrozenShop() {
    this.shop.slots = this.shop.slots.map((s) => (s && s.frozen && !s.sold ? s : null));
    this.dirty();
  }

  /**
   * g.buy {slot}. A full regular hand refuses every purchase, also one whose copy would complete a merge at once (PRTS
   * 卫戍协议/帮助 §手牌区 "当常规手牌区全满无空位时，玩家将无法执行使手牌溢出的操作" — "例如招募/购入等通常情况下会增加手牌的
   * 操作"; BWIKI 盟约 "当整备区达到上限后将无法进行涉及到整备区的操作（购买、撤回等）"; GitHub #82: the reporter's first-hand
   * check in the official game, "哪怕是已经有了两个相同干员情况"). Until 0.1.3 such a purchase was let through.
   */
  buy(slotIdx) {
    const g = this._gate(); if (g) return g;
    if (!Number.isInteger(slotIdx) || slotIdx < 0 || slotIdx >= this.shop.slots.length) return fail(ERR.BAD_TARGET);
    const slot = this.shop.slots[slotIdx];
    if (!slot) return fail(ERR.BAD_TARGET);
    if (slot.sold) return fail(ERR.SOLD_OUT);
    const price = this.priceOf(slot);
    if (this.funds < price) return fail(ERR.NO_FUNDS);
    const handFull = freeSlot(this.hand) < 0;
    let piece;
    if (slot.kind === 'chess') {
      const rec = this.gd.chess(slot.id);
      // a DIY slot sells only as this player's own 自选 piece (a slotted slot's record carries `diyFor`)
      if (!rec || (rec.isDiy && !rec.diyFor)) return fail(ERR.BAD_TARGET);
      // Already displayed operators stay purchasable after stock runs out (#498; 路标月报#2,
      // BV1eLXXBqEgF 2:50–2:57: nine owned + four shop offers => thirteen owned).
      // acquireChess records every copy, including the deficit; future rolls still exclude empty stock.
      if (handFull) return fail(ERR.HAND_FULL);
      this.spend(price);
      slot.sold = true;
      piece = this.acquireChess(slot.id, { source: 'buy' });
    } else {
      if (!this.gd.item(slot.id)) return fail(ERR.BAD_TARGET);
      if (!this.m.itemPool.canGain(slot.id)) return fail(ERR.SOLD_OUT);
      if (handFull) return fail(ERR.HAND_FULL);
      this.spend(price);
      slot.sold = true;
      piece = this.acquireItem(slot.id, { source: 'buy' });
    }
    this.stats.buys++;
    this.round.buys++;
    if (slot.kind === 'chess') {
      // 休养生息 (this fork) 的「买过干员」标记（endPrep 结算）+ 勤俭持家的每回合首次购买经验
      this.roundBoughtChess = true;
      if (!this._thriftUsed) {
        const xp = this.m.hexFirstBuyXp(this);
        if (xp > 0) {
          this._thriftUsed = true;
          this.shop.upgradePrice = Math.max(0, this.shop.upgradePrice - xp);
          this.m.toast(this, 'info', `勤俭持家 · 获得 ${xp} 经验`);
        }
      }
      // 财团 (this fork, 盟约专属·投资人炫彩)：购买干员返还其费用的 30%（向下取整、至少 1 资金）
      const refund = this.m.hexPurchaseRefund(this, price);
      if (refund > 0) {
        const got = this.addFunds(refund, { reason: 'hex' });
        this.m.toast(this, 'info', `财团 · 购买返还 ${got} 资金`);
      }
    }
    this.m.dispatch(this, 'onBuy', { piece, slot, price, kind: slot.kind });
    this._afterSpend(price, 'buy');
    this.recompute();
    return OK;
  }

  refresh() {
    const g = this._gate(); if (g) return g;
    const free = this.shop.freeRefreshes > 0;
    const price = free ? 0 : this.gd.refreshPrice;
    if (!free && this.funds < price) return fail(ERR.NO_FUNDS);
    if (free) this.shop.freeRefreshes--;
    else this.spend(price);
    this.rollShop({ keepFrozen: false });
    this.stats.refreshes++;
    this.round.refreshes++;
    // 休养生息 (this fork) 的「刷新过商店」标记（endPrep 结算）
    this.roundRefreshed = true;
    this.m.dispatch(this, 'onRefresh', { slots: this.shop.slots, free, price });
    this._afterSpend(price, 'refresh');
    // 海克斯 门票（白银/黄金/炫彩）: 按全局刷新计数或概率追加免费刷新（MatchHexDraft.hexOnRefresh）
    this.m.hexOnRefresh(this);
    this.dirty();
    return OK;
  }

  freeze() {
    const g = this._gate(); if (g) return g;
    this.shop.frozen = !this.shop.frozen;
    for (const s of this.shop.slots) if (s && !s.sold) s.frozen = this.shop.frozen;
    this.dirty();
    return OK;
  }

  levelUp() {
    const g = this._gate(); if (g) return g;
    if (this.shop.level >= this.gd.maxShopLevel) return fail(ERR.MAX_LEVEL);
    const price = Math.max(0, this.shop.upgradePrice);
    if (this.funds < price) return fail(ERR.NO_FUNDS);
    this.spend(price);
    this.shop.level++;
    this.shop.upgradePrice = this.gd.upgradeBase(this.shop.level) ?? 0;
    this._openLevelSlots();
    this.m.tickerFor('SHOP_LEVEL', [this.name, String(this.shop.level)], { playerId: this.playerId, param: String(this.shop.level) });
    this.m.dispatch(this, 'onLevelUp', { level: this.shop.level, price });
    this._afterSpend(price, 'levelUp');
    this.dirty();
    return OK;
  }

  /**
   * 额外上阵栏位 (this fork, 房间旗子 `buySlot`)：准备阶段花 25 / 50 / 75 资金买下第 1 / 2 / 3 个上阵位
   * （`deployCapBonus +1`，天花板仍是 DEPLOY_CAP_MAX）。房间没开这个开关时整条路径关闭（与「意图不存在」等价）。
   */
  buySlot() {
    const g = this._gate(); if (g) return g;
    if (!this.m.flags || !this.m.flags.buySlot) return fail(ERR.BAD_MSG, 'slot purchase is off in this room');
    const n = Number.isInteger(this.slotBuys) ? this.slotBuys : 0;
    if (n >= SLOT_BUY_PRICES.length) return fail(ERR.BAD_TARGET, 'all extra slots bought');
    if (this.deployCap >= DEPLOY_CAP_MAX) return fail(ERR.BAD_TARGET, 'deploy cap reached');
    const price = SLOT_BUY_PRICES[n];
    if (this.funds < price) return fail(ERR.NO_FUNDS);
    this.spend(price);
    this.slotBuys = n + 1;
    // `deployCap` = max(基础 + bonus, deployCapMin)。人事部文档把下限抬到 9 时，基础 8 + bonus 1 仍是 9 —— 
    // 只加 bonus 会被下限吃掉：花了 25 资金、栏位不变。哪一项在决定上限，就把 +1 加在哪一项上。
    if (this.deployCapMin > this.gd.deployCap + this.deployCapBonus) {
      this.deployCapMin = Math.min(DEPLOY_CAP_MAX, this.deployCapMin + 1);
    } else {
      this.deployCapBonus += 1;
    }
    this.m.toast(this, 'info', `额外上阵栏位 +1 · 花费 ${price} 资金（已购 ${this.slotBuys}/${SLOT_BUY_PRICES.length}）`);
    this.m.dispatch(this, 'onSpend', { amount: price, reason: 'buySlot', total: this.stats.gold });
    this.recompute();
    this.dirty();
    return OK;
  }

  sell(uid) {
    const g = this._gate(); if (g) return g;
    const loc = this.find(uid);
    if (!loc) return fail(ERR.BAD_TARGET);
    if (loc.piece.kind !== 'chess') return fail(ERR.BAD_TARGET, loc.piece.kind === 'item' ? 'items cannot be sold' : 'tokens cannot be sold');
    const piece = loc.piece;
    // its equipment returns to the hand (overflow temp): refuse rather than destroy it when there is no room
    // Removing the owner's summon stacks frees one slot per stack, regardless of its summon count.
    const freed = (x) => x == null || (x.kind === 'token' && x.ownerUid === piece.uid);
    const room = this.hand.filter(freed).length + this.temp.filter(freed).length + (loc.area === 'hand' || loc.area === 'temp' ? 1 : 0);
    if ((piece.items || []).length > room) return fail(ERR.HAND_FULL, 'no room for the equipment');
    this._detach(loc);
    this.removeTokensOf(piece.uid);
    for (const it of piece.items || []) {
      if (!this.stow(it, { allowTemp: true })) this.m.log.warn?.(`[match ${this.m.roomCode}] ${this.playerId}: item ${it.id} lost on sell (no space)`);
    }
    piece.items = [];
    this.returnCopies(piece);
    const ev = { piece, gain: this.gd.sellPrice(piece.id) };
    this.m.dispatch(this, 'onSold', ev);
    const gain = Number.isFinite(ev.gain) ? Math.max(0, Math.trunc(ev.gain)) : 1;
    this.addFunds(gain, { reason: 'sell' });
    this.stats.sells++;
    this.round.sells++;
    this.checkItemMerges();
    this.recompute();
    return OK;
  }
}
