// server/match/player/round.js — PlayerState methods: the round lifecycle the match calls — startRound (income, pending
// coins, the shop, summon stacks topped up), endPrep, eliminate (every copy back to the pool), recompute (legality,
// out-of-range summons, temp pieces into free hand slots, bonds), the bond views — and battleInput (the player's
// PlayerBattleInput: board units with their loadout, their 补位 mark or their 自选 pick, carried 联防 state, the reached
// layers).
// Installed on PlayerState.prototype by server/match/PlayerState.js (a method container: never instantiated; `this` is
// the player state).

import { boardOrder, pieceDir } from '../board.js';

/**
 * 测试工具 (this fork, 仅作者账号 zwl)：无敌倍率——debugGod 玩家的干员在战斗规格里拿到巨额生命与攻击，
 * 走与对局选项完全相同的 buffs 通道（spec.players[].buffs → sim units.js matchMul），服务器侧生效。
 * @param {{ hpMul?: number, atkMul?: number, defMul?: number, resMul?: number, aspdFlat?: number, academy?: object } | null} base
 */
function debugGodBuffs(base) {
  const g = base ? { ...base } : { hpMul: 1, atkMul: 1, defMul: 1, resMul: 1, aspdFlat: 0 };
  g.hpMul = (Number(g.hpMul) || 1) * 1000;
  g.atkMul = (Number(g.atkMul) || 1) * 30;
  g.aspdFlat = (Number(g.aspdFlat) || 0) + 200;
  return g;
}
import { computeBonds, bondSnapshot, activatedLayers, bondsWithGains } from '../bondsMeta.js';

export class PlayerRound {
  startRound(r) {
    this.round = { refreshes: 0, buys: 0, sells: 0, spent: 0, gainedChess: 0, arts: 0 };
    this.pendingLayerGains = null; // settled (or lapsed) at the last SETTLE
    // 休养生息 / 勤俭持家 (this fork) 的「本回合是否买过干员 / 刷新过商店」标记（PlayerEconomy.buy / refresh 写）
    this.roundBoughtChess = false;
    this.roundRefreshed = false;
    this._thriftUsed = false;
    if (r > 1) this.shop.upgradePrice = Math.max(0, this.shop.upgradePrice - 1);
    // 海克斯 休养生息 (this fork): 上个休整期结束时存下的奖励（没买干员 → 资金；没刷新 → 经验）
    const frugal = this._frugalPending;
    this._frugalPending = null;
    if (frugal && frugal.funds > 0) this.addFunds(frugal.funds, { reason: 'hex' });
    if (frugal && frugal.xp > 0) {
      this.shop.upgradePrice = Math.max(0, this.shop.upgradePrice - frugal.xp);
      this.m.toast(this, 'info', `休养生息 · 获得 ${frugal.funds > 0 ? `${frugal.funds} 资金、` : ''}${frugal.xp} 经验`);
    } else if (frugal && frugal.funds > 0) {
      this.m.toast(this, 'info', `休养生息 · 获得 ${frugal.funds} 资金`);
    }
    // 家族账本 (this fork, 盟约专属·叙拉古黄金)：本局累计击杀每满 12 名 → 3 资金（跨回合循环；回合开始结算）
    this.m.hexKillMilestone(this);
    // 黑手帝国 (this fork, 盟约专属·叙拉古炫彩)：上回合击杀数 ÷ 2 的资金（向下取整、至多 6）
    if (this.hexes.includes('bx_siracusa_empire')) {
      const total = Math.trunc(this.stats.kills) || 0;
      const mark = Number.isInteger(this.empireKillMark) ? this.empireKillMark : total;
      const last = Math.max(0, total - mark);
      this.empireKillMark = total;
      const f = Math.min(6, Math.floor(last / 2));
      if (f > 0) {
        const got = this.addFunds(f, { reason: 'hex' });
        this.m.toast(this, 'info', '黑手帝国 · 获得 {n} 资金'.replace('{n}', got));
      }
    }
    // onIncome handlers may rewrite ev.income / ev.pending (e.g. 老鲤 withholds R1–R2 income until R3)
    const ev = { round: r, income: this.gd.income(r), pending: this.pendingFunds };
    this.pendingFunds = 0;
    this.m.dispatch(this, 'onIncome', ev);
    const nonNeg = (v) => (Number.isFinite(v) && v > 0 ? Math.trunc(v) : 0);
    // 海克斯 奸商本色 的利息（MatchHexDraft.hexIncomeOf）：持仓＝上回合末保留下来的剩余资金，所以必须在 addFunds
    // 之前求值。此时坎诺特自带的 coin_carry_over 已经让位（sim/content/bands/meta.js 判 incomeInterest），不重复算。
    const hexIncome = nonNeg(this.m.hexIncomeOf(this));
    // 「本局海克斯详情」统计 (v0.03.3)：奸商本色的利息收入
    if (hexIncome > 0 && typeof this.m.hexStatAdd === 'function' && this.m.hexPicks(this).includes('devil_merchant')) {
      this.m.hexStatAdd(this, 'devil_merchant', { funds: hexIncome, count: 1 });
    }
    this.addFunds(nonNeg(ev.income) + nonNeg(ev.pending) + hexIncome, { reason: 'income' });
    // temp is NOT wiped here: the last prep's deadline resolved what the player could act on (endPrep); what overflowed
    // after it (battle-result grants, SETTLE merges, returned equipment) is shown and usable in this prep (tempDue).
    // Likewise reward offers of the last prep already expired at its end; what is still queued was earned after it —
    // a merge completed during SETTLE / the Final Assault (突变细胞, battle-result grants) — and is shown in this prep
    this.ready = false;
    // summon stacks removed from temp at the last prep deadline come back (PRTS 卫戍协议/帮助 §手牌区); full hand ⇒ temp
    for (const p of [...this.board.values()]) if (p.kind === 'chess') this.grantTokensFor(p);
    this.rollShop({ keepFrozen: true });
    this.shop.frozen = false;
    for (const s of this.shop.slots) if (s) s.frozen = false;
    // 海克斯 DD街区: 每回合开始白送 N 次免费刷新（MatchHexDraft.hexRoundStartFreeRefreshes）
    this.m.hexRoundStartFreeRefreshes(this);
    // 海克斯 天选系列 (this fork): 每回合开始随机发放 1 名该盟约干员（阶数 ≤ 当前调度中心等级）
    this.m.hexRoundStartChess(this);
    // 海克斯 维多利亚的助力 (this fork): 每 3 回合获得一件随机装备（阶数 ≤ 当前调度中心等级）
    this.m.hexRoundStartItem(this);
    this.recompute();
  }

  /**
   * Prep deadline (Match.endPrep, after the <休整期结束时> onPrepEnd effects): the temp pieces due at this prep are
   * resolved; what overflowed after Ready or during onPrepEnd stays for the next prep, which `prepsEnded` now names.
   */
  endPrep() {
    this.resolveTemp();
    this.prepsEnded++;
    for (const uid of [...this._tempDue.keys()]) if (!this.temp.some((p) => p && p.uid === uid)) this._tempDue.delete(uid);
    this.offers = [];
    this.clearUnfrozenShop();
    // 海克斯 奸商本色: 本局回合结束也不清空剩余资金（与 band_cannot 策略同理；MatchHexDraft.hexKeepsFunds）
    // 房间旗子 回合结束保留资金 (this fork, keepFunds；无尽默认开)：同样不清空（Match.roomKeepsFunds）
    if (!this.gd.leftoverKeptBands.includes(this.bandId) && !this.m.hexKeepsFunds(this) && !this.m.roomKeepsFunds()) this.funds = 0;
    // 海克斯 休养生息 (this fork): 本回合没买干员 / 没刷新商店 → 存起下回合发放
    this._frugalPending = this.m.hexFrugalCheck(this);
    this.ready = true;
    this.dirty();
  }

  // `effects` are kept: a 信标 gift still pending is delivered to the teammate at the next round start (builtin_gift is
  // flagged afterElimination — GitHub #86); nothing else of an eliminated player is dispatched.
  eliminate(round) {
    this.alive = false;
    this.ready = false;
    this.eliminatedRound = round;
    const all = [];
    for (const p of this.board.values()) all.push(p);
    for (const p of this.hand) if (p) all.push(p);
    for (const p of this.temp) if (p) all.push(p);
    for (const p of all) this.returnCopies(p);
    this.board.clear();
    this.hand.fill(null);
    this.temp.fill(null);
    this._tempDue.clear();
    this.offers = [];
    this.bounties = [];
    this.personalChoice = null;
    this.hexOffer = null;
    this.hexOfferDraft = 0;
    this.hexGrade = null;
    this.hexRerolls = null;
    this.hexDeadline = 0;
    this.shop.slots = [];
    this.funds = 0;
    this.pendingFunds = 0;
    this.recompute();
  }

  recompute() {
    this.deployMap(); // a change of the deploy field (a boss round's prep) marks the legality stale
    if (this._legalityStale) this._evictIllegal();
    this._liftOutOfRange();
    // a free regular hand slot pulls a temp piece in (PRTS 卫戍协议/帮助 §手牌区 "常规手牌区出现空位时自动移入")
    this._fillHandFromTemp();
    this.bonds = computeBonds(this.gd, this);
    this.dirty();
  }

  activatedLayers() { return activatedLayers(this.bonds); }

  /**
   * The bond states the views show (m.private bonds, m.public players[].bonds): the computed states plus the pending
   * in-battle gains of this round's finished normal battle (bondsMeta.bondsWithGains). The 联防 field fights with them too
   * (battleInput `reached`); no other rule reads them.
   */
  bondsView() { return bondsWithGains(this.bonds, this.pendingLayerGains, this.m.layerCap()); }

  /**
   * `reached`: the bonds carry the layers this round's own combat reached (bondsView: the pending in-battle gains, capped
   * like settle()) — the 联防 field (unite.js; PRTS 卫戍协议/帮助 §联防阶段 "将以其阵地当前的状态", [ASSUMED] the current
   * state includes those layers, as the strip shows them). The gains stay pending: settle() adds them once.
   */
  battleInput({ side = 'L', colOffset = 0, carry = null, reached = false } = {}) {
    // a terrain change not yet followed by a recompute (a content hook at the prep end) never fields an illegal board
    this.deployMap();
    if (this._legalityStale) this.recompute();
    const units = [];
    for (const { r, c, piece } of boardOrder(this.board)) {
      if (piece.kind === 'chess') {
        const u = { uid: piece.uid, kind: 'chess', chessId: piece.id, row: r, col: c, dir: pieceDir(piece), items: (piece.items || []).map((i) => i.id) };
        const pick = this.diyPickOf(piece.id);
        if (pick) {
          // 0.2.0 自选编队: a slotted DIY slot fights as its pick (sim getChess(id, { diy }): the operator's body, the pick's
          // skill and module — no loadout fields, docs/SIM.md §12)
          u.diy = { charId: pick.charId, skillIndex: pick.skillIndex, uniEquipId: pick.uniEquipId };
        } else if (this.fieldsStandIn(piece.id)) {
          // 0.2.0 补位: a chess this player does not own fights as its stand-in (sim getChess(id, { standIn: true }): the
          // backup skill / module — no loadout fields, docs/SIM.md §12)
          u.standIn = true;
        } else {
          // DESIGN §16: the equipped skill / module (elite only) from the loadout (defaults when absent)
          const lo = this.loadoutFor(this.gd.chess(piece.id));
          u.skillIndex = lo.skillIndex;
          u.moduleId = lo.moduleId;
        }
        // 0.2.2: the potential / 练度 of an operator the player owns (the chess as itself, an owned 自选 pick — the player's
        // 干员调配 settings, 潜能 6 / 精英2 Lv.60 by default and for bots; never a stand-in's nor a prototype pick's)
        const cv = u.standIn ? null : this.cultivationFor(this.gd.chess(piece.id));
        if (cv) { u.potential = cv.potential; u.cultivate = cv.cultivate; }
        if (carry && carry.has(piece.uid)) u.carryState = carry.get(piece.uid);
        units.push(u);
      } else if (piece.kind === 'token') {
        const u = { uid: piece.uid, kind: 'token', tokenId: piece.id, row: r, col: c, dir: pieceDir(piece), ownerUid: piece.ownerUid };
        if (carry && carry.has(piece.uid)) u.carryState = carry.get(piece.uid); // 联防: { sp } (unite.js)
        units.push(u);
      }
    }
    return {
      playerId: this.playerId,
      seat: this.seat,
      side,
      colOffset,
      units,
      bonds: bondSnapshot(reached ? this.bondsView() : this.bonds),
      bandId: this.bandId,
      // 对局选项 · 我方增益 (this fork) + 海克斯的干员增益（hexOpsBuffsOf：协防协议按激活盟约数、
      // 宝宝学院的分阶数据、名刀保命后的剩余对局生命加成）—— 全中性时为 null，与旧行为一致
      buffs: this.debugGod ? debugGodBuffs(this.m.hexOpsBuffsOf(this)) : this.m.hexOpsBuffsOf(this),
      playerEffects: this.effects.filter((e) => e.battle !== false).map((e) => ({
        id: e.id, key: e.key ?? null, source: e.iconKind ?? null, params: e.params ?? null, counter: e.counter ?? null, data: e.data ?? null,
      })),
      // 盟约专属海克斯 (this fork, 第六轮征集)：本局已选的海克斯 id 清单进战斗规格 —— 战斗侧内容钩子
      // （support.playerHexIds）据此判定各盟约专属效果（狂猎号角 / 军需官 / 骑士铁律 …）
      hexes: this.hexes.slice(),
      // 黑手帝国 (this fork, 盟约专属)：开战时的累计击杀快照 —— 叙拉古附加真伤的成长读这里
      kills: Math.trunc(this.stats.kills) || 0,
      deviceOverrides: { ...this.deviceOverrides },
    };
  }
}
