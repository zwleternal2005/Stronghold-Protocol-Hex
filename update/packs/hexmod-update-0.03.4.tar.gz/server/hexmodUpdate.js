// server/hexmodUpdate.js — 海克斯模组的「检查更新」（this fork）。
//
// 服务器启动时（之后每 CHECK_INTERVAL_MS）从发布渠道拿「最新版本号」，与本地 HEX_MOD_VERSION 比对，
// 缓存结果。浏览器从标题屏打**同源的** `GET /update-check`（routes.js）拿这份缓存 —— 远端请求只在
// 服务器侧发生，浏览器永远不出跨域请求，也永远不会因为清单地址挂掉而卡进游戏。
//
// 支持两种发布渠道（按 SP_HEX_UPDATE_URL / shared/hexMod.js 默认值的形状自动识别）：
//   1) **夸克网盘分享**（`https://pan.quark.cn/s/<id>`，可带 `?pwd=` 提取码）：匿名走分享接口
//      （token → 列目录，实测可行），**从文件名里提取版本号**（如 `卫戍协议：盟约 海克斯模组 v0.021.zip`），
//      取最大者为最新版；downloadUrl = 分享页本身。发版 = 把新 zip 按同样的命名传进这个分享（任意一层，
//      子目录也会扫），旧版不用删。
//   2) **普通 JSON 清单**（其他任何 URL）：响应体是 `{ "version": "…", "notes": "…", "downloadUrl": "https://…" }`
//      （形状见 shared/hexMod.js parseUpdateManifest）。
//
// 纪律：这条检查**绝不阻塞启动、绝不抛进请求路径**。拉不到 / 解析不了就当「没检查出来」
// （status() 的 checked:false），客户端不画条，游戏照常玩。夸克的接口是未文档化的分享页 API，
// 哪天变了也只是退化为「没检查出来」，普通 JSON 渠道永远可用作后备。

import { HEX_MOD_VERSION, HEX_UPDATE_URL_DEFAULT, parseUpdateManifest, updateCheckView, compareHexVersions } from '../shared/hexMod.js';

/** `GET /update-check` 的唯一路径（routes.js 与 CORE_ROUTE_EXACT 同值）。 */
export const UPDATE_CHECK_URL = '/update-check';
/** 启动后的首次检查也走这个超时：太长会让早期 /update-check 落在 checked:false。 */
const FETCH_TIMEOUT_MS = 8000;
/** 缓存有效期：期间 status() 直接回缓存，到期后下一次 status() 触发后台重查。 */
const CHECK_INTERVAL_MS = 30 * 60_000;

/** 夸克分享链接（可带 ?pwd= 提取码）。 */
export const QUARK_SHARE_RE = /pan\.quark\.cn\/s\/([a-zA-Z0-9]+)/i;
/** 文件名里的版本号（v0.02 / v0.021 / 0.021 …），取**最后一个**命中（文件名后缀版本是惯例）。 */
export const VERSION_IN_NAME_RE = /[vV](\d+(?:\.\d+)+)/;

export const quarkShareId = (url) => QUARK_SHARE_RE.exec(String(url || ''))?.[1] || null;

/**
 * 从文件名提取版本号：取**最后一个** `v?X.Y…` 形状的串（名字里可能多次出现，尾部的才是版本）。
 * 返回点分数字串（如 '0.021'）或 null —— 纯函数，test/hexUpdate.test.js 直接钉。
 * @param {string} name @returns {string|null}
 */
export function versionFromFileName(name) {
  const s = String(name || '');
  const hits = [...s.matchAll(/[vV](\d+(?:\.\d+)+)/g)];
  if (hits.length) return hits[hits.length - 1][1];
  const bare = [...s.matchAll(/(?:^|[\s_（(【-])(\d+\.\d+(?:\.\d+)*)(?=$|[\s_）)】.zip])/g)];
  return bare.length ? bare[bare.length - 1][1] : null;
}

/**
 * 从一页夸克文件列表里挑最新版本的文件（纯函数）：只看文件（file_type ≠ 0），版本号取自文件名，
 * 没有任何带版本的文件就返回 null。
 * @param {Array<{ file_name: string, file_type?: number }>} list
 * @returns {{ version: string, name: string } | null}
 */
export function newestVersionedFile(list) {
  let best = null;
  for (const f of Array.isArray(list) ? list : []) {
    if (!f || typeof f.file_name !== 'string' || (f.file_type ?? 1) === 0) continue;
    const v = versionFromFileName(f.file_name);
    if (!v) continue;
    if (!best || compareHexVersions(v, best.version) > 0) best = { version: v, name: f.file_name };
  }
  return best;
}

/**
 * @param {{ url?: string, current?: string, fetchImpl?: typeof fetch, now?: () => number, log?: object,
 *           timeoutMs?: number, intervalMs?: number }} opts
 */
export function createHexUpdateChecker(opts = {}) {
  const url = opts.url || process.env.SP_HEX_UPDATE_URL || HEX_UPDATE_URL_DEFAULT;
  const current = opts.current || HEX_MOD_VERSION;
  const doFetch = opts.fetchImpl || ((...a) => globalThis.fetch(...a));
  const now = opts.now || (() => Date.now());
  const log = opts.log || null;
  const timeoutMs = opts.timeoutMs ?? FETCH_TIMEOUT_MS;
  const intervalMs = opts.intervalMs ?? CHECK_INTERVAL_MS;

  let lastView = updateCheckView(current, null); // checked:false —— 还没查过
  let lastAt = 0;
  let inflight = false;

  const note = (line, err) => {
    if (!log) return;
    if (err) log.warn?.(`[hexmod] ${line}`, err); else log.info?.(`[hexmod] ${line}`);
  };

  // ---- 渠道 1：夸克网盘分享（未文档化接口，实测 2026-10 可匿名列出；坏了就退化为「没检查出来」） ----
  const jtext = (v, max) => (typeof v === 'string' ? v.replace(/\s+/g, ' ').trim().slice(0, max) : '');
  const QK = 'https://drive-pc.quark.cn/1/clouddrive';
  const qs = 'pr=ucpro&fr=pc';

  async function quarkManifest(shareUrl) {
    const id = quarkShareId(shareUrl);
    if (!id) throw new Error('not a quark share url');
    let passcode = '';
    try {
      const q = new URL(shareUrl).searchParams;
      passcode = q.get('pwd') || q.get('passcode') || '';
    } catch { /* 无查询串 */ }
    const deadline = now() + timeoutMs;
    const left = () => deadline - now();
    const post = async (u, body) => {
      const r = await doFetch(u, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) });
      if (left() <= 0) throw new Error('timeout');
      const j = await r.json();
      if (j.status !== 200 || !j.data) throw new Error(`quark api status ${j.status}（${j.message || '分享可能已取消或需要提取码'}）`);
      return j.data;
    };
    const getJson = async (u) => {
      const r = await doFetch(u);
      if (left() <= 0) throw new Error('timeout');
      const j = await r.json();
      if (j.status !== 200) throw new Error(`quark api status ${j.status}`);
      return j.data || {};
    };
    const tok = await post(`${QK}/share/sharepage/token?${qs}`, { pwd_id: id, passcode });
    const stoken = encodeURIComponent(tok.stoken);
    // 逐层扫目录（depth ≤ 3：分享根 → 版本子目录 → 再一层），文件名带版本号的取最大。
    let best = null;
    let bestName = '';
    const walk = async (fid, depth) => {
      if (depth > 3 || left() <= 0) return;
      const u = `${QK}/share/sharepage/detail?${qs}&pwd_id=${id}&stoken=${stoken}&pdir_fid=${fid || '0'}&_page=1&_size=200&_fetch_banner=0&_fetch_share=0&_fetch_total=1&_sort=file_type:asc,updated_at:desc`;
      const d = await getJson(u);
      for (const f of d.list || []) {
        if (f.file_type === 0) await walk(f.fid, depth + 1);
        else {
          const v = versionFromFileName(f.file_name);
          if (v && (!best || compareHexVersions(v, best) > 0)) { best = v; bestName = jtext(f.file_name, 200); }
        }
      }
    };
    await walk('0', 0);
    if (!best) throw new Error('分享里没有带版本号的文件');
    return { version: best, notes: bestName, downloadUrl: shareUrl };
  }

  // ---- 渠道 2：普通 JSON 清单 ----
  async function jsonManifest(u) {
    const r = await doFetch(u, { headers: { accept: 'application/json' } });
    if (!r || !r.ok) throw new Error(`HTTP ${r ? r.status : 'no response'}`);
    const manifest = parseUpdateManifest(await r.json());
    if (!manifest) throw new Error('bad manifest shape');
    return manifest;
  }

  /** 拉一次远端「最新版本」并刷新缓存；任何失败都吞掉（checked:false），只影响这一次的结果。 */
  async function check() {
    if (inflight) return lastView;
    inflight = true;
    try {
      const manifest = quarkShareId(url) ? await quarkManifest(url) : await jsonManifest(url);
      lastView = updateCheckView(current, manifest);
      lastAt = now();
      if (lastView.outdated) note(`发现新版本 v${manifest.version}（本地 v${current}）—— 标题屏会提示玩家更新`);
      else note(`已是最新版本 v${current}`);
    } catch (e) {
      lastView = updateCheckView(current, null);
      lastAt = now();
      note(`检查更新失败（不影响进入游戏）：${e && e.message ? e.message : e}`, e);
    } finally {
      inflight = false;
    }
    return lastView;
  }

  /**
   * 浏览器请求的同步视图：缓存有效期内直接回；过期了就后台补查一次（本次仍回旧值，绝不等待网络）。
   */
  function status() {
    if (!inflight && now() - lastAt > intervalMs) check().catch(() => {});
    return lastView;
  }

  return { check, status, url, current };
}
