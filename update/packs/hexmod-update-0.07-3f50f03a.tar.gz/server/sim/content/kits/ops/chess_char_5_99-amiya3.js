// server/sim/content/kits/ops/chess_char_5_99-amiya3.js — 阿米娅(医疗) (char_1037_amiya3) kit, tier 5.
// Conventions of the tier-5 kits: ../shared/tier5.js; kit contract and rules: ../README.md.
//
// 作者设定（v0.05.3，全部实装）：
//   · 特性（模组 INC-X）：攻击造成法术伤害，攻击时为范围内一名友方治疗 60% 伤害量 —— 由咒愈师分支的职业安装器按 profile.healRatio 提供。
//   · 天赋「诚挚期许」：在场时全体友方最大生命 +10%；技能期间全体友方每秒回复 3.5% 最大生命。
//   · 光环「专属能力」：攻击范围内友方（含自身）+5% 全能穿透、+10% 全属性；
//     范围内任一干员**开启技能**时，其己方已激活盟约层数 +1；结算受房间的盟约突破上限开关控制。
//   · 技能「慈悲愿景」：一次攻击最多命中 2 名；技能命中者施加寒冷（攻速 −30%，7 秒）；满层攻击 +125%。
//   · 里程碑：累计伤害 500 万 → 25% 伤害转真实（match 层判定，随 opts.amiyaTrue 进来）；
//     累计治疗 500 万 → 范围内最终单次 HP 扣血 ≤10% 最大生命（所有 HP 伤害类型，damage.js 落地前封顶）。
//
// ⚠️ 所有 install 逻辑都写在 **talents[0].install** 里，不用 kit 级 install：
//    `content/index.js:229-233` 只在「kit.install 与 generic.install 同时存在」时才合并，否则丢弃 kit.install
//    （实测：kit 级 install 不执行 → 光环/回血/计数全部失效；talents 的 install 会执行）。

import { num, talent, mods, traitBb, skillRange } from '../shared/tier5.js';
import { installAura, up } from '../shared/tier1.js';
import { bodyInKeys } from '../../../body.js';

/** 天赋：技能期间每秒回复的最大生命百分比（模组 3 级）。 */
const REGEN_PCT_PER_SEC = 0.035;
/** 天赋：全体最大生命加成。 */
const MAX_HP_PCT = 0.10;
/** 光环：全能穿透 / 全属性。 */
const AURA_PIERCE = 0.05;
const AURA_ALL_STATS = 0.10;
const BOND_POLL_INTERVAL = 0.2;
/** 技能数值（Lv7）。 */
const SKILL = { slowSec: 7, atkPerHit: 0.25, maxStack: 5, targets: 2, trueRatio: 0.25 };

/**
 * 攻击范围内的友方（含自身）。
 * 优先用引擎算好的 rangeKeySet；拿不到或没命中时**按坐标距离兜底** —— 阿米娅刚部署时 rangeKeySet 可能为空，
 * 那会让「范围内」恒为 false（实测就是因此光环/计数全没生效）。
 */
function inRange(unit, a) {
  if (a === unit) return true;
  if (!a || !a.alive || !a.deployed) return false;
  const ks = unit.rangeKeySet;
  if (ks && typeof ks.size === 'number' && ks.size > 0) {
    try { if (bodyInKeys(a, ks)) return true; } catch (e) { /* 落到距离判断 */ }
  }
  const r = (unit.s && Number(unit.s.rangeRadius)) || 3.0;
  const dx = Math.abs((Number(a.x) || 0) - (Number(unit.x) || 0));
  const dy = Math.abs((Number(a.y) || 0) - (Number(unit.y) || 0));
  return Math.max(dx, dy) <= r + 0.6 || dx * dx + dy * dy <= (r + 0.6) * (r + 0.6);
}

export default {
  chess_char_5_99_a: (bb, chess, def) => {
    const t0 = (talent(chess, 0) || {}).bb || {};
    const tb = traitBb(chess);
    const hpPct = num(t0.max_hp_pct, MAX_HP_PCT);
    const regenPct = num(t0.regen_pct_per_sec, REGEN_PCT_PER_SEC);
    const auraPierce = num(tb.aura_pierce, AURA_PIERCE);
    const auraAllStats = num(tb.aura_all_stats, AURA_ALL_STATS);
    const bondLayerGain = num(tb.bond_layer_on_skill, 1);
    const trueRatio = num(tb.true_dmg_ratio, SKILL.trueRatio);

    return {
      // ── 技能「慈悲愿景」：技能攻击最多选两个目标并附加寒冷 ─────────────────────────────────────
      trait: {
        dmgType: 'arts',
        maxTargets: 1,
      },
      skill: {
        kind: 'duration',
        mods: mods({ atkPct: SKILL.atkPerHit * SKILL.maxStack }),
        targeting: skillRange(chess, def, { maxTargets: SKILL.targets }),
        attack: {
          onEachHit({ battle, unit, target, isSkill }) {
            if (!isSkill || !target || !target.alive || target.side !== 'enemy') return;
            battle.applyStatus(target, 'cold', { duration: SKILL.slowSec, source: unit });
          },
        },
      },
      skills: {},

      // ── 以下全部逻辑挂在天赋的 install 上（kit 级 install 引擎不会调用，见文件头）──────────
      talents: [
        {
          install(battle, unit) {
            // ① 在场时**全体**友方最大生命 +10%
            installAura(battle, unit, {
              key: 'amiya:maxhp',
              select: () => true,
              mods: { hpPct },
              value: hpPct,
              interval: 1,
            });

            // ② 光环：**攻击范围内**友方（含自身）+5% 全能穿透 / +10% 全属性
            installAura(battle, unit, {
              key: 'amiya:aura',
              select: (a) => inRange(unit, a),
              mods: { pierce: auraPierce, atkPct: auraAllStats, defPct: auraAllStats, hpPct: auraAllStats },
              value: auraAllStats,
              interval: 0.3,
            });

            // ③ 天赋：技能期间全体友方每秒回复 3.5% 最大生命（以她为 source ⇒ 计入她的累计治疗量）
            const regen = (dt) => {
              if (!up(unit) || !unit.skill?.active) return;
              for (const a of battle.alliesFor(unit)) {
                if (!a || !a.alive || !a.s) continue;
                const amount = a.s.maxHp * regenPct * dt;
                if (amount > 0) battle.heal(unit, a, amount, { silent: true });
              }
            };
            battle.on('tick', ({ dt }) => regen(dt), { owner: unit });

            // ④ 里程碑：累计伤害达标后，追加黑板比例真实伤害
            battle.on('damaged', (c) => {
              const opts = battle.opts || {};
              if (!opts.amiyaTrue || !c || c.source !== unit || c.target?.side !== 'enemy') return;
              const rec = c.dmg || c;
              if (!rec || rec.isSplash) return;
              const amount = Number(rec.amount) || 0;
              if (amount <= 0 || !c.target || !c.target.alive || (c.dmg?.tags || []).some((tag) => tag === 'amiyaTrue')) return;
              battle.dealDamage(unit, c.target, {
                amount: amount * trueRatio,
                type: 'true',
                tags: ['trait', 'amiyaTrue'],
              });
            }, { owner: unit });

            // ⑥ 光环：范围内任一干员「开启技能」→ 己方已激活盟约层数 +1（战斗内只计数，结算时加层）
            const prev = new Map();
            // v0.07 修复（玩家反馈「范围内干员叠层数不增加」）：旧实现用 `WeakSet<skill>` 去重，
            // 但 `u.skill` 整场只会 new 一次（battle/players.js），同一个技能对象复用到底 ——
            // 于是每名干员整场只贡献 1 层，之后开多少次技能都不再加层。
            // 现在：skillStart 每次开启都记一层；轮询只做兜底（同一次开启若已被事件记过，按时间窗跳过）。
            const lastGainAt = new Map();
            const addBondGain = (actor, skill, fromEvent = false) => {
              if (!(bondLayerGain > 0) || !actor || !skill || !inRange(unit, actor) || !up(unit)) return;
              if (!fromEvent) {
                const t = lastGainAt.get(actor);
                if (t != null && battle.time - t <= BOND_POLL_INTERVAL * 2) return;
              }
              lastGainAt.set(actor, battle.time);
              prev.set(actor, true);
              if (!battle.amiyaBondGain) battle.amiyaBondGain = new Map();
              const k = actor.ownerId || actor.pid || '__shared';
              battle.amiyaBondGain.set(k, (battle.amiyaBondGain.get(k) || 0) + bondLayerGain);
            };
            const sampleSkillEdges = () => {
              if (!up(unit)) return;
              for (const a of battle.alliesFor(unit)) {
                if (!a || !a.skill || !inRange(unit, a)) continue;
                const now = !!a.skill.active;
                const was = prev.get(a) || false;
                if (now && !was) addBondGain(a, a.skill, false);
                prev.set(a, now);
              }
              for (const a of [...prev.keys()]) {
                if (!a || !a.alive || !a.deployed) { prev.delete(a); lastGainAt.delete(a); }
              }
            };
            battle.every(BOND_POLL_INTERVAL, sampleSkillEdges, { owner: unit, immediate: false });
            battle.on('skillStart', ({ unit: actor, skill }) => addBondGain(actor, skill, true), { owner: unit });
          },
        },
      ],
    };
  },
};
