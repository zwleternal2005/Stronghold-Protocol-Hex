// shared/hexChanges.js — 海克斯平衡改动表（this fork, 图鉴用）。
//
// V0.03.2 的 13 处调整：图鉴（public/js/ui/hexCodex.js）按这张表给受影响的卡片画改动标记，
// 并在卡面下方给出「改动前」的原文做对照 —— 改动过的片段用绿色高亮（用户要求：绿色字体体现改动处），
// 直到**下一次海克斯更新**：下次改海克斯时把本文件整体替换成新一版（`HEX_CHANGES_VERSION` 一起改），
// 旧的一版不再保留（`HEX_CHANGES = {}` 即图鉴上不显示任何标记）。
//
// 字段：
//   verdict  'buff'（增强，图鉴画绿色 ↑）| 'nerf'（削弱，红色 ↓）| 'tweak'（调整，黄色 —）
//   before   改动前的描述原文；**被改动的片段用 [[…]] 包起来**（图鉴渲染成绿色）
//   added    本次**新增**的整句（改动前没有），图鉴另起一行绿色「＋ 新增」展示
//   label    一句话概括（可选，图鉴在标记旁的小字）

/** 本次改动表对应的版本（下次海克斯更新时整体替换）。 */
export const HEX_CHANGES_VERSION = 'v0.04.4';

/**
 * @type {Record<string, { verdict: 'buff'|'nerf'|'tweak', before?: string, added?: string, label?: string }>}
 */
export const HEX_CHANGES = Object.freeze({
  // v0.04.3：双盟约系列首条 —— 焚荒之冰（图鉴画绿色「＋ 新增」）
  bx_frostfire: {
    verdict: 'buff',
    added: '双盟约海克斯（炎 × 谢拉格）：【炎】对同时处于灼燃损伤与寒冷/冻结的敌人造成伤害时，额外造成相当于该次伤害 1% / 3% 的真实伤害；'
      + '【谢拉格】打处于灼燃损伤的敌人有 50% 概率使谢拉格获得 1 层；两个盟约任一方获得层数时，对方获得其中 25%'
      + '（自身转移的层数不再触发，不会循环）。获得 1 名 1 阶【炎】与 1 名 1 阶【谢拉格】干员。',
    label: '新增 · 双盟约系列（炫彩）',
  },
});

/** 取某条海克斯的改动记录；没有登记就是 null（图鉴据此决定画不画标记）。 */
export function hexChangeOf(id) {
  return (id && HEX_CHANGES[id]) || null;
}
