// server/match/player/views.js — PlayerState methods: the views — pieceView, effectsView (the effects column: 策略 / 机变 /
// 悬赏 …) and m.private (privateView).
// Installed on PlayerState.prototype by server/match/PlayerState.js (a method container: never instantiated; `this` is
// the player state).

import { PHASE } from '../../../shared/constants.js';
import { boardOrder, pieceDir } from '../board.js';
import { bondList, offBondCounts } from '../bondsMeta.js';
import { bountyText, bountyCard } from '../choices.js';

export class PlayerViews {
  pieceView(p, rc = null) {
    const rec = p.kind === 'item' ? this.gd.item(p.id) : p.kind === 'token' ? this.gd.token(p.id) : this.gd.chess(p.id);
    const v = {
      uid: p.uid,
      kind: p.kind,
      id: p.id,
      golden: !!(rec && rec.isGolden),
      tier: rec && Number.isInteger(rec.tier) ? rec.tier : null,
      items: p.kind === 'chess' ? (p.items || []).map((it) => ({ uid: it.uid, id: it.id })) : [],
      count: p.kind === 'token' ? (p.count || 1) : 1,
      ownerUid: p.kind === 'token' ? p.ownerUid ?? null : null,
    };
    if (rc) { v.row = rc[0]; v.col = rc[1]; v.dir = pieceDir(p); }
    return v;
  }

  effectsView() {
    // 「本局海克斯详情」统计 (v0.03.3)：海克斯徽章的 tooltip 直接拼上这台账里的收益（玩家要求：右侧栏悬停可见）
    const statLines = (id) => {
      const view = this.m && typeof this.m.hexStatsView === 'function' ? this.m.hexStatsView(this) : null;
      const rec = Array.isArray(view) ? view.find((x) => x && x.id === id) : null;
      return rec && Array.isArray(rec.lines) ? rec.lines : [];
    };
    const out = [];
    const band = this.bandId ? this.gd.band(this.bandId) : null;
    if (band) out.push({ id: band.effectId || band.bandId, name: band.effectName || band.name, desc: band.desc || '', iconKind: 'band', iconId: band.iconId || band.bandId });
    for (const e of this.effects) {
      if (e.hidden) continue;
      const v = { id: e.id, name: e.name || e.id, desc: e.desc || '', iconKind: e.iconKind || 'choice', iconId: e.iconId || e.id };
      if (e.counter != null) v.counter = e.counter;
      // 海克斯徽章：右侧效果栏悬停时把「本局海克斯详情」的统计一起显示（玩家要求）
      if (v.iconKind === 'hex' && typeof v.id === 'string' && v.id.startsWith('hex:')) {
        const extra = statLines(v.id.slice(4));
        if (extra.length) v.desc = v.desc ? `${v.desc}\n· ${extra.join('\n· ')}` : extra.join('\n');
      }
      out.push(v);
    }
    for (const b of this.bounties) {
      // the battles the bounty's enemies still come for (an official multi-round card: every battle, no counter) and
      // the card's official rich text (blue "下场作战" / "两场作战", red "每场"; a multi-round card reads as long as it
      // lasts — choices.js bountyText, MULTI_ROUND_BOUNTY_BATTLES) — user playtest #6 item 4
      const left = b.roundsLeft >= 90 ? null : b.roundsLeft;
      const eff = b.card.effectId ? this.gd.effect(b.card.effectId) : null;
      out.push({
        id: b.id, name: b.card.name || '悬赏', desc: bountyText((eff && eff.descRaw) || b.card.desc || '', b.card), iconKind: 'choice', iconId: b.card.effectId || 'bounty', // i18n-ignore: a data-less card's fallback name
        counter: left, counterText: left == null ? '之后的每场作战' : `还剩 ${left} 场作战`, // i18n-ignore: older clients (ui/effectsList.js builds it from counter)
      });
    }
    return out;
  }

  privateView() {
    // `support: true` marks a slot rolled from an operator THIS player brought as 助战 (shared/support.js) — additive,
    // so a client that does not know the field still reads the slot exactly as before.
    const slots = this.shop.slots.map((s) => (s ? {
      kind: s.kind, id: s.id, price: this.priceOf(s), basePrice: s.basePrice, sold: !!s.sold, frozen: !!s.frozen,
      ...(s.support ? { support: true } : {}),
    } : null));
    const offer = this.offers[0] || null;
    const free = this.shop.freeRefreshes > 0;
    const board = [];
    for (const { r, c, piece } of boardOrder(this.board)) board.push(this.pieceView(piece, [r, c]));
    // a boss round's prep: the partner's board on its half of the boss field (Match.bossMateView, item 51)
    const bossMate = typeof this.m.bossMateView === 'function' ? this.m.bossMateView(this) : null;
    return {
      t: 'm.private',
      playerId: this.playerId,
      seat: this.seat,
      alive: this.alive,
      lp: this.lp,
      funds: this.funds,
      bandId: this.bandId,
      ready: this.ready,
      canReady: this.alive && this.tempEmpty && !this.personalChoice && !this.hexOffer && this.m.phase === PHASE.PREP,
      personalChoice: this.personalChoice ? {
        id: this.personalChoice.id,
        round: this.personalChoice.round,
        sourceItemId: this.personalChoice.sourceItemId,
        cards: this.personalChoice.cards.map((c) => bountyCard(this.gd, c)),
      } : null,
      // 海克斯 (TFT-style augment, this fork): `hex` = the FIRST confirmed pick (match-long, the legacy field),
      // `hexes` = every pick of this match (第 1 / 第 7 回合各一张). `hexOffer` is the open draft, resolved by the client
      // overlay from shared/hexes.js. m.private only — teammates see the picks in m.public.
      hex: this.hex,
      hexes: Array.isArray(this.hexes) ? this.hexes.slice() : [],
      hexOfferDraft: this.hexOfferDraft || 0,
      hexOffer: Array.isArray(this.hexOffer) ? this.hexOffer.slice() : null,
      // 自选海克斯 (v0.03.3)：本次草案里「自选」那一格的 id（客户端据此高亮；没有自选 = null）
      hexOfferPicked: this.hexOfferPicked || null,
      // 「本局海克斯详情」(v0.03.3)：已获得的海克斯 + 各自的实际收益统计（资金/触发次数/派生值）
      hexStats: this.m.hexStatsView(this),
      // 海克斯: 本次候选的等级（silver / gold / prismatic）—— 三张卡同等级，客户端据此画配色与标题
      hexGrade: this.hexGrade || null,
      // 海克斯: 每个选项各自剩余的免费刷新次数（与 hexOffer 同下标）+ 多人模式的选择截止时刻
      // （epoch ms，0 = 不限时）—— 客户端据此画每张卡的刷新按钮与倒计时
      hexRerolls: Array.isArray(this.hexRerolls) ? this.hexRerolls.slice() : null,
      hexDeadline: Number.isFinite(this.hexDeadline) && this.hexDeadline > 0 ? this.hexDeadline : 0,
      // 海克斯熔毁协议 (this fork, 无尽)：隐秘 Boss 后的四栏商店；没开时 null
      meltdown: typeof this.m.meltdownView === 'function' ? this.m.meltdownView(this) : null,
      // 混沌投掷 (this fork, 赌局系列)：最后一次投掷的结果（seq 幂等，客户端只演不算）
      chaos: this.chaosEvent || null,
      shop: {
        level: this.shop.level,
        maxLevel: this.gd.maxShopLevel,
        upgradePrice: this.shop.level >= this.gd.maxShopLevel ? 0 : this.shop.upgradePrice,
        refreshPrice: free ? 0 : this.gd.refreshPrice,
        freeRefreshes: this.shop.freeRefreshes,
        frozen: this.shop.frozen,
        slots,
        // `source` 'merge' = the promotion reward (晋升奖励); any other offer (a strategy, an item, a 特质) carries the
        // `label` the bar shows instead; `queued` = offers waiting behind it (player report #6 after 0.1.0)
        rewardOffer: offer ? { tier: offer.tier, source: offer.source === 'merge' ? 'merge' : 'special', label: offer.label || null, queued: this.offers.length - 1, slots: offer.slots.map((s) => ({ kind: s.kind === 'item' ? 'item' : 'chess', id: s.id, price: s.price, sold: !!s.sold })) } : null,
      },
      hand: this.hand.map((p) => (p ? this.pieceView(p) : null)),
      temp: this.temp.map((p) => (p ? this.pieceView(p) : null)),
      board,
      // The stage's 外勤医疗 reserve medic is present during prep, but is not a draggable board piece.
      prepMapChars: this.m.prepMapChars(this),
      deployCap: this.deployCap,
      deployCount: this.deployCount,
      // 额外上阵栏位 (this fork, 房间旗子 `buySlot`)：{ bought, left, price, maxed, cap } 或 null（开关没开）——
      // 客户端按它在生命值旁画「购买上阵位」按钮（25/50/75 逐级）
      slotBuy: this.m.slotBuyState(this),
      // 回合结束保留资金 (this fork, 房间旗子 `keepFunds`；无尽默认开)：客户端据此不再弹「剩余资金将清零」的确认
      keepFunds: this.m.roomKeepsFunds(),
      // + the mode-off bonds it has members of (`off: true`, the strip's grey 本局禁用 discs — bondsMeta.offBondCounts)
      bonds: bondList(this.gd, this.bondsView(), { full: true, off: offBondCounts(this.gd, this) }),
      effects: this.effectsView(),
      nextEnemies: this.m.nextEnemiesFor(this),
      // 助战 (shared/support.js): what this player brought AND what was actually granted at round 1. They differ when
      // the server's pool changed between the lobby's check and the grant (prepareSupports re-checks), and when a granted
      // piece is sold or merged away — so the client can say which supports it is actually fighting with.
      support: { selected: Array.isArray(this.support) ? [...this.support] : [], granted: Array.isArray(this.supportGranted) ? [...this.supportGranted] : [] },
      // DESIGN §16: the effective operator loadout ({ [baseChessId]: { skill, module } }; chess not listed use defaults)
      loadout: this.loadout,
      // 0.2.2: the effective per-operator 潜能 / 练度 ({ [charId]: { potential, cultivate } }; operators not listed: 潜能 6,
      // 精英2 Lv.60) — the client's cards compose the numbers from it (shared/potential.js)
      ops: this.ops,
      // 0.2.0 补位: the base chess ids this player fields as their stand-ins in this match (the not-owned list the seat had
      // at the match start; [] = every operator owned) — the client shows these as their stand-ins (cards, pieces, the
      // detail card, with a small 「替补」 mark)
      standIns: this.standIns,
      // 0.2.0 自选编队: this player's 自选 picks in this match ({ [slotBaseId]: { charId, skillIndex, uniEquipId } } — the seat's
      // when the match started; {} = none) — the client composes the operator's record for its own cards and pieces
      // (shared/diy.js diyRecord); `diyBanned`: the slotted slots out of the shop this match (every bond of the operator
      // switched off)
      diy: this.diy,
      diyBanned: this.diyBanned,
      // 最终攻势 / 隐秘核心 prep (community report of 2026-10-06, item 51): `{ playerId, side, units }` — the pair partner's
      // board pieces as UnitInfo on its half of the boss field (mirrored on the right half, as the battle places them);
      // the own prep view draws them beside the own half, read-only. Absent otherwise.
      ...(bossMate ? { bossMate } : {}),
      stats: {
        dmgDealt: Math.round(this.stats.dmgDealt), kills: this.stats.kills, leaks: this.stats.leaks, gold: this.stats.gold,
        refreshes: this.stats.refreshes, merges: this.stats.merges,
      },
    };
  }
}
