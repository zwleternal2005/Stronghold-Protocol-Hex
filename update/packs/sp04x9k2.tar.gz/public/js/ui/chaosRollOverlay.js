// public/js/ui/chaosRollOverlay.js — 混沌投掷演出 (this fork, 赌局系列：赌神！/ 赌王！/ 赌徒！)。
//
// 服务端（server/match/match/chaosRoll.js）掷好 3d6 并结算完奖励，把结果挂在 m.private.chaos：
//   { seq, dice:[a,b,c], key, word, reward, hex }   （seq 单调递增，客户端按 seq 幂等播放，只演不算）
// 演出：三颗骰子同时翻滚（罗马数字面快速切换）→ 依次落定 → 判定艺术字（彩蛋走炫彩）→ 奖励行 → 3s 后淡出。
//
// 视觉：白底 / 蓝色罗马数字 / 金色边框；判词与海克斯选择界面同一套「双图层」渐变字（.vglow/.vfill，
// 单层 text-shadow + background-clip:text 会让阴影盖住填充，整行发白 —— 见 hex.css 的注释）。

import { html } from './components.js';
import { useEffect, useRef, useState } from '../../vendor/hooks.module.js';
import { t } from '../../../shared/i18n.js';

const cx = (...p) => p.flat().filter(Boolean).join(' ');

const ROMAN = Object.freeze({ 1: 'I', 2: 'II', 3: 'III', 4: 'IV', 5: 'V', 6: 'VI' });
/** 面朝向：FACE_TF[face] = [rotateX, rotateY]（面 2/5 在顶/底，面 3/4 在右/左，1 正面、6 背面） */
const FACE_TF = Object.freeze({ 1: [0, 0], 2: [-90, 0], 3: [0, -90], 4: [0, 90], 5: [90, 0], 6: [0, 180] });
const RAINBOW = new Set(['jackpot', 'kings', 'done']);

const T_ROLL = 820;      // 三骰同滚
const T_SETTLE = 250;    // 相邻两颗落定的间隔
const T_VERDICT = 140;   // 全部落定 → 判词
const T_REWARD = 260;    // 判词 → 奖励行
const T_HOLD = 3000;     // 奖励行停留
const T_OUT = 560;       // 淡出

/**
 * 一颗骰子。`face` 是当前朝上的点数；`spinning` 为 true 时快速翻滚（父组件换 face 驱动）。
 */
function Die({ face, spinning, settled }) {
  const tf = FACE_TF[face] || FACE_TF[1];
  const transform = spinning
    ? `rotateX(${face * 72}deg) rotateY(${face * 108}deg)`
    : `rotateX(${tf[0]}deg) rotateY(${tf[1]}deg)`;
  const faces = [];
  for (let f = 1; f <= 6; f++) {
    faces.push(html`<div key=${f} class=${`chaos__face chaos__face--${f}`}>
      <b class="chaos__roman">${ROMAN[f]}</b>
    </div>`);
  }
  return html`<div class=${cx('chaos__die', spinning && 'is-spinning', settled && 'is-settled', settled && 'is-landed')}>
    <div class="chaos__cube" style=${{ transform }}>${faces}</div>
  </div>`;
}

/**
 * @param {{ ev: {seq:number, dice:number[], key:string, word:string, reward:string, hex:string},
 *          onDone?: () => void }} props
 */
export function ChaosRollOverlay({ ev, onDone = () => {} }) {
  const [faces, setFaces] = useState(() => ev.dice.map(() => 1));
  const [settled, setSettled] = useState(() => ev.dice.map(() => false));
  const settledRef = useRef(ev.dice.map(() => false));   // interval 里读最新值（state 闭包是旧的）
  const [phase, setPhase] = useState('spin');   // spin → verdict → reward → out

  useEffect(() => {
    const timers = [];
    const spins = ev.dice.map(() => setInterval(() => {
      setFaces((prev) => prev.map((v, k) => (settledRef.current[k] ? v : 1 + Math.floor(Math.random() * 6))));
    }, 68));
    const stopSpins = () => spins.forEach(clearInterval);
    timers.push(setTimeout(() => {
      ev.dice.forEach((d, i) => {
        timers.push(setTimeout(() => {
          clearInterval(spins[i]);        // 这一颗停：换面 → 落定（其余两颗继续滚，直到轮到它们）
          setFaces((prev) => prev.map((v, k) => (k === i ? d : v)));
          settledRef.current = settledRef.current.map((v, k) => (k === i ? true : v));
          setSettled(settledRef.current.slice());
          if (i === ev.dice.length - 1) setPhase('verdict');
        }, i * T_SETTLE));
      });
      const tVerdict = ev.dice.length * T_SETTLE + T_VERDICT;
      timers.push(setTimeout(() => setPhase('reward'), tVerdict + T_REWARD));
      timers.push(setTimeout(() => setPhase('out'), tVerdict + T_REWARD + T_HOLD));
      timers.push(setTimeout(() => onDone(), tVerdict + T_REWARD + T_HOLD + T_OUT));
    }, T_ROLL));
    return () => { stopSpins(); timers.forEach(clearTimeout); };
  }, [ev.seq]);

  const rolling = phase === 'spin';
  const showVerdict = phase === 'verdict' || phase === 'reward';
  const showReward = phase === 'reward';
  const rainbow = RAINBOW.has(ev.key);

  return html`<div class=${cx('chaos', phase === 'out' && 'is-out')} role="status" aria-label=${t('混沌投掷')}>
    <div class="chaos__veil" aria-hidden="true"></div>
    <div class="chaos__inner">
      <div class="chaos__micro">CHAOS ROLL // <b>${rolling ? t('投掷中…') : t('混沌投掷')}</b></div>
      <div class="chaos__hexname">${ev.hex}</div>

      <div class="chaos__dice">
        ${ev.dice.map((d, i) => html`<div key=${i} class="chaos__cell">
          <${Die} face=${faces[i]} spinning=${rolling || !settled[i]} settled=${settled[i]} />
          <div class=${cx('chaos__num', settled[i] && 'is-fixed', settled[i] && 'is-blue')}>
            ${settled[i] ? ROMAN[d] : '·'}
          </div>
        </div>`)}
      </div>

      ${showVerdict ? html`<div class="chaos__verdict">
        <div class=${cx('verdict__word', rainbow && 'is-rainbow', ev.key === 'small' && 'is-small', ev.key === 'none' && 'is-muted')}>
          <span class="vglow">${ev.word}</span><span class="vfill" aria-hidden="true">${ev.word}</span>
        </div>
      </div>` : null}
      ${showReward ? html`<div class="chaos__reward">${ev.reward}</div>` : null}
    </div>
  </div>`;
}
