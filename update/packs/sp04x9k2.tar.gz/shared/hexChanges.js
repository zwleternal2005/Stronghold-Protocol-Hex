// shared/hexChanges.js — 海克斯平衡改动表（this fork, 图鉴用）。
//
// V0.03.2 的 13 处调整：图鉴（public/js/ui/hexCodex.js）按这张表给受影响的卡片画改动标记，
// 并在卡面下方给出「改动前」的原文做对照 —— 改动过的片段用绿色高亮（用户要求：绿色字体体现改动处），
// 直到**下一次海克斯更新**：下次改海克斯时把本文件整体替换成新一版（`HEX_CHANGES_VERSION` 一起改），
// 旧的一版不再保留（`HEX_CHANGES = {}` 即图鉴上不显示任何标记）。
//
// 字段：
//   verdict  'buff'（增强，图鉴画绿色 ↑）| 'nerf'（削弱，红色 ↓）| 'tweak'（调整，黄色 —）
//   before   改动前的描述原文；**被改动的片段用 [[…]] 包起来**（图鉴渲染成绿色）
//   added    本次**新增**的整句（改动前没有），图鉴另起一行绿色「＋ 新增」展示
//   label    一句话概括（可选，图鉴在标记旁的小字）

/** 本次改动表对应的版本（下次海克斯更新时整体替换）。 */
export const HEX_CHANGES_VERSION = 'v0.04';

/** @type {Record<string, { verdict: 'buff'|'nerf'|'tweak', before?: string, added?: string, label?: string }>} */
export const HEX_CHANGES = Object.freeze({
  // v0.04：新增 6 条海克斯（赌局系列 3 条 + 飞升系列 3 条）—— 图鉴在卡片上画绿色「＋ 新增」。
  chaos_god: {
    verdict: 'buff', added: '立即进行一次混沌投掷，此后每两个回合的部署阶段开始时再投一次。掷出三颗骰子，按点数获得奖励。',
    label: '新增 · 赌局系列（炫彩）',
  },
  chaos_king: {
    verdict: 'buff', added: '立即进行两次混沌投掷。掷出三颗骰子，按点数获得奖励。',
    label: '新增 · 赌局系列（黄金）',
  },
  chaos_rookie: {
    verdict: 'buff', added: '立即进行一次混沌投掷。掷出三颗骰子，按点数获得奖励。',
    label: '新增 · 赌局系列（白银）',
  },
  ascension: {
    verdict: 'buff', added: '战斗开始 12 秒后，你的所有干员全属性增加 25%，直到战斗结束。',
    label: '新增 · 飞升系列（白银）',
  },
  ascension_plus: {
    verdict: 'buff', added: '战斗开始 12 秒后，你的所有干员全属性增加 50%，直到战斗结束。',
    label: '新增 · 飞升系列（黄金）',
  },
  ascension_plusplus: {
    verdict: 'buff', added: '战斗开始 12 秒后，你的所有干员全属性增加 100%，直到战斗结束。',
    label: '新增 · 飞升系列（炫彩）',
  },
});

/** 这张表里某条海克斯的改动记录（没有则 null）。 */
export function hexChangeOf(id) {
  return (id && Object.hasOwn(HEX_CHANGES, id)) ? HEX_CHANGES[id] : null;
}
